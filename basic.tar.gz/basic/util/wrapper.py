'''
Created on Nov 11, 2011

@author: mulawadifh
'''
class Map(object):
    '''Wrapper of dictionary object, to turn it into a Javascript-style dictionary'''
    def __init__(self, d=None):
        super(Map, self).__setattr__('_map_', d or dict())

    def __setattr__(self, k, v):
        self._map_[k] = v

    def __getattribute__(self, k):
        try:
            return super(Map, self).__getattribute__(k)
        except:
            _map_ = super(Map, self).__getattribute__('_map_')
            if k in _map_:
                o = _map_[k]
                def _recurse(x):
                    if type(x) is dict:
                        return Map(x)
                    elif type(x) is list:
                        return [_recurse(_) for _ in x]
                    else:
                        return x
                return _recurse(o)
            else:
                _map_[k] = Map()
                return _map_[k]
    
    def __getitem__(self, k):
        return self.__getattribute__(k)

    def __setitem__(self, k, v):
        self.__setattr__(k, Map(v) if isinstance(v, dict) else v)
    
    def __repr__(self):
        return 'Map(%s)'% super(Map, self).__getattribute__('_map_').__repr__()
    
    def __contains__(self, k):
        m = super(Map, self).__getattribute__('_map_')
        return k in m
    
    def _rec_update(self, target, source):
        for k,v in source.iteritems():
            if k in target:
                v2 = target[k]
                if type(v) == type(v2) and type(v) == dict:
                    self._rec_update(v2, v)
                else:
                    target[k] = v
            else:
                target[k] = v
    
    def update(self, newmap):
        m = super(Map, self).__getattribute__('_map_')
        if isinstance(newmap, dict):
            self._rec_update(m, newmap)
        elif isinstance(newmap, Map):
            self._rec_update(m, newmap.to_map())
        else:
            raise ValueError('Argument type must be "dict" or "Map"')
    
    def to_map(self):
        m = super(Map, self).__getattribute__('_map_')
        d = dict()
        for k,v in m.iteritems():
            if isinstance(v, Map):
                d[k] = v.to_map()
            elif isinstance(v, dict):
                d[k] = dict((p,q.to_map() if isinstance(q, Map) else q) for p,q in v.iteritems())
            elif isinstance(v, list):
                d[k] = [_.to_map() if isinstance(_, Map) else _ for _ in v]
            else:
                d[k] = v
        return d