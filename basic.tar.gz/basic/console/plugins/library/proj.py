'''
Created on Mar 30, 2012

@author: mulawadifh
'''
from browser.models import Project
from fabi.pytools.term import Tabulator, stdin_or_editor

def help():
  return 'Manage the list of projects'

def config(parser):
  subpar = parser.add_subparsers()
  sub = subpar.add_parser('new', help='Create new project entry. Description read from stdin, if available')
  sub.add_argument('name', help='Project name')
  sub.set_defaults(func=_new)
  
  sub = subpar.add_parser('list', help='List all projects')
  sub.set_defaults(func=_list)

def _new(args):
  proj = Project(name=args.name)
  proj.descn = stdin_or_editor('Please enter description for project [%s]'% args.name)
  proj.save()
  _list(args, id=proj.id)

def _list(args, **kw): # kw -> criteria passed to filter
  tabby = Tabulator()
  tabby.add_column('ID', 6, just='right')
  tabby.add_column('Project', 25, color='red')
  tabby.add_column('Description', 100)
  tabby.print_table((l.id, l.name, l.descn or '-') for l in Project.objects.filter(**kw))
