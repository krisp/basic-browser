'''
Created on Sep 11, 2011

@author: Fabianus
'''
from browser.models import Library, CellLine, Technology, TargetFactor
from console.plugins.library.list import list_libraries
from django.contrib.auth.models import User, Group
from fabi.pytools.term import stdin_or_editor
from termcolor import colored
import json
import sys

def help():
  return "Creates a new library. Description read from stdin, if available"

def permissions():
  return ['browser.add_library',]

def config(sub):
  sub.add_argument('name', help='Library name')
  sub.add_argument('-c', '--cell', help='Cell line name')
  sub.add_argument('-t', '--tech', help='Technology name')
  sub.add_argument('-f', '--factor', help='Target factor name')
  sub.add_argument('--owners', help='Usernames of owners; comma-separated')
  sub.add_argument('--groups', help='Names of groups; comma-separated')
  sub.add_argument('-j', '--json', action='store_true', help='Prints out output in JSON format. Useful in automation.')
  sub.set_defaults(func=_new)

def _new(args):
  owners = args.owners
  groups = args.groups
  if not (owners or groups) and not args.json:
    print colored("\nWARNING: You don't specify any owner or group.", 'yellow')
    print "The tracks belonging to this table can be viewed by anyone. Are you sure y/[n]? ",
    if sys.stdin.readline().rstrip().upper() != 'Y': return

  exist = False
  try:
    lib = Library.objects.get(name__iexact=args.name)
    exist = True
  except:
    lib = Library(name=args.name)
    lib.descn = stdin_or_editor('Please enter description for library [%s]'% args.name)
    if args.cell: lib.cell = CellLine.objects.get(name__iexact=args.cell)
    if args.tech: lib.tech = Technology.objects.get(name__iexact=args.tech)
    if args.factor: lib.target = TargetFactor.objects.get(code__iexact=args.factor)
    lib.save()
    
  if owners: lib.owners = [User.objects.get(username=_) for _ in owners.split(',')]
  if groups: lib.groups = [Group.objects.get(name=_) for _ in groups.split(',')]
  lib.save()
  
  if args.json:
    print json.dumps({ 'library-id': lib.id, 'existing': exist })
  else:
    setattr(args, 'libs', str(lib.id))
    setattr(args, 'assgs', [])
    list_libraries(args)
