'''
Created on Sep 11, 2011

@author: Fabianus
'''
from browser.models import Library
from console.plugins.library.list import list_libraries
from django.contrib.auth.models import User, Group
from fabi.pytools.text import parse_range

def help():
  return "Change library owners"

def permissions():
  return ['browser.change_library',]

def config(sub):
  sub.add_argument("libs", help="Table IDs; comma-separated")
  sub.add_argument("names", help="User/group names; comma-separated")
  sub.set_defaults(func=_chown)

def _chown(args):
  try:
    libids = parse_range(args.libs)
  except:
    libids = [Library.objects.get(name=_).id for _ in args.libs.split(',')]
    
  if ':' in args.names:
    p,q = args.names.split(':')
    users = p.split(',')
    groups = q.split(',')
  else:
    users = args.names.split(',')
    groups = []

  del_users = list()
  add_users = list()
  for u in users:
    if u and u[0] == '-':
      del_users += User.objects.filter(username=u[1:])
    else:
      add_users += User.objects.filter(username=u)
      
  del_grps = list()
  add_grps = list()
  for g in groups:
    if g and g[0] == '-':
      del_grps += Group.objects.filter(name=g[1:])
    else:
      add_grps += Group.objects.filter(name=g)
    
  for libid in libids:
    lib = Library.objects.filter(id=libid)
    if not lib: continue
    lib = lib[0]
    lib.owners.add(*add_users)
    lib.owners.remove(*del_users)
    lib.groups.add(*add_grps)
    lib.groups.remove(*del_grps)
  list_libraries(args)
