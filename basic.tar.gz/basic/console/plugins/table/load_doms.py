'''
Created on Apr 2, 2012

@author: mulawadifh
'''
from util.mongo import BASICollection
from console.plugins.table.common import get_table_id

def _convert(line):
  result = list()
  for dom in line.split(','):
    if not dom: continue
    arr = dom.split(':')
    result.append((arr[0], int(arr[3])+1, int(arr[4])+1))
  return result

def help():
  return ("HELP!")
  
def permissions():
  return []

def config(parser):
  parser.add_argument('table_id_name')
  parser.add_argument('-i', '--input', required=True)
  parser.set_defaults(func=_main)

def _main(args):
  genes = BASICollection(get_table_id(args.table_id_name))
  with open(args.input) as f:
    for line in f:
      line = line.strip()
      if not line: continue
      arr = line.split('\t')
      
      doc = genes.find_one({ 'ucsc_name': arr[0] })
      if doc:
        doms = _convert(arr[2])
        if doms:
          domname = doms[0]
          exons = doc['exons'] 
          doc['domains'] = doms
          genes.save(doc) 