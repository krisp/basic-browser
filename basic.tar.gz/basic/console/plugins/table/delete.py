'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.list import list_tables
from fabi.pytools.text import parse_range
from table.models import Table, Track, Metadata
from termcolor import colored
import sys
from util.mongo import BASICollection

def help():
  return "Deletes a table"

def permissions():
  return ['table.delete_table',]

def config(sub):
  sub.add_argument("tables", help="Table IDs; comma-separated")
  sub.set_defaults(func=del_tables)

def del_tables(args):
  if list_tables(args):
    print '\nDelete all these tracks y/[n]? %s '% colored('(THERE IS NO TURNING BACK)', 'red'),
    if sys.stdin.readline().rstrip().upper() != 'Y':
      print colored("Nothing is deleted", "white")
      return
  else:
    print "There's nothing to delete"
    return

  tables = Table.objects.filter(id__in=parse_range(args.tables))
  for tab in tables:
    for o in Track.objects.filter(table=tab):
      for md in Metadata.objects.filter(track=o): md.delete() 
      o.delete()
    
    BASICollection(tab.id).drop()
      
  count = len(tables)
  tables.delete()
      
  print colored("%d table(s) deleted."% count, "white")
  