'''
Created on Nov 23, 2011

@author: mulawadifh
'''
from console.plugins.table.common import get_table_id
from util.mongo import BASICollection
from table.models import Table
import re
import sys

def help():
    return "Loads data from Charlie's SNP file"
    
def permissions():
    return ['table.add_table',]

def config(parser):
    parser.add_argument('format', choices=('charlie', 'pileup'), help='Input format')
    parser.add_argument('table_id_name', help='Table ID or name in database')
    parser.add_argument('-i', '--input', help='Input file name. If not specified, the script will read from stdin')
    parser.add_argument('-m', '--mode', choices=['normal', 'overwrite', 'append'], 
                        help=r'normal (default): create new table (will fail if table already exists); overwrite: drop existing table; append: do not create table')
    parser.add_argument('-G', '--group', help='Group name (ignored in Charlie format; default="_")', default='_')
    parser.add_argument('--skip-header', type=int, help='Number of lines to skip at the beginning (0)', default=0)
    parser.set_defaults(func=_callback)

def _charlie_to_doc(arr, group):
    def _parse_xsectstring(xsectstr):
        xsectstr = xsectstr.strip()
        if xsectstr == '-': 
            return []
        else:
            return list(set(_.split(':')[0] for _ in xsectstr.split(';') if _))
            
    def _parse_groupstring(groupstr):
        groupstr = groupstr.strip()
        if groupstr == '-': return []
        
        result = list()
        for grp in groupstr.split(';'):
            name, _ = grp.split(':')
            if name[0] == '-': continue # skip weaklings
            _, a, c, g, t = _.split(',')[:5]
            if not name[0] in '0123456789':
                name = name[1:]
            result.append(dict(name=name, reads=dict(A=int(a),C=int(c),G=int(g),T=int(t))))
        return result

    chrom = arr[6]
    pos = int(arr[7])
    groups = _parse_groupstring(arr[25])
    
    return dict(
        chrom=chrom,
        start=pos,
        refbase=arr[8].strip(),
        recur=len(groups),
        groups=groups,
    )

def _charlie_meta():
    return {
        'version': 1.0,
        'traits': ['point'],
        'columns': [
            { 'name': 'chrom', 'type': 'str', 'long_name': 'Chromosome', 'indexed': True },                    
            { 'name': 'start', 'type': 'int', 'long_name': 'Position', 'indexed': True },
            { 'name': 'refbase', 'type': 'str', 'long_name': 'Ref. Base', 'indexed': False },
            { 'name': 'recur', 'type': 'int', 'long_name': '#Recurrences', 'indexed': True },
        ]
    }

def _pileup_to_doc(arr, group):
    refbase = arr[2]
    readstr = re.sub(r'[\.\,]', refbase, arr[8].upper())
    readstr = re.sub(r'[^ACGT]', '', readstr) # keep only ACGT
    reads = dict(A=0,C=0,G=0,T=0)
    for c in readstr: reads[c] += 1
    
    return dict(
        chrom=arr[0],
        start=int(arr[1]),
        refbase=refbase,
        groups=[dict(name=group, reads=reads)], # only one group
    )

def _pileup_meta():
    return {
        'version': 1.0,
        'traits': ['point'],
        'columns': [
            { 'name': 'chrom', 'type': 'str', 'long_name': 'Chromosome', 'indexed': True },                    
            { 'name': 'start', 'type': 'int', 'long_name': 'Position', 'indexed': True },
            { 'name': 'refbase', 'type': 'str', 'long_name': 'Ref. Base', 'indexed': False },
        ]
    }

def _bgi_to_doc(arr, group):
    groups = []
    for pair in arr[3].split(','):
        grp, ltr = pair.split(':')
        reads = dict(A=0, C=0, G=0, T=0)
        reads[ltr] = 1
        groups.append(dict(name=grp, reads=reads))
    
    return dict(
        chrom=arr[0],
        start=int(arr[1]),
        refbase=arr[2],
        groups=groups,
    )

def _bgi_meta():
    return {
        'version': 1.0,
        'traits': ['point'],
        'columns': [
            { 'name': 'chrom', 'type': 'str', 'long_name': 'Chromosome', 'indexed': True },                    
            { 'name': 'start', 'type': 'int', 'long_name': 'Position', 'indexed': True },
            { 'name': 'refbase', 'type': 'str', 'long_name': 'Ref. Base', 'indexed': False },
        ]
    }

def _callback(args):
    table_id = get_table_id(args.table_id_name)
    table_obj = Table.objects.get(id=table_id)

    if args.input:
        source = open(args.input) # only present if invoked via function
    else:
        source = sys.stdin
        if source.isatty():
            print >> sys.stderr, 'No file specified and no stream from stdin'
            return 1 

    coll = BASICollection(table_obj.id)
    
    if coll.count()>0:
        if args.mode == 'normal':
            raise Exception('There is existing data. Use mode=overwrite or mode=append')
        elif args.mode == 'overwrite':
            coll.drop()
    
    skiphdr = 0
    meta = globals()['_{args.format}_meta'.format(**locals())]()
    func = globals()['_{args.format}_to_doc'.format(**locals())]
    
    coll.meta(meta)
    
    id_ = 1
    for line in source:
        skiphdr += 1
        if skiphdr <= args.skip_header:
            continue
        
        arr = line.split('\t')
        doc = func(arr, args.group)
        doc['_id'] = id_
        coll.save(doc)
        id_ += 1

    # create indexes        
    for key in ('chrom', 'start'):
        coll.create_index(key)
