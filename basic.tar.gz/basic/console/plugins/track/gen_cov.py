'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.common import get_table_id
from console.plugins.track.common import refine_track_name, cov_to_ds, \
  aggregate
from engine.table_core import create_track_tx, create_metadata
from fabi.pytools.shell import ShellChain, Shell
from os import path
from table.models import Table
import settings
from fabi.pytools.io import opentemp
import json

def help(): 
  return "Generates coverage track using maxDS or sumDS"
    
def permissions():
  return ['table.add_track',]

def config(parser):
  parser.add_argument('type', choices=('max', 'sum'), help='Use either maxDS or sumDS')
  parser.add_argument('table_id_name', help='Table ID or name')
  parser.add_argument('source', help='Input file name')
  parser.add_argument('-n', '--name', help='Track name')
  parser.add_argument('-c', '--color', default='red', help='Coverage color (red)')
  parser.add_argument('-d', '--descn', help='Track description (None)', default=None)
  parser.add_argument('-C', '--count', type=int, default=1, help='How many series to make (1)')
  parser.add_argument('--no-pile', help='Do not perform pile-over',  action='store_true')

  parser.add_argument('-j', '--json', action='store_true', help='Prints out output in JSON format. Useful in automation (false)')
  parser.set_defaults(func=_parser_callback)

def _parser_callback(args):
  with aggregate(args.source) as source:
    '''source = case of
         None => read from database
         file => read from the file object (may be stdin)
    '''
    table = Table.objects.get(id=get_table_id(args.table_id_name))
    trk_name = refine_track_name(args.name or table.name)
    
    trk_types = dict(max='cov', sum='avg')
    with create_track_tx(table, trk_types[args.type], trk_name, args.descn) as track:
      dsname = 'trk_{track.id}'.format(**locals())
      chromfile = path.join(settings.GENOME_SIZE_DIR, '{0}.txt'.format(table.asm.name))
      
      sources = list()
      series = list()
      colors = args.color.split(',')
      
      # for each count (default=1), do a 'cut' and call gen_ds
      sh = Shell()
      for i in xrange(args.count):
        dsname_i = '{0}_{1}'.format(dsname, i)
        srcfile = path.join(dsname_i, '{name}.{type}'.format(name=dsname_i, type=args.type))
        sources.append(srcfile)
        series.append({ 'color': colors[i%len(colors)] })
        with opentemp() as tmpsrc:
          sh('cut -f1,2,3,{x} < "{inp}" > "{out}"'.format(x=i+4, inp=source, out=tmpsrc.name))
          gen_ds(args.type, table, dsname_i, chromfile, tmpsrc.name, not args.no_pile)
      
      create_metadata(track, source=sources, series=series)
      if args.json:
        print json.dumps({ 'track-id': track.id })

def gen_ds(type_, table, rmq_name, chrom_info, source, pileup):
  output_dir = path.join(settings.TRACK_DIR, rmq_name)
  ch = ShellChain()
  
  if not source:
    raise Exception('Data source undefined. Must be either file name or file object')
    
  if type(source) is str:
    ch.chain('cat "{0}"'.format(source))
    source = None 

  ch.chain(r"""awk 'BEGIN {{OFS="\t"}} {{ print $1,$2,"[",$4; print $1,$3-1,"]",$4 }}'""" if pileup else "cut -f 1-3")
  return cov_to_ds(type_, rmq_name, chrom_info, output_dir, source, ch, pileup)
