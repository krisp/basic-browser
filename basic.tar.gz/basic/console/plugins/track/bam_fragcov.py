'''
Created on Jul 1, 2011

@author: fabianus
'''
from console.plugins.table.common import get_table_id
from console.plugins.track.common import refine_track_name, rmdup, cov_to_ds, \
  aggregate
from engine.table_core import create_track_tx, create_metadata
from fabi.pytools.shell import ShellChain
from os import path
from table.models import Table
import settings
import sys

def help(): 
  return """Generates 'fragment' coverage track from BAM file.
            Assumes that the BAM file has two entries for every PET (read2 is ignored).
            If URL is given as source, it needs 'curl' to be installed.
            """

def permissions():
  return ['table.add_track',]

def config(parser):
  parser.add_argument("table_id_name", help="Table ID or name")
  parser.add_argument("sources", nargs="*", default=None, help="Input source")
  parser.add_argument("-n", "--name", help="Track name")
  parser.add_argument("-d", "--descn", help="Track description (default=None)", default=None)
  parser.set_defaults(func=_parser_callback)

def _parser_callback(args):
  bam2frag = path.join(settings.ROOT_DIR, "scripts", "py", "bam_frag.py")
  cnv = '%s %s'% (sys.executable, bam2frag)

  # convert BAM to internal 'cov' format
  with aggregate(args.sources, converter=cnv, parallel=-1) as source:
    _make_it_so(get_table_id(args.table_id_name), source, args.name, args.descn)

def _make_it_so(table_id, sourcefile, trk_name, trk_descn):
  mgr = Table.objects.get(id=table_id)
  trk_name = refine_track_name(trk_name or mgr.name)
  chromfile = path.join(settings.GENOME_SIZE_DIR, "%s.txt"% mgr.asm.name)
  
  with create_track_tx(mgr, "cov", trk_name, trk_descn) as track:
    rmqname = "%s_%s"% (mgr.id, track.id)
    outdir = path.join(settings.TRACK_DIR, rmqname)
    
    # first, we remove duplicates based on chrom,start,end
    with rmdup(sourcefile, ['1,1', '2n,3n']) as nodup:
      outfile = _bam2cov(rmqname, chromfile, nodup, outdir)
      source = path.join(path.basename(outdir), path.basename(outfile))
      create_metadata(track, source=[source,], series=[{'color': '#fa8072'}])

def _bam2cov(rmq_name, chrom_info, source_file, output_dir):
  ch = ShellChain().context(locals())
  ch.chain('cat {source_file}')
  ch.chain(r"""awk 'BEGIN {{OFS="\t"}} {{ print $1,$2,"[",1; print $1,$3,"]",1 }}'""") 
  return cov_to_ds('max', rmq_name, chrom_info, output_dir, source_file, ch, pileup=True)