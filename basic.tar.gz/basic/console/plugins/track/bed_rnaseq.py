'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.common import get_table_id
from console.plugins.track.common import refine_track_name, cov_to_ds, rmdup, \
  aggregate
from engine.table_core import create_track_tx, create_metadata
from fabi.pytools.shell import ShellChain, split_by_col
from os import path
from table.models import Table
import settings
import sys

def help(): 
  return "Generates RNA-Seq track from BED file"
    
def permissions():
  return ['table.add_track',]

def config(parser):
  parser.add_argument("table_id_name", help="Table ID or name")
  parser.add_argument("sources", nargs="*", default=None, help="Input source")
  parser.add_argument('-s', '--split', action='store_true', help='Separate (+)ve and (-)ve strands')
  parser.add_argument("-n", "--name", help="Track name")
  parser.add_argument("-d", "--descn", help="Track description (default=None)", default=None)
  parser.set_defaults(func=_parser_callback)

def _parser_callback(args):
  with aggregate(args.sources) as source:
    gen_rmq_and_config(get_table_id(args.table_id_name), source, args.name, args.descn, args.split)

# NOTE: also called by methods in other scripts, e.g. bam_rnaseq.py
def gen_rmq_and_config(table_id, sourcefile, trk_name, trk_descn, split=False):
  mgr = Table.objects.get(id=table_id)
  trk_name = refine_track_name(trk_name or mgr.name)
  chromfile = path.join(settings.GENOME_SIZE_DIR, "%s.txt"% mgr.asm.name)
  
  with create_track_tx(mgr, "cov", trk_name, trk_descn) as track:
    rmqname = "%s_%s"% (mgr.id, track.id)
    outdir = path.join(settings.TRACK_DIR, rmqname)
    
    # first, we remove duplicates based on chrom,start,end,splices
    with rmdup(sourcefile, ['1,1', '2n,3n', '12,12']) as nodup:
      if split: # separate positive and negative strands    
        # second, we split the files into 2: positive, negative, and ignore the original

        with split_by_col(nodup, 6) as srcdict:
          srcvals = list()
          signdict = {'+': 'pos', '-': 'neg'}
          for k in ('+', '-'): # must be in the same order as the series metadata below
            suffix = signdict[k]
            label = '%s.%s'% (rmqname, suffix)
            outfile = _bed2cov(label, chromfile, srcdict[k], outdir)
            srcvals.append(path.join(path.basename(outdir), path.basename(outfile)))
         
          create_metadata(track, source=srcvals,  
                          options=dict(opacity=0.3), 
                          series=[{'color': '#080'}, {'color': 'blue', 'negate': True }])
      else: # not split
        label = rmqname
        outfile = _bed2cov(label, chromfile, nodup, outdir)
        srcval = path.join(path.basename(outdir), path.basename(outfile))
        create_metadata(track, source=srcval, series=[{'color': '#fa8072'}])

def _bed2cov(rmq_name, chrom_info, source_file, output_dir):
  py = sys.executable
  splicer = path.join(settings.ROOT_DIR, "scripts", "py", "bed_splice.py")
  ch = (ShellChain().context(locals())
         .chain('{py} {splicer} < {source_file}')
         .chain(r"""awk 'BEGIN {{OFS="\t"}} {{ print $1,$2,"[",1; print $1,$3-1,"]",1 }}'"""))
  
  # we must set the source=None because we're supplying a shellchain 
  return cov_to_ds('max', rmq_name, chrom_info, output_dir, None, ch, pileup=True)
