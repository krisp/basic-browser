'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.common import get_table_id
from console.plugins.track.common import aggregate
from console.plugins.track.bed_rnaseq import gen_rmq_and_config
from fabi.pytools.io import which

def help(): 
  return '''Generates RNA-Seq track from BAM file. 
            Assumes that program bamToBed is present on the PATH.
            If URL is given as source, it needs 'curl' to be installed.
            '''

def permissions():
  return ['table.add_track',]

def config(parser):
  parser.add_argument('table_id_name', help='Table ID or name')
  parser.add_argument('sources', nargs='*', default=None, help='Input source')
  parser.add_argument('-s', '--split', action='store_true', help='Separate (+)ve and (-)ve strands')
  parser.add_argument('-n', '--name', help='Track name')
  parser.add_argument('-d', '--descn', help='Track description (default=None)', default=None)
  parser.set_defaults(func=_parser_callback)

def _parser_callback(args):
  if not which('bamToBed'):
    raise Exception("Program 'bamToBed' not found. " +
                    "Please install software package BEDTools and make sure it's referred to in PATH")
  
  bam2bed = 'bamToBed -bed12'
  # convert BAM to internal 'cov' format
  with aggregate(args.sources, converter=bam2bed) as source:
    # call function to upload BED into RNA-Seq track
    gen_rmq_and_config(get_table_id(args.table_id_name), source, args.name, args.descn, args.split)
