'''
Created on Jun 10, 2011

@author: Fabianus
'''
from fabi.pytools.shell import get_dir_size
from table.models import Metadata
from termcolor import colored
import json
import os
import settings
import shutil
import sys

def help():
  return "Deletes orphaned external files (no corresponding Track entry in the database)"

def permissions():
  return ['table.delete_track',]

def config(sub):
  sub.set_defaults(func=hsekeep_tracks)

def _add_whitelist(db_sources, src):
  if src and src[0] != '/': src = os.path.join(settings.TRACK_DIR, src)
  db_sources.add(os.path.dirname(src)) # ignore the file name

def hsekeep_tracks(args):
  db_sources = set()
  for meta in Metadata.objects.filter(key__startswith='source'):
    try: # accommodate different ways source is specified
      jsobj = json.loads(meta.value)
      if type(jsobj) == list:
        for src in jsobj:
          if type(src) == dict: # special case: e.g. CountIF track has 3 sets of files {abs,rel,mix} in one series
            for x in src.itervalues(): _add_whitelist(db_sources, x)
          else:
            _add_whitelist(db_sources, src)
      elif type(jsobj) == dict:
        for src in jsobj.itervalues(): _add_whitelist(db_sources, src)
      elif type(jsobj) == str or type(jsobj) == unicode:
        _add_whitelist(db_sources, jsobj)
    except:
      _add_whitelist(db_sources, meta.value) # normal string

  fs_sources = set(os.path.join(settings.TRACK_DIR, src) for src in os.listdir(settings.TRACK_DIR))

  no_fs = [src for src in (db_sources - fs_sources) if not os.path.exists(src)]
  if no_fs:
    print colored('\nNot found in filesystem:', 'yellow')
    for src in sorted(no_fs):
      print '-', src

  no_db = fs_sources - db_sources
  if no_db:
    print colored('\nNot found in database:', 'yellow')
    for src in sorted(no_db):
      print '-', src, get_dir_size(src, True)
  
    print '\nDelete all directories not found in database %s y/[n]? '% colored('(THERE IS NO TURNING BACK)', 'red'),
    if sys.stdin.readline().rstrip().upper() == 'Y':
      for src in no_db: shutil.rmtree(src)
      print '%d directories deleted.'% len(no_db)
    else:
      print 'No directories deleted.'

