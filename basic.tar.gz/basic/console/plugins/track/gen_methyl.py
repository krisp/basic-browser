'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.common import get_table_id
from console.plugins.track.common import refine_track_name
from engine.table_core import create_track_tx, create_metadata
from fabi.pytools.shell import Shell
from os import path
from table.models import Table
import settings
import sys

def help():
    return "Generates 2 tracks to visualize %%methylated C"
    
def permissions():
    return ['table.add_track',]

def config(parser):
    parser.add_argument("table_id_name", help="Table ID or name")
    parser.add_argument('source', nargs='?', help='Input source containing number of tags and %%methylated C')
    parser.add_argument('--abs', type=int, help='Minimum number of tags to be considered significant', required=True)
    parser.add_argument('--rel', type=int, help='Minimum %%methylated C to be considered significant (0-100%%)', required=True)
    parser.add_argument('-n', '--name', help='Track name')
    parser.add_argument('-d', '--descn', help='Track description (default=None)', default=None)
    parser.set_defaults(func=gen_methyl)

def gen_methyl(args):
    if not args.source:
        source = None if sys.stdin.isatty() else sys.stdin # isatty=False --> there's redirection
        print _make_3countif_tracks(get_table_id(args.table_id_name), source, args.abs, args.rel, args.name, args.descn)
    else:
        with open(args.source) as source:
            print _make_3countif_tracks(get_table_id(args.table_id_name), source,    args.abs, args.rel, args.name, args.descn)

def _make_3countif_tracks(table_id, source, abs_minsup, rel_minsup, trk_name=None, trk_descn=None):
    '''source = case of
           None => read from database (NOT SUPPORTED)
           "-"  => read from stdin
           _    => read from the given filename
    '''
    
    mgr = Table.objects.get(id=table_id)
    trk_name = refine_track_name(trk_name or mgr.name)
    with create_track_tx(mgr, "cif", trk_name, trk_descn) as track1:
        with create_track_tx(mgr, "cif", "%s (normalized)"% trk_name, trk_descn) as track2:
            
            cifname = "%s_%s"% (mgr.id, track1.id)
            meta_val = [{  # must be synchronized with build_cif.py
                           'abs': path.join(cifname, cifname + ".abs.cif"),
                           'rel': path.join(cifname, cifname + ".rel.cif"), 
                           'mix': path.join(cifname, cifname + ".mix.cif"),
                       }]
    
            # metadata for track1
            create_metadata(track1, source=meta_val, 
                series=[{
                    'abs_minsup': abs_minsup, 'rel_minsup': rel_minsup, 'color': 'blue',
                    'formula': 'function(a,r,m) { return r; }'
                }])

            # metadata for track2 (normalized)                                                                                                
            create_metadata(track2, source=meta_val, 
                series=[{
                    'abs_minsup': abs_minsup, 'rel_minsup': rel_minsup, 'color': 'red',
                    'formula': 'function(a,r,m) { return (a!=0 ? m*1.0/a : 0); }'
                }],
                
                options={
                    'yaxis': { 
                        'max': 1,                
                        'tickFormatter': 'function (val, axis) { return Math.round(val*10000)/100 + "%"; }' 
                    } 
                })
                
            chromfile = path.join(settings.GENOME_SIZE_DIR, "%s.txt"% mgr.asm.name)
            gen_cif(mgr, cifname, chromfile, source, abs_minsup)

def gen_cif(mgr, cifname, chromfile, source, abs_minsup):
    splitter = path.join(settings.PYSCRIPT_DIR, 'splitbycol.py')
    build_cif = path.join(settings.ROOT_DIR, 'console', 'build_cif.py')
    outdir = path.join(settings.TRACK_DIR, cifname)
    
    sh = Shell()        
    try:
        sh("mkdir -p '%s'"% outdir)
    except: pass
    
    # we assume the input is a in format chrom,start,end,#meth,#nonmeth,%meth
    cmd = r'''awk 'BEGIN {{ OFS="\t" }} {{ print $1,$2,$4+$5,$6 }}'
               | {p} {splitter} 1 
               | {p} {build_cif} '{cifname}' '{chromfile}' {abs_minsup} -o {outdir}'''.format(p=sys.executable, **locals())

    try:
        if not source:
            raise Exception("Sorry pal, but I don't support database table as source")
        elif type(source) == file:
            sh(cmd, input=source)
        else:
            raise Exception('Invalid source: %s'% source)
    except Exception as e:
        print "stdout: ", e.stdout
        print "stderr: ", e.stderr
        raise
