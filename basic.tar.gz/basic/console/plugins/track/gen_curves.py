'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.common import get_table_id
from console.plugins.track.common import refine_track_name, aggregate
from console.plugins.track.gen_xpets import gen_xpets
from engine.table_core import create_track_tx, create_metadata
from os import path
from settings import GENOME_SIZE_DIR
from table.models import Table
from util.mongo import BASICollection

def help():
  return 'Generates curve track (input identical to [pcls])'
  
def permissions():
  return ['table.add_track',]

def config(parser):
  parser.add_argument("table_id_name", help="Table ID or name")
  parser.add_argument('source', nargs='?', default=None, help='Input source (default=read from database)')
  parser.add_argument('-c', '--color', default='red', help='Default: red')
  parser.add_argument('-n', '--name', help='Track name')
  parser.add_argument('-d', '--descn', help='Track description (default=None)', default=None)
  parser.set_defaults(func=_parser_callback)
  
def _parser_callback(args):
  with aggregate(args.source, allow_null=True) as source:
    _gen_track_curve(get_table_id(args.table_id_name), args.color, source, args.name, args.descn)
    
def _gen_track_curve(table_id, color, source, trk_name, trk_descn):
  table = Table.objects.get(id=table_id)
  trk_type = 'curv' # must be defined in table.Track.TYPES
  ds_type = 'paired'
  trait = 'interval_paired'
  
  if not BASICollection(table_id).has_traits(trait):
    raise Exception('Data must have trait [{0}]'.format(trait))
  
  trk_name = refine_track_name(trk_name or table.name)
  with create_track_tx(table, trk_type, trk_name, trk_descn) as track:
    # create fresh new data structure
    tagname = 'trk_{track.id}'.format(**locals())
    meta_val = path.join(tagname, '%s.%s'% (tagname, ds_type))

    create_metadata(track, source=meta_val, 
                    options={ 'yaxis': { 'log': 10 } }, 
                    series=[{ 'color': color }])
    chromfile = path.join(GENOME_SIZE_DIR, '%s.txt'% table.asm.name)
    gen_xpets(table, tagname, chromfile, ds_type, trait, source)
