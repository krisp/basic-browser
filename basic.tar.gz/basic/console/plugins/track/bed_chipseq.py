'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.common import get_table_id
from console.plugins.track.common import refine_track_name, cov_to_ds, rmdup, \
  aggregate
from engine.table_core import create_track_tx, create_metadata
from fabi.pytools.shell import ShellChain
from os import path
from table.models import Table
import settings

def help(): 
  return "Generates ChIP-Seq track from BED file"
  
def permissions():
  return ['table.add_track',]

def config(parser):
  parser.add_argument("table_id_name", help="Table ID or name")
  parser.add_argument("sources", nargs="*", default=None, help="Input source")
  parser.add_argument("-n", "--name", help="Track name")
  parser.add_argument("-d", "--descn", help="Track description (default=None)", default=None)
  parser.add_argument("--no-pile", help="Do not perform pile-over",  action='store_true')
  parser.set_defaults(func=_parser_callback)

def _parser_callback(args):
  with aggregate(args.sources) as source:
    _make_it_so(get_table_id(args.table_id_name), source, args.name, args.descn, not args.no_pile)

def _make_it_so(table_id, sourcefile, trk_name, trk_descn, do_pileover):
  mgr = Table.objects.get(id=table_id)
  trk_name = refine_track_name(trk_name or mgr.name)
  chromfile = path.join(settings.GENOME_SIZE_DIR, "%s.txt"% mgr.asm.name)
  
  with create_track_tx(mgr, "cov", trk_name, trk_descn) as track:
    rmqname = "%s_%s"% (mgr.id, track.id)
    outdir = path.join(settings.TRACK_DIR, rmqname)
    
    # first, we remove duplicates based on chrom,start,end
    with rmdup(sourcefile, ['1,1', '2n,3', '5,5']) as nodup:
      outfile = _bed2cov(rmqname, chromfile, nodup, outdir, do_pileover)
      source = path.join(path.basename(outdir), path.basename(outfile))
      create_metadata(track, source=[source,], series=[{'color': '#fa8072'}])

def _bed2cov(rmq_name, chrom_info, source_file, output_dir, pileup):
  ch = ShellChain().context(locals())
  ch.chain('cat {source_file}')
  if pileup:
    # for pileup mode, we assume every entry is worth 1
    ch.chain(r"""awk 'BEGIN {{OFS="\t"}} {{ print $1,$2,"[",1; print $1,$3-1,"]",1 }}'""") 
  else:
    # for non-pileup, we don't use end position, and use score as the tag weight
    ch.chain(r"cut -f 1-2,5") 
    
  # we must set the source=None because we're supplying a shellchain
  return cov_to_ds('max', rmq_name, chrom_info, output_dir, None, ch, pileup)