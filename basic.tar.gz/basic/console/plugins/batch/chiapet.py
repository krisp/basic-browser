'''
Created on Apr 25, 2012

@author: mulawadifh
'''
import colorsys
import json
from os import path

from browser.models import Library
from common import *
from engine.table_core import create_track_tx, create_metadata
from fabi.pytools.io import opentemp, ouvrir
from table.models import Metadata
from engine import table_load, table_core


TRK_CFG_TEMPL = '''
(function() {
    var hsv2rgb = function(a,b,c) {
        var d=0,e=0,f=0,g=Math.floor(a*6),h=a*6-g,i=c*(1-b),j=c*(1-h*b),k=c*(1-(1-h)*b);
        switch(g%6) {
            case 0: d=c,e=k,f=i; break;
            case 1: d=j,e=c,f=i; break;
            case 2: d=i,e=c,f=k; break;
            case 3: d=i,e=j,f=c; break;
            case 4: d=k,e=i,f=c; break;
            case 5: d=c,e=i,f=j; break;
        }
        return'rgb('+Math.round(d*255)+','+Math.round(e*255)+','+Math.round(f*255)+')';
    },
    colorFun = function(args) {
        var size = args.element.score;
        return hsv2rgb(|hue|, Math.min(1, 0.3 + size*0.05), |val|/2);
    },
    fillColorFun = function(args) {
        var size = args.element.score;
        return hsv2rgb(|hue|, Math.min(1, 0.3 + size*0.05), Math.max(|val|, 1-size*0.02));
    };
    return {
        colors: {
            head: colorFun,
            tail: colorFun,
            line: colorFun,
            text: 'black',
            _: fillColorFun
        }
    };
})()
'''.strip()

_COLORS = {
    'aqua': '#00ffff',
    'black': '#000000',
    'blue': '#0000ff',
    'fuchsia': '#ff00ff',
    'gray': '#808080',
    'green': '#008000',
    'lime': '#00ff00',
    'maroon': '#800000',
    'navy': '#000080',
    'olive': '#808000',
    'orange': '#ffa500',
    'purple': '#800080',
    'red': '#ff0000',
    'silver': '#c0c0c0',
    'teal': '#008080',
    'white': '#ffffff',
    'yellow': '#ffff00'
}


def _color2hsv(color):
    color = _COLORS.get(color, color)
    if color[0] != '#':
        raise Exception('Color not recognized: [%s]' % color)
    color = color[1:]
    if len(color) == 3:
        color = '%s0%s0%s0' % tuple(color)
    r = int(color[0:2], 16) / 255.0
    g = int(color[2:4], 16) / 255.0
    b = int(color[4:6], 16) / 255.0
    return colorsys.rgb_to_hsv(r, g, b)


def help():
    return 'Upload the output of ChIA-PET pipeline into BASIC'


def config(parser):
    parser.add_argument('chia_dir', help='Directory containing output files of ChIA-PET pipeline')
    parser.add_argument('asm', help='Genome assembly')
    parser.add_argument('-c', '--cell', help='Cell line name', required=True)
    parser.add_argument('-f', '--factor', help='Target factor name', required=True)
    parser.add_argument('-m', '--minsup', help='Minimal cluster size [2]', type=int, default=2)
    parser.add_argument('-l', '--lib', help='Library name to which the new tracks will belong')

    parser.add_argument('-O', '--owners', help='Owner IDs; comma-separated []', default='')
    parser.add_argument('-G', '--groups', help='Group IDs; comma-separated [chiapet]', default='chiapet')

    parser.add_argument('--color', help='Color [red]', default='red')
    parser.set_defaults(func=_main)


def _test(args):
    tests = ['red', 'green', 'blue', '#123', '#867355', '#CE7100']
    for t in tests:
        print t, _color2hsv(t)


def _get_libname(raw_libname):
    libname = raw_libname
    if '_' in libname:
        libname = libname.split('_')[0]
    if libname[-1] in 'CMT':
        libname = libname[:-1]
    return libname


def _find_file(fname):
    if path.exists(fname):
        return fname
    elif path.exists('%s.gz' % fname):
        return '%s.gz' % fname
    elif path.exists('%s.bz2' % fname):
        return '%s.bz2' % fname
    else:
        raise Exception('Not found: %s' % fname)


def _determine_prog(fname):
    if fname.endswith('.bz2'):
        return 'bunzip2 -c'
    elif fname.endswith('.gz'):
        return 'gunzip -c'
    else:
        return 'cat'


def _main(args):
    chia_dir = path.normpath(path.realpath(args.chia_dir))
    raw_libname = path.basename(chia_dir)
    basic_lib = args.lib if args.lib else _get_libname(raw_libname)

    # create library
    lib_json = json.loads(runscript(LIB, 'create', basic_lib, cell=args.cell, factor=args.factor, tech='ChIA-PET',
                                    owners=args.owners, groups=args.groups, json=None, _stdin='/dev/null'))

    # create table for peaks and load
    peakfile = _find_file(path.join(chia_dir, '{raw_libname}.peak'.format(**locals())))

    with table_core.create_table_tx('{raw_libname} Peaks'.format(**locals()), args.asm, None, basic_lib) as peak_tab:
        with ouvrir(peakfile, buffered=True) as peakload:
            table_load.load(peakload.name, peak_tab.id, preset='chiapet.peak', forceful=True)

    # create PET2+ cluster file
    clusfile = _find_file(path.join(chia_dir, '{raw_libname}.cluster'.format(**locals())))
    with opentemp() as cluspetx:
        prog = _determine_prog(clusfile)
        Shell('''
            {prog} {clusfile}
            | awk '{{ if ($11>={args.minsup}) print }}'
            > {cluspetx.name}
        '''.format(**locals()))

        # create table for clusters and load
        with table_core.create_table_tx('{raw_libname} Clusters (PET{args.minsup}+)'.format(**locals()), args.asm, None,
                                        basic_lib) as clus_tab:
            table_load.load(cluspetx.name, clus_tab.id, preset='chiapet.itx', forceful=True)

            # create loop track for clusters
            with create_track_tx(clus_tab, 'curv',
                                 '{raw_libname} Loops (PET{args.minsup}+)'.format(**locals())) as track:
                create_metadata(track, options={'yaxis': {'log': 10}}, series=[{'color': args.color}])

            # create anchor track for clusters
            with create_track_tx(clus_tab, 'pcls',
                                 '{raw_libname} Anchors (PET{args.minsup}+)'.format(**locals())) as track:
                h, _, v = _color2hsv(args.color)
                md = Metadata(key='options', track=track)
                md.value = TRK_CFG_TEMPL.replace('|hue|', str(h)).replace('|val|', str(v))
                md.save()

    # create temp file from cPETs
    cpetfile = _find_file(path.join(chia_dir, '{raw_libname}.cpet'.format(**locals())))
    with opentemp() as cpetcov:
        prog = _determine_prog(cpetfile)
        Shell('''
            {prog} {cpetfile}
            | awk 'BEGIN {{ OFS="\t" }}
                         {{ if ($2<$5) print $1,$2,$5,1; else print $1,$5,$2,1; }}'
            > {cpetcov.name}
        '''.format(**locals()))

        # create da coverage track (takes a long time)
        runscript(TRK, 'gen_cov', 'max', peak_tab, cpetcov.name,
                  name='{raw_libname} Binding Sites'.format(**locals()),
                  color=args.color, json=None)
