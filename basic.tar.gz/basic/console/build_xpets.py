'''
Created on Jan 13, 2011
@author: fabianus
'''

from argparse import ArgumentParser
from fabi.pytools.shell import count_line_num
from gis.basic import xpets
import os
import shutil
import sys
import tempfile
import yaml

def main(args):
  # read chromosome sizes
  chroms = list()
  with open(args.chromfile) as f:
    for line in f:
      p, _ = line.strip().split('\t')
      chroms.append(p)
  
  if not os.path.exists(args.outdir):
    os.mkdir(args.outdir)

  petsout = os.path.join(args.outdir, "%s_pets.out"% args.libname)
  selectout = os.path.join(args.outdir, "%s_select.out"% args.libname)
  
  input_ = args.inputfile
  petcount = count_line_num(input_)

  tmpdir = tempfile.mkdtemp()
  try:
    #inputfile, output1, output2, chromfile, maxpets, tmpdir
    if args.type == 'single':
      xpets.pets_create_single(input_, petsout, selectout, args.chromfile, petcount, tmpdir)
    elif args.type == 'paired':
      xpets.pets_create(input_, petsout, selectout, args.chromfile, petcount, tmpdir)
    else:
      raise Exception("Huh!? This line shouldn't ever get executed.")

  finally:
    shutil.rmtree(tmpdir)
       
  # create rmq file
  with open(os.path.join(args.outdir, "%s.%s"% (args.libname, args.type)), "w") as out:
    petsfile = dict()
    petsfile["__lib__"] = args.libname
    petsfile["chroms"] = chroms
    petsfile["pets"] = "%s_pets.out"% args.libname
    petsfile["select"] = "%s_select.out"% args.libname
    petsfile["taglen"] = args.taglen
    petsfile["type"] = args.type
    petsfile["version"] = 2 # with ID support
    out.write(yaml.dump(petsfile))

if __name__ == '__main__':
  parser = ArgumentParser()
  parser.add_argument("libname", help="Library name")
  parser.add_argument("inputfile", help="Input file")
  parser.add_argument("chromfile", help="File containing info on chromosome length")
  parser.add_argument("type", choices=['single', 'paired'], help="Single/paired-end tags")
  parser.add_argument("taglen", type=int, help="Tag length in base pairs")
  parser.add_argument("-o", "--outdir", help="Output directory (curdir)", default=".")
  args = parser.parse_args()
  sys.exit(main(args))
  