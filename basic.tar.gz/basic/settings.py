from django.utils.importlib import import_module
from os import path
import os
import pymongo
import sys

# this will set os.environ['LANG'] = 'C'
# the speedup effect for Linux 'sort' is around 10x, but in some cases it may be desirable
# to keep the system's default setting (usually LANG=en_US.UTF-8)
FAST_SORT = True

def configure():
    '''To be called by all scripts that are invoked directly from shell'''
    os.environ["DJANGO_SETTINGS_MODULE"] = "basic.settings"
    _dir = path.join(path.dirname(path.abspath(path.realpath(__file__))), path.pardir)
    for p in ('', 'basic',):
        q = path.abspath(path.join(_dir, p))
        if q not in sys.path: sys.path.append(q)
    if FAST_SORT:
        os.environ['LANG'] = 'C'

DEBUG = True
TEMPLATE_DEBUG = DEBUG
BASIC_DEBUG = 'BASIC_DEBUG' in os.environ

ADMINS = (
    ('Fabianus Mulawadi', 'mulawadifh@gis.a-star.edu.sg'),
)

MANAGERS = ADMINS

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'basicdb',
        'USER': 'basicuser',
        'PASSWORD': '',
        'HOST': '',
        'PORT': '',
    }
}

_mongoconn_default = pymongo.Connection(DATABASES['default']['HOST'] or 'localhost')
MONGODBS = {
    'default': _mongoconn_default[DATABASES['default']['NAME']]
}

# Local time zone for this installation. Choices can be found here:
# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
# although not all choices may be available on all operating systems.
# On Unix systems, a value of None will cause Django to use the same
# timezone as the operating system.
# If running in a Windows environment this must be set to the same as your
# system time zone.
TIME_ZONE = 'Asia/Singapore'

# Language code for this installation. All choices can be found here:
# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'en-us'

SITE_ID = 1

# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = False

# If you set this to False, Django will not format dates, numbers and
# calendars according to the current locale
USE_L10N = True

ROOT_DIR = os.path.normpath(os.path.dirname(__file__))

# For cases where the application is not hosted on root URL, e.g. http://example.org/basic
# It must have slash in front, and no slash at the end
APP_URL = ''

# Absolute path to the directory that holds media.
# Example: "/home/media/media.lawrence.com/"
STATIC_URL = '{0}/static/'.format(APP_URL)

LOGIN_URL = '{0}/accounts/login/'.format(APP_URL)
LOGIN_REDIRECT_URL = '{0}/'.format(APP_URL)

# Make this unique, and don't share it with anybody.
SECRET_KEY = 'b%r^z*d(%#4fff36)82hs-8)w0l=)n*h)byqcq+0i@lm)0av4a'

# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
#   'django.template.loaders.eggs.Loader',
)

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
)

ROOT_URLCONF = 'basic.urls'

TEMPLATE_DIRS = (
    # Put strings here, like "/home/html/django_templates" or "C:/www/django/templates".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
    os.path.join(ROOT_DIR, 'templates')
)

INSTALLED_APPS = [
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
    'django.contrib.admin',
    'django.contrib.humanize',
    'south',

    'basic.browser',
    'basic.fserve',
    'basic.table',
]

# contains special fast-access data structure files
# naming convention: TRACK_DIR/{tableid}_{trackid}
TRACK_DIR = os.path.join(ROOT_DIR, "data/tracks")

# location of files with info on genome size for each assembly
GENOME_SIZE_DIR = os.path.join(ROOT_DIR, "data/genome/size")

# files with info on chromosome band colorings
CHROM_BAND_DIR = os.path.join(ROOT_DIR, "data/genome/chrband")

# location of files containing genome sequences
GENOME_ACGT_DIR = os.path.join(ROOT_DIR, "data/genome/acgt")

# types of tables supported
DATA_FORMATS = os.path.join(ROOT_DIR, "config/formats.yaml")

# directory containing static content; best served with Apache
STATIC_DIR = os.path.join(ROOT_DIR, 'static')
STATIC_ROOT = STATIC_DIR # <-- recognized by django

PYSCRIPT_DIR = os.path.join(ROOT_DIR, 'scripts', 'py')
