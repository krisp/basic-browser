'''
Extract RNA-Seq splices from BED file

Output format (tab-separated):
chrom, start splice, end splice

Created on Jun 14, 2011

@author: mulawadifh
'''
from itertools import izip
import sys

if __name__ == '__main__':
  for line in sys.stdin:
    arr = line.rstrip().split()
    chrom, start, end = arr[0], int(arr[1]), int(arr[2]) 
    for wid, dist in izip((int(p) for p in arr[10].split(',')), 
                         (int(q) for q in arr[11].split(','))):
      begin = start+dist
      print '%s\t%d\t%d'% (chrom, begin, begin+wid)