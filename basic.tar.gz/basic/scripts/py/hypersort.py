'''
Performs sorting with hypercube topology
By default, it creates temporary files at memory-backed filesystem (/dev/shm),
so it may fail if the file is too big.

Created on Jun 15, 2011

@author: mulawadifh
'''

from argparse import ArgumentParser
from fabi.pytools.parallel import hypersort
import sys

if __name__ == "__main__":
  parser = ArgumentParser()
  parser.add_argument("input", help="Name of file to sort")
  parser.add_argument("param", default="", help="Arguments to be passed to UNIX sort")
  parser.add_argument("-o", "--output", help="Output file")
  parser.add_argument("-p", "--proc", type=int, default=-1, 
                      help="Max number of processors to use in parallel. By default, it checks "+
                           "system load and uses as many processors as possible (recommended: power of 2)")
  parser.add_argument("-n", "--nlines", type=int, default=1000000, help="Number of lines per batch")
  parser.add_argument("--tmp", default="/dev/shm", help="Temporary directory to use (default=/dev/shm)")
  args = parser.parse_args()
  hypersort(args.input, args.output or sys.stdout, args.param, args.proc, args.nlines, tmpdir=args.tmp)
  