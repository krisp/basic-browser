from setuptools import setup, Extension
from os import path

setup(
  name         = "fabi-pytools",
  version      = "0.1",
  description  = "Fabi's Assorted Utility Functions",
  author       = "Fabianus Mulawadi",
  author_email = "fabianus_soc@hotmail.com",
  package_dir  = { "": "src" },
  packages     = ['fabi', 'fabi.pytools'], 
  ext_modules  = [
  ],
  py_modules  = [
    "fabi.pytools.format",
    "fabi.pytools.io",
    "fabi.pytools.parallel",
    "fabi.pytools.run",
    "fabi.pytools.shell",
    "fabi.pytools.term",
    "fabi.pytools.text",
  ],
  install_requires = [
    "termcolor",
  ],
)
