'''
Created on Jul 27, 2012

@author: mulawadifh
'''
from django.conf.urls import patterns

urlpatterns = patterns('basic.fserve.views',
  (r'^gridfs/(?P<file_id>.*)/$', 'get_gridfs'),
  (r'^get/$', 'get_file'),
  (r'^([\d\w\ \-]+)/$', 'list_files'),
)
