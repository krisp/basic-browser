'''
This script is not to be called directly.
It is supposed to be invoked by basic/setup.py

Created on Oct 5, 2011

@author: mulawadifh
'''
from argparse import ArgumentParser
from fabi.pytools.shell import Shell
from os import path
from setup import info, warn
import distutils.sysconfig
import os
import sys

BASIC_WSGI_FILE = 'basic.wsgi'
APACHE_CONF_FILE = 'basic.conf'

_BASIC_WSGI_TEMPL = '''
import os
import sys

prev_sys_path = set(sys.path) # Remember original sys.path 

# Add virtualenv site-packages
import site 
site.addsitedir('{site_conf_dir}')

# Reorder sys.path so new directories at the front.
new_sys_path = [] 
for item in list(sys.path): 
    if item not in prev_sys_path: 
        new_sys_path.append(item) 
        sys.path.remove(item) 

sys.path[:0] = new_sys_path 
sys.path[:0] = ['{basic_pardir}', '{basic_dir}',]

os.environ['DJANGO_SETTINGS_MODULE'] = '{basic}.settings'
os.environ['PYTHON_EGG_CACHE'] = '{egg_dir}'

import django.core.handlers.wsgi
application = django.core.handlers.wsgi.WSGIHandler()
'''

_BASIC_VHOST_TEMPL = '''
Listen {port}
<VirtualHost *:{port}>
    ServerName {server_name}
    ServerAdmin {server_admin}

    ProxyRequests Off
    <Proxy *>
        Order deny,allow
        Allow from all
    </Proxy>

    DocumentRoot {basic_dir}

    Alias /static/admin {django_dir}/contrib/admin/static/admin
    Alias /static {basic_dir}/static

    WSGIScriptAlias / {basic_dir}/{wsgi_file}
    ErrorLog {basic_dir}/log/basic.error.log

    LogLevel info
    CustomLog {basic_dir}/log/basic.access.log combined
</VirtualHost>
'''


def _gen_wsgi_conf(args):
    basic_dir = path.abspath(os.curdir)
    if not path.exists(BASIC_WSGI_FILE) or args.force:
        info('Generating %s' % BASIC_WSGI_FILE)

        with open(BASIC_WSGI_FILE, 'w') as out:
            out.write(_BASIC_WSGI_TEMPL.format(
                basic_pardir=path.normpath(path.join(basic_dir, path.pardir)),
                basic_dir=basic_dir,
                egg_dir=path.join(basic_dir, '.python-eggs'),
                basic=path.basename(basic_dir),
                site_conf_dir=distutils.sysconfig.get_python_lib(),
            ))

        info('DONE')
    else:
        warn('%s already exists. Use --force to overwrite' % BASIC_WSGI_FILE)


def _gen_vhost_conf(args):
    import django

    basic_dir = path.abspath(os.curdir)
    if not path.exists(APACHE_CONF_FILE) or args.force:
        info('Generating %s' % APACHE_CONF_FILE)
        with open(APACHE_CONF_FILE, 'w') as out:
            out.write(_BASIC_VHOST_TEMPL.format(
                basic_dir=basic_dir,
                wsgi_file=BASIC_WSGI_FILE,
                django_dir=path.dirname(django.__file__),
                port=args.port,
                server_name=args.server_name,
                server_admin=args.admin_email,
            ))
        info(
            'Please note that you need to move %s to your Apache config directory, '
            'located in either ' % APACHE_CONF_FILE +
            '/etc/apache2/conf.d/ or /etc/httpd/conf.d/. ' +
            'Also, with the default config, '
            'the Apache log files will be generated at %s. ' % path.join(basic_dir, 'log') +
            'You need to either change the location, or ensure that the directory is writable by Apache HTTP server')
        info('DONE')
    else:
        warn('%s already exists. Use --force to overwrite' % APACHE_CONF_FILE)


def _copy_extsds(args):
    sh = Shell()
    libdir = distutils.sysconfig.get_python_lib()
    outdir = path.join(libdir, 'extsds')
    force_flag = '-f' if args.force else ''

    if not path.exists(outdir):
        os.mkdir(outdir)

    sh('cp {force_flag} {files} {outdir}'.format(files=path.join(args.bin_dir, '*'), **locals()))
    sh('touch {initpy}'.format(initpy=path.join(outdir, '__init__.py')))


if __name__ == '__main__':
    parser = ArgumentParser()
    subpar = parser.add_subparsers()
    parser.add_argument('-F', '--force', action='store_true', help='Overwrite any existing directory/file')

    sub = subpar.add_parser('vhost')
    sub.add_argument('--port', type=int, help='Port number to be used in Apache config (8001)', default=8001)
    sub.add_argument('--server-name', help='Server name to be used in Apache config (example.com)',
                     default='example.com')
    sub.add_argument('--admin-email', help='Email address to be used in Apache config (you@example.com)',
                     default='you@example.com')
    sub.set_defaults(func=_gen_vhost_conf)

    sub = subpar.add_parser('wsgi')
    sub.set_defaults(func=_gen_wsgi_conf)

    sub = subpar.add_parser('extsds')
    sub.add_argument('bin_dir', help='Directory containing binary files of extsds')
    sub.set_defaults(func=_copy_extsds)

    args = parser.parse_args()
    args.func(args)
