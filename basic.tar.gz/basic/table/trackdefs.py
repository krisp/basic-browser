'''
Created on Oct 3, 2011

@author: mulawadifh
'''
import json

class _Property(object):
  def __init__(self, type_, editor=None, default=None, size=None):
    self.type_ = type_ # python type
    self.editor = editor # e.g. slider, colorpicker
    self.default = default
    self.size = size

class TrackEncoder(json.JSONEncoder):
  def default(self, obj):
    t = type(obj)
    if t.__name__ == '_Meta':
      attrs = (_ for _ in dir(obj) if not _.startswith('__'))
      return dict((_,getattr(obj,_)) for _ in attrs)
    elif t == _Property:
      return {'type': str(obj.type_)[7:-2], 
              'editor': obj.editor, 
              'default': obj.default,
              'size': obj.size}
    return super(TrackEncoder, self).default(obj)

class _Meta(type):
  '''
  This metaclass allows us to (ab)use python class declaration
  to define tracks with inherited properties from "abstract" tracks
  '''
  def __new__(cls, clsname, bases, attrs):
    module = attrs.pop('__module__')
    new_class = super(_Meta, cls).__new__(cls, clsname, bases, {'__module__': module})

    for base in bases:
      for name, value in base.__dict__.iteritems():
        if name.startswith('_'): continue
        if name == 'properties':
          if hasattr(new_class, name):
            copy = dict()
            copy.update(getattr(new_class, name))
            copy.update(value)
            setattr(new_class, name, copy)
          else:
            setattr(new_class, name, value)
        else:
          setattr(new_class, name, value)
    
    for name, value in attrs.iteritems():
      if name == 'properties':
        if hasattr(new_class, name):
          copy = dict()
          copy.update(getattr(new_class, name))
          copy.update(value)
          setattr(new_class, name, copy)
        else:
          setattr(new_class, name, value)
      else:
        setattr(new_class, name, value)

    if not 'verbose_name' in attrs:
      setattr(new_class, 'verbose_name', new_class.__name__)

    return new_class
  
  def __repr__(self):
    return '[{name}] {dict_}'.format(name=self.__name__, dict_=str(self.__dict__))

class _BaseDef(object):
  __metaclass__ = _Meta
  properties = dict()

### ---------------------------------------------------------------------------

class _Coverage(_BaseDef):
  properties = {
    'options': {
      'yaxis': {
        'min': _Property(float),
        'max': _Property(float),
        'log': _Property(int),
        'tickLength': _Property(int),
      },          
      'opacity': _Property(float),  
    },
    'series' : {
      'color': _Property(str, 'color'),
      'negate': _Property(bool),
    }                                          
  }

class CoverageMax(_Coverage):
  name = 'cov'
  verbose_name = 'Coverage (max)'

class CoverageAvg(_Coverage):
  name = 'avg'
  verbose_name = 'Coverage (avg)'

class CountIf(_Coverage):
  name = 'cif'

class Curve(_BaseDef):
  name = 'curv'
  properties = {
    'options': {
      'yaxis': {
        'min': _Property(float),
        'max': _Property(float),
        'log': _Property(int),
        'tickLength': _Property(int),
      },          
      'opacity': _Property(float),  
      'outline': _Property(str, 'outline'),
      'outbound': {
        'show': _Property(bool),
      },
    },
    'series' : {
      'color': _Property(str, 'color'),
    }                                          
  }

### ---------------------------------------------------------------------------

class _Block(_BaseDef):
  properties = {
    'options': {
      'label': _Property(str),
      'showLabel': _Property(bool),
      'glyph': {
        'height': _Property(int),
        'margin': {
           'top': _Property(int),
           'right': _Property(int),
           'bottom': _Property(int),
           'left': _Property(int),        
        },        
      }
    }
  }

class Genes(_Block):
  name = 'gene'

class SingleCluster(_Block):
  name = 'scls'
  properties = {
    'options': {
      'label': _Property(str, size='large'),
      'tooltip': _Property(str, size='textarea'),
      'showLabel': _Property(bool),
      'glyph': {
        'height': _Property(int),
        'margin': {
           'top': _Property(int),
           'right': _Property(int),
           'bottom': _Property(int),
           'left': _Property(int),        
        },        
      }
    }
  }

class PairedClusters(_Block):
  name = 'pcls'
  properties = {
    'options': {
      'label': _Property(str, size='large'),
      'tooltip': _Property(str, size='textarea'),
      'showLabel': _Property(bool),
      'glyph': {
        'height': _Property(int),
        'margin': {
           'top': _Property(int),
           'right': _Property(int),
           'bottom': _Property(int),
           'left': _Property(int),        
        },        
      }
    }
  }

class SingleTag(_Block):
  name = 'stag'

class PairedTags(_Block):
  name = 'ptag'

class LetterTag(_Block):
  name = 'ltag'

### ---------------------------------------------------------------------------

class TransFactor(_BaseDef):
  name = 'trfac'
  verbose_name = 'Transcription Factors'

class SNP(_BaseDef):
  name = 'snp'
  verbose_name = 'Singlenucleotide Polymorphism'

### ---------------------------------------------------------------------------

TRACK_DEFS = dict()
for cls in (_ for _ in locals().values() if 
              isinstance(_, type) and 
              issubclass(_, _BaseDef) and 
              not _.__name__.startswith('_')):
  TRACK_DEFS[cls.name] = cls
