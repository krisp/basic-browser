'''
File to define all possible traits of uploaded data.

NOTE: A name must mean the same across all traits.
For example, "start" should refer to a starting position of gene/whatever,
so its type must always be integer, and it's generally indexed.

Created on Jan 27, 2012

@author: mulawadifh
'''
from os import path
import yaml

_processed_traits = set()
def _process_trait(traits, name):
  if name in _processed_traits:
    return
  
  HEADER = ('name', 'long_name', 'type', 'indexed')
  result = list()

  for el in traits[name]:
    if type(el) is str:
      if not name in _processed_traits:
        _process_trait(traits, el)
      result += traits[el]
    elif type(el) is list:
      result.append(dict(zip(HEADER, el)))
    else:
      raise ValueError('Unexpected type: {0}'.format(el))
  
  traits[name] = result
  _processed_traits.add(name)

# Load and convert the traits into dictionary
_TRAITS = dict()

_thisdir = path.dirname(path.abspath(path.realpath(__file__)))
_traitfile = path.join(_thisdir, 'trait_defs.yaml')

with open(_traitfile) as f:
  _TRAITS = yaml.load(f)
  for t in _TRAITS.iterkeys():
    _process_trait(_TRAITS, t)

def predict_traits(colnames):
  '''
  Checks how many traits there are in a set of column names
  Returns a list of traits, and all related column definitions
  '''
  colnames = set(colnames)
  result = dict()
  traitlist = list()
  for trname, trait in _TRAITS.iteritems():
    trcols = set(_['name'] for _ in trait)
    if (trcols & colnames) == trcols: # trait is a subset of colnames
      traitlist.append(trname)
      for t in trait:
        if t['name'] not in result:
          result[t['name']] = t
  return traitlist, result

if __name__ == '__main__':
  import json
  p, q = predict_traits(['chrom', 'start', 'end', 'score'])
  print p
  print json.dumps(q, indent=2)