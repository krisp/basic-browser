'''
Created on Feb 26, 2012

@author: Fabianus
'''
from util.http import cookie

def initialize(engine):
  engine.register('set', handler=cookie_set)
  engine.register('get', handler=cookie_get)
  engine.register('del', handler=cookie_del)

# -----------------------------
#  COOKIE MONSTER
# -----------------------------

def cookie_set(request, args):
  with cookie(request) as coo:
    for k,v in request.POST.iteritems():
      coo[k] = v
  return cookie_get(request, args)

def cookie_del(request, args):
  with cookie(request) as coo:
    for k in request.POST.iterkeys():
      del coo[k]
  return cookie_get(request, args)

def cookie_get(request, args):
  result = dict()
  with cookie(request) as coo:
    for k,v in coo: result[k] = v
    return result
