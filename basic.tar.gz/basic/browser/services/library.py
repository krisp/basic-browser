'''
Created on Feb 27, 2012

@author: mulawadifh
'''
from browser.models import Library
from django.http import HttpResponseNotFound, HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from settings import APP_URL, MONGODBS

def initialize(engine):
    engine.register('view_stats', handler=view_stats, get=('library_id', 'fullscreen'), output='manual')

def view_stats(request, args):
    fullscreen = args['fullscreen']

    try:
        lib = Library.objects.get(id=args['library_id'])
    except:
        return HttpResponseNotFound('Library not found.')

    statscoll = MONGODBS['default']['statistics']
    stats = statscoll.find_one({ '_id': lib.id })
    template = 'no_stats.html'
    
    if not stats:
        stats = {'library' : {
            'name': str(lib.name),
            'descn': str(lib.descn),
            'target': str(lib.target.code) if lib.target else None,            
            'tech': str(lib.tech.name) if lib.tech else None,
            'cell': str(lib.cell.name) if lib.cell else None,
        }}
    else:
        # hack: now we only have PGS anyway
        return HttpResponseRedirect(APP_URL + '/pgs/stats/{0}'.format(lib.id))
    
    if fullscreen: 
        stats['fullscreen'] = True
    return render_to_response(template, stats, context_instance=RequestContext(request))
