'''
Created on Feb 26, 2012

@author: Fabianus
'''
from table.models import MetaTable
from util.mongo import BASICollection

def initialize(engine):
  engine.register('find_by_name', handler=find_by_name, get=('asm', 'name'))
  engine.register('find_by_func', handler=find_by_func, get=('asm', 'func', 'role_type~list', 'role_impt~list'))
  engine.register('autocomplete', handler=autocomplete, get=('asm', 'term'))

def autocomplete(request, args):
  '''Used by autocomplete feature of awesomebar'''
  
  term = args['term']
  if ':' in term: return None
  
  table = MetaTable.objects.get(key='knownGene.%s'% args['asm'])
  coll = BASICollection(table.value)
  
  criteria = '%s*'
  # search genes with symbols that _start_ with [term]
  genes = coll.find_all({ 'sym': { '$regex': r'^%s.*'% term, '$options': 'i' } })
  count = genes.count()
  
  if not count:
    # search genes with symbols that _contain_ [term]  
    criteria = '*%s*'
    genes = coll.find_all({ 'sym': { '$regex': r'.*%s.*'% term, '$options': 'i' } })
  
  if count > 50:
    return ['%d genes found matching the term "%s". Please be more specific'% (count, criteria%term)]  
    
  return sorted(set(_['sym'] for _ in genes))

def find_by_name(request, args):
  '''Used by gene search on left panel'''
  asm = args['asm']
  table = MetaTable.objects.get(key='knownGene.%s'% asm)
  coll = BASICollection(table.value)
  
  return _get_genes(request, asm, coll.find_all({ 'sym': { '$regex': r'.*%s.*'% args['name'], '$options': 'i' } }))

def find_by_func(request, args):
  term = MetaTable.objects.filter(key='go.terms')
  term_coll = BASICollection(term[0].value) if term else None 

  gontos = set(_['_id'] for _ in term_coll.find_all({ 'name': { '$regex': r'.*%s.*'% args['func'], '$options': 'i' },
                                                      'rank': { '$in': [int(_) for _ in args['role_impt'] if _] },
                                                      'ns': { '$in': args['role_type'] },
                                                    }))
  asm = args['asm']
  if not gontos: # special case if nothing's found
    return _get_genes(request, asm, [])

  table = MetaTable.objects.get(key='knownGene.%s'% asm)
  coll = BASICollection(table.value)
  return _get_genes(request, asm, coll.find_all({ 'ontology': { '$in': list(gontos) } }))

def _get_genes(request, asm, genelist):
  genes = dict()
  funcs = dict()
  
  term = MetaTable.objects.filter(key='go.terms')
  term_coll = BASICollection(term[0].value) if term else None

  for g in genelist:
    gsym = g['sym']
    if gsym not in genes: genes[gsym] = list()
    if gsym not in funcs:
      funcs[gsym] = [dict(func=_['name'], type=_['rank'], role=_['ns']) 
                     for _ in term_coll.find_all({ '_id': { '$in': g['ontology'] } })]
    for k in ('_id', 'sym', 'exons', 'cds_start', 'cds_end', 'ontology'): del g[k]
    genes[gsym].append(g)

  result = list()
  for gsym in sorted(genes):
    result.append(dict(sym=gsym, accs=genes[gsym], func=funcs[gsym]))
  return result
