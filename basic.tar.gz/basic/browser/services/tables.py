'''
Created on Feb 26, 2012

@author: Fabianus
'''
from django.http import HttpResponse
from util.mongo import BASICollection
from table.models import Table
import pymongo
import json

def initialize(engine):
    engine.register('download', handler=download, get=('module', 'table_id', 'order'), output='manual')
    engine.register('explore', handler=explore, get=('module', 'table_id', 'offset~int', 'limit~int', 'order'))

# -----------------------------
#  EXPLORE
# -----------------------------

def _gimme_val(v):
    try:
        return float(v)
    except:
        return str(v) # it's a string

def _weave_conds(request):
    OPS = (('>=', '$gte'), ('<=', '$lte'), ('>', '$gt'), ('<', '$lt'), ('!=', '$ne'))
    
    conds = {}
    for k,val in request.GET.iteritems():
        # for each field
        
        if not k.startswith('_f_'):
            continue

        key = k[3:]
        arr = val.strip().split(',')
        
        for cond_str in arr:
            # one field may contain multiple conditions, e.g. >5, <=7 (comma-separated)
            cond_str = cond_str.strip()
            cond = {}
            
            for op, mongo_op in OPS:
                l = len(op)
                if cond_str.startswith(op):
                    v = _gimme_val(cond_str[l:])
                    cond[mongo_op] = None if v=='nil' else v 
                    break
            else:
                # no ops matched
                if cond_str.endswith('%'):
                    # ends with % sign: string prefix search
                    cond['$regex'] = '^' + cond_str[:-1] 
                elif cond_str.startswith('^='): 
                    # same as above: string prefix search
                    cond['$regex'] = '^' + cond_str[2:] 
                elif cond_str.startswith('$='): 
                    # same as above: string suffix search (SLOW)
                    cond['$regex'] = cond_str[2:] + '$' 
                else:
                    # no operator whatsoever: equality
                    cond = _gimme_val(cond_str)
            if cond: 
                conds[key] = None if cond=='nil' else cond
    return conds

def explore(request, args):
    tid, offset, limit, order = args['table_id'], args['offset'], args['limit'], args['order']
    if not offset: offset = 0
    if not limit: limit = 100
    module = args['module'] or 'default'

    result = dict()
    table = Table.objects.using(module).get(id=tid)
    
    coll = BASICollection(table.id, module=module)
    metacoll = coll.meta()

    columns = list()
    for feld in metacoll['columns']:
        if feld['name'].startswith('_') or feld['name'] == 'id': continue
        columns.append({
            'name': feld['name'],
            'longname': feld['long_name'],
            'type': feld['type'],
            'sort': feld['indexed'],             
        })

    colnames = [_['name'] for _ in columns]
    result['columns'] = columns
    result['links'] = _determine_links(metacoll['traits'])
    
    try:
        # if filter is specified, use it
        meta = table.metatable_set.get(key='explorer.filter')
        if meta: filtr = json.loads(meta.value)
    except:
        filtr = {}

    # incorporate conditions from user-defined filters
    filtr.update(_weave_conds(request))
    print filtr

    entries = list()
    rows = coll.find_all(filtr, skip=offset, limit=limit, sort=_get_order_by(order or []))
    for row in rows:
        entry = list()
        for col in colnames:
            v = row.get(col, '-')
            if type(v) in (set, list):
                v = ', '.join(str(_) for _ in sorted(v))
            entry.append(v)
        entries.append(entry)
    
    result['entries'] = entries
    return result

def _determine_links(traits):
    if 'interval_paired' in traits:
        return { 'Go to outer span': ('chrom', 'start', 'end2'),
                 'Go to inner span': ('chrom', 'start2', 'end'),
                 'Go to head position': ('chrom', 'start', 'end'),
                 'Go to tail position': ('chrom2', 'start2', 'end2') }
    elif 'interval' in traits:
        return { 'Go to position': ('chrom', 'start', 'end') }
    elif 'point' in traits:
        return { 'Go to position': ('chrom', 'start', 'start') }
    else:
        return {}

# -----------------------------
#  DOWNLOAD
# -----------------------------

def download(request, args):
    module = args['module'] or 'default'
    table = Table.objects.using(module).get(id=args['table_id'])

    response = HttpResponse(mimetype='text/csv')
    response['Content-Disposition'] = 'attachment; filename=BASIC_{table.name}.txt'.format(**locals())

    coll = BASICollection(table.id, module=module)
    meta = coll.meta()

    columns = list()
    for feld in meta['columns']:
        if feld['name'].startswith('_') or feld['name'] == 'id': continue
        columns.append({
            'name': feld['name'],
            'longname': feld['long_name'],
            'type': feld['type'],
            'sort': feld['indexed'],             
        })

    colnames = [_['name'] for _ in columns]

    # incorporate conditions from user-defined filters
    filtr = _weave_conds(request)
    
    response.write('#' + '\t'.join(_['longname'] for _ in columns) + '\n')
    rows = coll.find_all(filtr, sort=_get_order_by(args['order'] or []))
    for row in rows:
        entry = list()
        for col in colnames:
            v = row.get(col, '-')
            if type(v) in (set, list):
                v = ', '.join(str(_) for _ in sorted(v))
            entry.append(v)
        response.write('\t'.join(str(_) for _ in entry) + '\n')
    
    response.flush()
    return response

def _get_order_by(order):
    if order:
        ord_by = list()
        for o in order.split(','):
            if o[0] == '-':
                ord_by.append((o[1:], pymongo.DESCENDING))
            else:
                ord_by.append((o, pymongo.ASCENDING))
        return ord_by
    else:
        return None
