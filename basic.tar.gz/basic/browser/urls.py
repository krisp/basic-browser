'''
Created on Jul 27, 2012

@author: mulawadifh
'''

from django.conf.urls.defaults import patterns

# Provide visualization data to Track components in JSON
urlpatterns = patterns('basic.browser.tracks',
  (r'^track/pcls/', 'get_track_pcls'),
  (r'^track/scls/', 'get_track_scls'),
  (r'^track/ptag/', 'get_track_ptag'),
  (r'^track/stag/', 'get_track_stag'),
  (r'^track/ltag/', 'get_track_ltag'),
  (r'^track/curv/', 'get_track_pcls'), # we use 'scls' when there's a request for 'curv'
  (r'^track/trfac/', 'get_track_trfac'),
)
