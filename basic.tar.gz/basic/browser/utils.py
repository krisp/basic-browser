'''
Created on Feb 26, 2012

@author: Fabianus
'''
import settings
from django.http import HttpResponseForbidden

def has_perm(request, lib):
    '''If a library doesn't have any permission attached, it means it's free for all.
    '''
    myid = request.user.id
    mygrps = set(g.id for g in request.user.groups.all())
        
    t_own = set(u.id for u in lib.owners.all()) if lib else set()
    t_grp = set(g.id for g in lib.groups.all()) if lib else set()
    return (request.user.username == 'root' or # the all-powerful being
            len(t_own)+len(t_grp) == 0 or # no specific permission
            myid in t_own or # is owner 
            len(mygrps & t_grp)>0) # is member of owning group

def has_mod_perm(request, module):
    '''Check if user is allowed to access a module.
       This is done by checking if the module's config declare AUTH_GROUPS.
       If the user belongs to one of the groups in AUTH_GROUPS, access is allowed.
       Without AUTH_GROUPS, a module is not accessible by anyone.
    '''
    mygrps = set(_.name for _ in request.user.groups.all())

    modgrps = getattr(module, 'AUTH_GROUPS') # this is intentional: fail if AUTH_GROUPS is not defined
    return mygrps & set(modgrps) or []
