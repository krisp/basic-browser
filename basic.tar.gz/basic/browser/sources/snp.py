'''
Created on Feb 27, 2012

@author: mulawadifh
'''
from browser.sources.common import utils
from driver.gaprs import RankSelect
from driver.pets import Tags
from os import path
from table.models import Metadata, Track
from util.mongo import BASICollection
import settings

def initialize(engine):
  engine.register('query', handler=query, get=('track_id', 'chrom', 'start~int', 'end~int', 'limit~int', 'canvas_w~int'))

_snp_xpets_drivers = dict() # dict of drivers
_snp_gaprs_drivers = dict() # dict(track) of dict(group) of drivers
def query(request, args):
  track_id = args['track_id']
  
  drv_xpets = _snp_xpets_drivers.get(track_id)
  if not drv_xpets:
    # load handlers
    source_xpets = Metadata.objects.get(track__id=track_id, key='source.xpet').value
    srcfile = utils.parse_metaval(source_xpets)

    if srcfile[0] != '/': srcfile = path.join(settings.TRACK_DIR, srcfile) # relative path
    _snp_xpets_drivers[track_id] = drv_xpets = Tags(srcfile)

  # --------------

  drv_gaprs = _snp_gaprs_drivers.get(track_id)
  if not drv_gaprs:
    source_gaprs = Metadata.objects.get(track__id=track_id, key='source.gaprs').value
    srcfile = utils.parse_metaval(source_gaprs) # this is a dictionary { group -> .snp file }
      
    drv_gaprs = dict()
    for k,v in srcfile.iteritems():
      if v[0] != '/': v = path.join(settings.TRACK_DIR, v) # relative path
      drv_gaprs[k] = RankSelect(v, silent=True) # always silently return 0 if corresponding file doesn't exist

    _snp_gaprs_drivers[track_id] = drv_gaprs
  
  # --------------
  chrom, start, end, limit = args['chrom'], args['start'], args['end'], args['limit']
  canvas_w = args['canvas_w']
  
  entries = drv_xpets.query(chrom, start, end, limit)
  table_id = Track.objects.get(id=track_id).table.id
  coll = BASICollection(table_id)

  if len(entries) < limit and coll.count():
    # if there's at least one result, and corresponding table is present in database, "augment" the result
    for item in entries: # spice up the results
      item.update(coll.find_one({ '_id': item['id'] }) or {})
  
  heatmap = dict() # {group -> [0..canvas_w]}

  # map contains the list of values for each pixel on canvas, for each group
  # entries contains the actual entries, if there're not too many of them
  result = dict(map=heatmap, entries=entries)

  # PGS: find all non-synonymous SNPs if meta table is defined
  result['pgs.nonsyns'] = list(coll.find({ 'chrom': chrom, 'non_synonymous': True }))
  
  skip = (end-start+1)/float(canvas_w)
  for grpname, drv in drv_gaprs.iteritems():
    if not drv.count(chrom, start, end): 
      continue # optimization: do count from start-end first before deciding to do it 1000+ times
    
    heatlist = list()
    for _i in xrange(canvas_w):
      pos = int(start+skip*_i)
      heatlist.append(drv.count(chrom, pos, min(end, int(pos+skip+0.5))))
      
    heatmap[grpname] = heatlist
  
  return result
