'''
Created on Feb 27, 2012

@author: mulawadifh
'''
import json

def parse_metaval(value):
  try:
    return json.loads(value)
  except:
    return value # if it's not JSON, it's just plain string

def get_srcfile(jsobj, srckey):
  if type(jsobj) == list:
    return jsobj[int(srckey)]
  elif type(jsobj) == dict:
    return jsobj[srckey]
  elif type(jsobj) == str or type(jsobj) == unicode:
    return jsobj
  else:
    raise Exception('Unrecognized format: %s'% type(jsobj))
