'''
Created on Feb 27, 2012

@author: mulawadifh
'''
from table.models import Track
from util.mongo import BASICollection

def initialize(engine):
  engine.register('query', handler=query, get=('track_id', 'chrom', 'start~int', 'end~int', 'limit~int'))

_track_gene_drivers = dict()
def query(request, args):
  trk = Track.objects.get(id=args['track_id'])
  coll = BASICollection(trk.table.id)
  gene_list = _get_genes_by_loc(coll, args['chrom'], args['start'], args['end'], limit=args['limit'])

  result = list()
  for gene in gene_list:
    exons = gene['exons']
    if exons:
      introns = [(0, exons[0][0])]
      introns += [(exons[i-1][1], exons[i][0]) for i in xrange(1, len(exons))]
      introns.append((exons[-1][1], gene['end']-gene['start']))
      gene['introns'] = [(x,y) for x,y in introns if x<y]
    else:
      gene['introns'] = []
    result.append(gene)
  return result

def _get_genes_by_loc(coll, chrom, start, end, limit):
  for item in coll.find({ 'chrom': chrom,
                          'start': { '$lt': end   },
                          'end'  : { '$gt': start },
                        }, limit=limit or 0): yield item
