'''
All methods that provide JSON to Track components go here.

@author: Fabi
'''
from browser.sources.common import utils
from django.http import HttpResponseServerError
from driver.bam import TwinBammy
from driver.pets import Tags
from os import path
from settings import TRACK_DIR
from table.models import Metadata, Track
from util.http import get_params, json_service
from util.mongo import BASICollection

#-------------------------------------------------------------------------------
# Common method to retrieve pet-like data structure
#-------------------------------------------------------------------------------
def _get_track_xpets(request, cache):
  trk_id, chrom, start, end, srckey, maxpets = get_params(request, 'tid', 'chrom', 'start~int', 'end~int', 'srckey', 'max')
  
  if not srckey: 
    raise Exception(HttpResponseServerError('[srckey] must be given as parameter'))
  source = Metadata.objects.get(track__id=trk_id, key='source').value

  cachekey = '%s.%s'% (trk_id,srckey) if srckey else trk_id
  driver = cache.get(cachekey, None)
  
  if not driver:
    # load handlers
    try:
      jsobj = utils.parse_metaval(source)
      srcfile = utils.get_srcfile(jsobj, srckey)
    except Exception as e:
      raise Exception(HttpResponseServerError(e))

    if srcfile[0] != '/': srcfile = path.join(TRACK_DIR, srcfile) # relative path
    cache[cachekey] = driver = Tags(srcfile)
  
  maxpets = int(maxpets or 0) 
  result = list()
  ids = set()
  
  # remove duplicates
  for item in driver.query(chrom, start, end, maxpets):
    if item['id'] in ids: continue
    ids.add(item['id'])
    result.append(item)

  table_id = Track.objects.get(id=trk_id).table.id
  coll = BASICollection(table_id)

  if result and coll.count():
    # if there's at least one result, and corresponding table is present in database, "augment" the result
    for item in result: # spice up the results
      item.update(coll.find_one({ '_id': item['id'] }))
  
  return result

_track_stag_drivers = dict()
def get_track_stag(request):
  with json_service(request, _get_track_xpets(request, _track_stag_drivers)) as response:
    return response

_track_ptag_drivers = dict()
def get_track_ptag(request):
  with json_service(request, _get_track_xpets(request, _track_ptag_drivers)) as response:
    return response

_track_pcls_drivers = dict()
def get_track_pcls(request): # paired clusters
  srckey, chrom = get_params(request, 'srckey', 'chrom')
  if srckey:
    # if [srckey] is present, it means there's a data structure backing 
    with json_service(request, _get_track_xpets(request, _track_pcls_drivers)) as response:
      return response
  else:
    # otherwise, do it the old boring way: use database
    track_id, start, end, limit = get_params(request, 'tid', 'start~int', 'end~int', 'max~int')
    return _get_track_pcls_db(request, chrom, start, end, limit, track_id)
  
def _get_track_pcls_db(request, chrom, start, end, limit, track_id):
  table_id = Track.objects.get(id=track_id).table.id
  coll = BASICollection(table_id)
  limit = limit or 0
  result = list()
  added = set()
  with json_service(request, result) as response:
    for row in coll.find_all({ 'chrom': chrom, 'start': { '$lt': end }, 
                               'end': { '$gt': start }}, limit=limit):
      if row['_id'] in added: continue
      result.append(row)
      added.add(row['_id'])
      
    partial_result_length = len(result)
    if partial_result_length < limit:
      for row in coll.find_all({ 'chrom2': chrom, 'start2': { '$lt': end }, 
                                 'end2': { '$gt': start }}, limit=max(0,limit-partial_result_length)):
        if row['_id'] in added: continue
        result.append(row)
        added.add(row['_id'])
        
    return response

_track_scls_drivers = dict()
def get_track_scls(request): # single clusters
  srckey = get_params(request, 'srckey')

  if srckey: 
    # if this field is present, it means there's a data structure backing
    with json_service(request, _get_track_xpets(request, _track_scls_drivers)) as response:
      return response
  else:
    # otherwise, do it the old boring way: use database
    tid, chrom, start, end, maxpets = get_params(request, 'tid', 'chrom', 'start~int', 'end~int', 'max~int')
    return _get_track_sintv_db(request, chrom, start, end, maxpets, tid)

_track_ltag_drivers = dict()
def get_track_ltag(request): # single clusters
  trk_id, chrom, start, end, _, limit, showseq = get_params(request, 'tid', 'chrom', 'start', 'end', 'srckey', 'max', 'show_seq')
  start = int(start)
  end = int(end)
  cache = _track_ltag_drivers
  
  result = list()
  tmpresult = list()
  with json_service(request, result) as response:
    source = Metadata.objects.get(track__id=trk_id, key='source').value
    bamlist = utils.parse_metaval(source)
  
    limit = int(limit or 0)
    for i, bamfile in enumerate(bamlist):
      cachekey = '%s.%s'% (trk_id, i)
      drv = cache.get(cachekey)
      
      if not drv:
        if bamfile[0] != '/': bamfile = path.join(TRACK_DIR, bamfile) # relative path
        cache[cachekey] = drv = TwinBammy(bamfile)
    
      intermed = drv.query(chrom, start, end, max(0, limit), showseq)
      tmpresult += intermed
      limit -= len(intermed)
    
    result += sorted(tmpresult, key=lambda _: (_['pos'], _['len']))
    return response

#-------------------------------------------------------------------------------
# Common method to query single-interval records (chrom,start,end)
#-------------------------------------------------------------------------------
def _get_track_sintv_db(request, chrom, start, end, limit, track_id):
  table_id = Track.objects.get(id=track_id).table.id
  coll = BASICollection(table_id)

  result = list()
  with json_service(request, result) as response:
    result += coll.find({ 'chrom': chrom,
                          'start': { '$lt': end },
                          'end'  : { '$gt': start }},
                        limit=limit or 0)
    return response

def get_track_trfac(request):
  tid, chrom, start, end, maxretv = get_params(request, 'tid', 'chrom', 'start~int', 'end~int', 'max~int')
  return _get_track_sintv_db(request, chrom, start, end, maxretv, tid)

#-------------------------------------------------------------------------------
# Common method to query point records (chrom,pos)
#-------------------------------------------------------------------------------
def _get_track_point_db(request, chrom, start, end, limit, track_id):
  table_id = Track.objects.get(id=track_id).table.id
  coll = BASICollection(table_id)
  return coll.find({ 'chrom': chrom,
                     'start'  : { '$lt': end, '$gte': start }},
                    limit=limit or 0)

