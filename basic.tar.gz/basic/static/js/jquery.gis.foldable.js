(function ($) {
  $.widget("gis.foldable", {
    options: {
      trigger: null, // HTML element; if specified, clicking on it will trigger fold/unfold
      
      _vars: {
	    _is_anim: false, // animation in progress
	    _icon_tents: [],
	    _folders: {}
	  }
    },
    
    reset: function() {
      this.options._vars._icon_tents = [];
    },
    
    hide_all: function() {
      var vars = this.options._vars;
      for (var i in vars._icon_tents) {
        var v = vars._icon_tents[i];
        this._hide(v[0], v[1]);
      }
    },

    show_all: function() {
      var vars = this.options._vars;
      for (var i in vars._icon_tents) {
        var v = vars._icon_tents[i];
        this._show(v[0], v[1]);
      }
    },

    _hide: function(icon, folder) {
      if (folder.data('folded') || folder.data('animated')) return;
      folder.data('animated', true);
      folder.slideUp('fast', function() {
        folder.data('folded', true).data('animated', false);
        icon.removeClass('ui-icon-triangle-1-s').addClass('ui-icon-triangle-1-e');
      });
    },

    _show: function(icon, folder) {
      if ((! folder.data('folded')) || folder.data('animated')) return;
      folder.data('animated', true);
      folder.slideDown('fast', function() {
        folder.data('folded', false).data('animated', false);
        icon.removeClass('ui-icon-triangle-1-e').addClass('ui-icon-triangle-1-s');
      });
    },

    append: function(anchor, content, folded) {
      var self = this,
          el = this.element,
          opts = this.options,
          vars = this.options._vars;
  
      var folder = $('<div>').css({
        //'border-left': 'solid 1px #ccc',
        //'margin-left': '0.5em'
      }).append(content).disableSelection();

      folder[folded ? 'hide' : 'show']().appendTo(el).data('folded', folded);
    
      $(anchor).css({ position: 'relative' }); // required to make absolute positioning work
      
      var icon = $('<span>').addClass('ui-icon');
      icon.addClass(folded ? 'ui-icon-triangle-1-e' : 'ui-icon-triangle-1-s')
        .appendTo(anchor)
        .css({ 
          cursor: 'pointer',
          position: 'absolute',
          top: 0,
          left: '-18px'
        });
      
      (function() {
        var fun = function() {
          self[folder.data('folded') ? '_show' : '_hide'](icon, folder);
        };
        icon.click(fun);
        if (opts.trigger != null) {
          if (opts.trigger instanceof Array) {
            for (var i in opts.trigger) opts.trigger[i].click(fun);
          } else {
            $(opts.trigger).click(fun);
          }
        }
      })();
      
      vars._icon_tents.push([icon, folder]);
    },
    
    _create: function() {
    }
  });
})(jQuery);