/**
 * Indicates the area in genome currently viewed.
 * Fabi. Jul 2010.
 */
(function ($) {
    var _self = null;
    $.widget('gis.acgtview', {
        options: {
            source: null, // required
            asm: null, // required
            height: 18,
            minblock: 7, // minimal letter block size (pixel)
            
            _vars: {}
        },
        
        _colors: {
            A: '#0c0',
            C: '#00a',
            G: '#da0',
            T: '#c00',
            N: '#777',
            '?': 'white'
        },
        
        _createContent: function(trackId) {
            var opts = this.options,
                track = opts._track;

            track.css({
                position: 'relative',
                width: '100%',
                border: 'none',
                'margin-top': '-0.3em'
            });
                
            var canvasHolder = $('<div>').css({
                'margin-left': BASIConst.flot.labelWidth + 19, // magic
                'margin-right': 13
            }).appendTo(track);
            
            var canvas = $('<canvas>').attr({
                height: opts.height,
                width: canvasHolder.width()
            }).appendTo(canvasHolder);
            
            return canvas;
        },
        
        hresize: function() {
            var el = this.element;
            el.css({ width: '100%' });
            // call setLocation() instead of _drawPlot() because
            // the logic to hide/show depending on view span is in setLocation
            this.setLocation();    
        },

        _drawPlot: function() {
            var opts = this.options,
                vars = this.options._vars,
                canvas = opts._canvas;

            canvas.attr({
                width: canvas.parent().width()
            });
            
            var w = canvas.width(),
                h = canvas.height();
            
            var len = vars.end-vars.start+1, 
                blocksize = w/len;
            
            var ctx = canvas.get(0).getContext('2d');
            ctx.save();

            ctx.clearRect(0, 0, w, h);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.font = '12px bold';
            
            var p = 0, q = blocksize;
            var seqStart = vars.text.start,
                    seq = vars.text.seq;
            
            for (var i = vars.start; i <= vars.end; i++) {
                var j = i-seqStart;
                var chr = (j >= 0 && j < len) ? seq[j] : '?',
                        col = this._colors[chr.toUpperCase()];
                
                ctx.clearRect(Math.round(p), 0, Math.round(q), h);
                ctx.fillStyle = col;
                ctx.fillText(chr, p+blocksize/2, h/2);
                
                p += blocksize;
                q += blocksize;
            }
            
            ctx.restore();
        },

        _lazyFullRefresh: _.debounce(function() { _self.fullRefresh(); }, 500),
        
        setLocation: function (loc) {
            var vars = this.options._vars,
                opts = this.options,
                canvas = opts._canvas,
                prevChrom = vars.chrom,
                prevSpan = vars.end-vars.start+1;
            
            if (_.isObject(loc)) {
                if (loc.chrom != null) vars.chrom = loc.chrom;
                if (loc.start != null) vars.start = loc.start;
                if (loc.end != null) vars.end = loc.end;
            }
            
            var curSpan = vars.end-vars.start+1,
                w = canvas.parent().width();
            
            if (w/curSpan < opts.minblock) {
                canvas.hide();
                return;
            } else {
                canvas.show();
            }

            if (prevChrom == vars.chrom && prevSpan == curSpan) {
                var self = this;
                this.quickRefresh();
                this._lazyFullRefresh();
            } else {
                this.fullRefresh();
            }
        },
        
        quickRefresh: function() {
            if (this.options._vars.text) this._drawPlot(); // only call after full refresh has been called            
        },

        fullRefresh: function() {
            var self = this, 
                opts = this.options,
                vars = this.options._vars,
                params = { 
                    asm: opts.asm, 
                    chrom: vars.chrom, 
                    start: vars.start, 
                    end: vars.end 
                };
            
            if (!(vars.chrom && vars.start && vars.end)) return;
            
            $.getJSON(opts.source, params, function(data) {
                self.options._vars.text = {
                    seq: data.seq,
                    start: vars.start
                };
                self._drawPlot();            
            });
        },
        
        _create: function () {
            var opts = this.options;
            opts._track = this.element;
            
            var trackId = opts._track.attr('id');
            opts._canvas = this._createContent(trackId);
            
            _self = this; // <-- used by lazyQuickRefresh
        }
    });
})(jQuery);