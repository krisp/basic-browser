BASIC.register('gis.basic.bootstrap', (function() {
    'use strict';
    
    var global = null,
        app_url = null;

    var chrom_sizes = null,
        chrom_bands = null;
    
    return {
        __init__: function(args) {
            global = args.global;
            app_url = args.APP_URL;
            
            var self = this,
                pos = args.position;
            
            this._setupAjaxCSRF();
            
            // ----------------------------------------------------------
            // BOOTSTRAP - Get information on chromosome sizes and bands
            // ----------------------------------------------------------
            return $.Deferred(function(def) {
                BASIC_getMultiJSON({
                    csize: BASICService.CHROME_SIZES,
                    cband: BASICService.CHROME_BANDS
                }, { asm: global.asm }).done(function(data) {
                    if (pos.chrom === '') {
                        
                        // no info found in cookie
                        for (var i in data.csize) {
                            pos.chrom = i;
                            pos.start = 1;
                            pos.end = data.csize[i];
                        }
                    }
                    
                    chrom_sizes = data.csize;
                    chrom_bands = data.cband;
                    
                    self._setupFixedComponents(chrom_sizes, chrom_bands, pos.chrom, pos.start, pos.end);
                    def.resolve();
                });
            }).promise();
        },

        getChromInfo: function(callback) {
            callback({
                sizes: chrom_sizes,
                bands: chrom_bands
            });
        },
        
        /*
         * PRIVATE FUNCTIONS 
         */

        _setupAjaxCSRF: function() {
            jQuery(document).ajaxSend(function(event, xhr, settings) {
                function getCookie(name) {
                    var cookieValue = null;
                    if (document.cookie && document.cookie != '') {
                        var cookies = document.cookie.split(';');
                        for (var i = 0; i < cookies.length; i++) {
                            var cookie = jQuery.trim(cookies[i]);
                            // Does this cookie string begin with the name we want?
                            if (cookie.substring(0, name.length + 1) == (name + '=')) {
                                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                                break;
                            }
                        }
                    }
                    return cookieValue;
                }
                function sameOrigin(url) {
                    // url could be relative or scheme relative or absolute
                    var host = document.location.host; // host + port
                    var protocol = document.location.protocol;
                    var sr_origin = '//' + host;
                    var origin = protocol + sr_origin;
                    // Allow absolute or scheme relative URLs to same origin
                    return (url == origin || url.slice(0, origin.length + 1) == origin + '/') ||
                        (url == sr_origin || url.slice(0, sr_origin.length + 1) == sr_origin + '/') ||
                        // or any other URL that isn't scheme relative or absolute i.e relative.
                        !(/^(\/\/|http:|https:).*/.test(url));
                }
                function safeMethod(method) {
                    return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
                }
            
                if (!safeMethod(settings.type) && sameOrigin(settings.url)) {
                    xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken'));
                }
            });
        },

        _setupFixedComponents: function(chrsizes, chrbands, chrom, start, end) {
            // setup assembly selector
            $("#select_asm option").each(function() {
                if ($(this).val() == global.asm) $(this).attr({ selected: 'selected' });
            });
            $("#select_asm").css({ 'margin-bottom': 0 }).on('change', function (ev, ui) {
                document.location = app_url + "/basic/main/" + $(this).val();
            }).tooltip({ placement: 'bottom' });
            
            this._setupChromSelector(chrsizes, chrom);
        },
        
        _setupChromSelector: function(chrsizes, chrom) {
            // setup chrom selector
            var keys = [], 
                chrselect = global.select_chrom
                                  .css({ 'margin-bottom': 0 })
                                  .tooltip({ placement: 'bottom' });
            
            for (var chrname in chrsizes) { keys.push(chrname); }
            keys.sort(function(p,q) {
                var a = 0, b = 0, x = 0;
                if (p.substr(0,3) == 'chr') {
                    x = 3;
                } else if (p.substr(0,9) == 'scaffold_') {
                    x = 9;
                }

                a = parseInt(p.substr(x));
                b = parseInt(q.substr(x));
                var c = a-b;
                
                if (!isNaN(c)) return c;
                if (isNaN(a) && isNaN(b)) return p < q ? -1 : 1;
                if (isNaN(a)) return 1;
                if (isNaN(b)) return -1;
            }); // sort first
            
            for (var x in keys) {
                var chrname = keys[x],
                    opt = $('<option>').attr({ value: chrname }).html(chrname).appendTo(chrselect);
                if (chrname == chrom) opt.prop({ selected: true });
            }
            chrselect.change(function (ev, ui) {
                var new_value = $(this).val();
                $.publish(BASICEvent.NAV_GET_LOCATION, function(loc) {
                    var st = Math.min(loc.start, chrsizes[new_value]),
                        en = Math.min(loc.end, chrsizes[new_value]);
        
                    if (en-st < 1500) st = 1;
                    $.publish(BASICEvent.NAV_ZOOM_TO, [new_value, st, en]);
                });
            });
        }
    };
})());