BASIC.register('gis.basic.tracklist', (function() {
    var global = null,
        app_url = null,
        track_list = null,
        track_defs = null,
        raw_track_list = null;
    
    function setup(tab, tracklist) {
        var def = $.Deferred();
        BASIC_getMultiJSON({
            projs     : BASICService.PROJ_LIST,
            techs     : BASICService.TECH_LIST,
            cells     : BASICService.CELL_LIST,
            targets   : BASICService.TARGET_LIST,
            tkdef     : BASICService.TRACK_DEFS
        }).done(function(data) {
            
            raw_track_list = tracklist;
            track_defs = data.tkdef; // needed for user-specific property modification
            
            tab.tracky({
                tracklist: raw_track_list,
                source: BASICService.TRACK_LIST,
                asm: global.asm,
                projs: data.projs,
                techs: data.techs,
                cells: data.cells,
                targets: data.targets,
                
                groupchange: function(ev, value) {
                    BASIC_local(BASICStorage.TRACK_ACTIVE_GROUP, value);
                },
                
                click: function (ev, ui) {
                    if (ui.state) { // ON
                        $.publish(BASICEvent.TRACK_MGR_ADD, [ui.track.track_id]);
                    } else {
                        $.publish(BASICEvent.TRACK_MGR_REMOVE, [ui.track.track_id]);
                    }
                },
                
                libclick: function(ev, ui) { // library name is clicked
                    window.open(BASICService.LIBRARY_STATS + '?' + $.param({ 
                        library_id: ui.library.id, 
                        fullscreen: 1 
                    }));
                }
            });
            
            // preserve the previously selected track groupings
            var group = BASIC_local(BASICStorage.TRACK_ACTIVE_GROUP);
            if (group != null) tab.tracky('chgroup', group);
            
            def.resolve();
        });
        return def.promise();
    }

    function subscribeToEvents() {
        // TRACK CONFIG EVENTS
        $.subscribe(BASICEvent.TRACK_CONFIG, function(track) {
            $.publish('gis.basic.panel.bottom.addTab', 
                        [track.name, '', false, 'trkconfig_' + track.track_id, function(holder) {
                
                holder.trackconf({
                    defs: track_defs[track.type],
                    props: track.configs,
                    apply: function(ev, ui) {
                        $.post(BASICService.TRACK_CONFIG_SET, $.extend(ui.value, { track_id: track.track_id }), function(data) {
                            var stat = BASIC_recurseval(data);
                            if (stat.status == 'OK') {
                                $.publish(BASICEvent.TRACK_MGR_RELOAD, [track.track_id]);
                            }
                        });
                    }
                });
            }]);
        });
    }
    
    return {
        __init__: function(args) {
            global = args.global;
            app_url = args.APP_URL;
            
            return $.Deferred(function(def) {
                $.publish(BASICEvent.PANEL_LEFT_ADD, ['Library/Track List', '', function(tab) {
                    $.publish(BASICEvent.TRACK_MGR_GET_TRACKLIST, function(data) {
                        track_list = tab; // this is actually a DIV element containing the list of tracks
                                          // it's different from what's returned by TRACK_MGR_GET_TRACKLIST,
                                          // which is a list of track objects retrieved from the server
                        setup(tab, data).done(function() {
                            subscribeToEvents();
                            def.resolve();
                        });
                    });
                }]);
            }).promise();
        },
        
        __deps__: function() {
            return ['gis.basic.panel.left', 'gis.basic.trackmanager'];
        },
        
        getActiveTrackIDs: function(callback) {
            var activeIds = [],
                trackDict = track_list.tracky('getTracks');
                
            _.each(raw_track_list, function(t) {
                var id = t.track_id;
                if (trackDict[id]._state) activeIds.push(id);
            });
            
            callback(activeIds);
        },
        
        refresh: function() {
            track_list.tracky('refresh');
        },

        getTracks: function(callback) {
            callback(track_list.tracky('getTracks'));
        },
        
        openTrack: function(track_id) {
            track_list.tracky('set', track_id);
        },
        
        closeTrack: function(track_id) {
            track_list.tracky('clear', track_id);
        }
    };
})());

// --- START JQUERY WIDGET -----------------------------------------------------

(function ($) {
    $.widget("gis.tracky", {
        options: {
            source: "",
            asm: "",
            libtags: null, // required
            
	        _vars: {} // "local" variables
        },
        
        set: function(id) {
            var tracks = this.options._vars.trackdict,
                links = this.options._vars.linkdict;

            tracks[id]._state = true;
            links[id].addClass('active').css({ border: "none" });
        },

        clear: function(id) {
            var tracks = this.options._vars.trackdict,
                links = this.options._vars.linkdict;

            tracks[id]._state = false;
            links[id].removeClass('active');
        },
        
        refresh: function() {
            this._refreshList();
        },
        
        chgroup: function(group) {
            this.options._vars.selector.val(group);
        },

        getTracks: function() {
            // we have to use string 'null' because if a widget method returns null,
            // a jquery object is returned automatically for chaining
            return $.extend({}, this.options._vars.trackdict); 
        },
        
        getTrack: function(track_id) {
            // we have to use string 'null' because if a widget method returns null,
            // a jquery object is returned automatically for chaining
            return this.options._vars.trackdict[track_id] || 'null'; 
        },
        
        _makeGroupSelector: function() {
            var select = $('<select>').attr({ id: 'tracky_selector' }).css({ width: '90%' }),
                    groups = { 
                        none: '(no grouping)',
                        proj: 'Project',
                        cell: 'Cell Line', 
                        tech: 'Technology', 
                        target: 'Target Factor'
                    };
            _.each(groups, function(grpLabel, key) {
                var opt = $('<option>').attr({ value: key }).html(grpLabel).appendTo(select);
                if (key == 'none') opt.prop({ selected: true });
            });
            return select;
        },
        
        _makeFilterField: function() {
            return $('<input type="text">')
                .attr({ id: 'tracky_filter', placeholder: 'no filter' })
                .css({ width:'90%' })
                .addClass('ui-corner-all');
        },
        
        _refreshList: function() {
            var self = this,
                opts = this.options,
                vars = this.options._vars,
                content = vars.content;
            
            content.empty(); // clear the whole thing

            var rawTracks = vars.rawlist,
                grpby = vars.selector.val(),
                filter = vars.filter,
                groups = _.groupBy(rawTracks, function(it) { return it[grpby] || '~'; });

            var headers = [];
            for (var g in groups) headers.push(g);
            headers.sort();

            var filtText = filter.val().toLowerCase();
            var trackdict = vars['trackdict'] = {};
            var linkdict = vars['linkdict'] = {};
            
            content.off('click').on('click', 'a', function(ev) {
                ev.preventDefault();
                var it = trackdict[$(this).data('track_id')];
                if (it._state) self.clear(it.track_id); else self.set(it.track_id); 
                self._trigger('click', ev, { state: it._state, track: it });
            });
            
            for (var j in headers) {
                var g = headers[j],
                    groupTitle = g,
                    subgroups = _.groupBy(groups[g], function(it) { return it.library || '~'; });

                if (headers.length > 1) {
                    var group = $('<label>')
                    				.css({ 'padding': '4px' })
                                    .addClass('label label-inverse')
                                    .html(groupTitle === '~' ? '&nbsp;' : groupTitle)
                                    .disableSelection()
                                    .appendTo(content);
                                    
                    group.click(function() {
                        $(this).nextUntil('.label', '.accordion-group').each(function(_, el) {
                            var colly = $(el).find('.collapse');
                            colly.collapse(colly.hasClass('in') ? 'hide' : 'show');
                        });
                    });
                }

                var subheaders = [], library_ids = {};
                for (var g in subgroups) {
                    subheaders.push(g);
                    if (library_ids[g] == null) {
                        library_ids[g] = subgroups[g][0].library_id;
                    }
                }
                subheaders.sort();

                for (var i in subheaders) {
                    var g2 = subheaders[i],
                        subgroupTitle = g2,
                        ulEmpty = true, 
                        items = subgroups[g2];
    
                    var accord_inner = $('<ul>').addClass('accord-inner'),
                        hasActive = false; // this subgroup has at least one active track
                        
                    for (var item in items) {
                        var it = items[item],
                            name = it.name, 
                            li = $('<li>'),
                            anchor = $('<a href="#">').html(name).appendTo(li).data('track_id', it.track_id);

                        if (filtText != '' 
                            && name.toLowerCase().indexOf(filtText) == -1
                            && subgroupTitle.toLowerCase().indexOf(filtText) == -1
                            ) {
                            li.hide();
                        } else {
                            ulEmpty = false; // this means there's at least one visible entry
                        }
                        
                        li.appendTo(accord_inner);
                        trackdict[it.track_id] = it;
                        linkdict[it.track_id] = anchor;
                        
                        if (it._state) {
                            hasActive = true;
                            anchor.addClass('active');
                        }
                    }
    
                    if (! ulEmpty) {
                        if (subgroupTitle == '~') {
                            subgroupTitle = '(N/A)';
                        }

                        var accord_group = $('<div>')
                            .addClass('accordion-group')
                            .css({ border: 'none' })
                            .appendTo(content);

                        var accord_head = $('<div>')
                            .addClass('accordion-heading')
                            .appendTo(accord_group)
                            .disableSelection();
                                                    
                        var accord_toggle = $('<div>')
                            .addClass('accordion-toggle prefix-arrow-down')
                            .attr({
                                'data-toggle': 'collapse',
                                'href': '#traccord_' + i + '_' + j
                            }).html(subgroupTitle)
                            .appendTo(accord_head);

                        $('li', accord_inner).css({ 'margin-left': '0.5em', 'color': '#aaa' });
                        
                        var accord_body = $('<div>')
                            .addClass('accordion-body collapse').attr({
                                'id': 'traccord_' + i + '_' + j
                            }).appendTo(accord_group);
                        
                        if (!(filtText == '' && !hasActive)) {
                            // not collapsed
                            accord_body.addClass('in');
                        }
                        
                        accord_inner.addClass('accordion-inner').appendTo(accord_body);
                    }
                }
            } // j
        },
        
        _create: function() {
            var self = this,
                el = this.element;
            
            // clear the playing field
            el.empty();
            var holder = $('<div>').addClass('basic-tracklist').appendTo(el);
            var control_panel = $('<form>').addClass('well well-small').appendTo(holder);

            $('<label for="tracky_selector">Group by:</label>').appendTo(control_panel);
            grpSelect = this._makeGroupSelector();
            grpSelect.change(function(ev, ui) {
                self._trigger('groupchange', ev, $(this).val());
                self._refreshList();
            }).appendTo(control_panel);
            this.options._vars['selector'] = grpSelect;
            
            $('<label for="tracky_filter">Filter by:</label>').appendTo(control_panel);
            filtField = this._makeFilterField();
            filtField.keyup(_.throttle(function() {
                self._refreshList();
            }, 1000)).appendTo(control_panel);
            this.options._vars['filter'] = filtField;

            var butt_group = $('<div>').addClass('btn-group').css({
                'padding-bottom': '1em'
            }).appendTo(control_panel);

            $('<button> Expand</button>')
                .addClass('btn')
                .prepend($('<i>').addClass('icon icon-resize-full'))
                .click(function(ev) {
                    ev.preventDefault();
                    $('#accord_content .collapse').not('.in').collapse('show');
                }).appendTo(butt_group);
            
            $('<button> Collapse</button>')
                .addClass('btn')
                .prepend($('<i>').addClass('icon icon-resize-small'))
                .click(function(ev) {
                    ev.preventDefault();
                    $('#accord_content .collapse.in').collapse('hide');
                }).appendTo(butt_group);

            // this div will be emptied every time
            // new data is retrieved from server, or grouping/filtering is done
            var content = $('<div>')
                .addClass('basic-accord accordion')
                .attr({ id: 'accord_content' })
                .appendTo(holder);

            this.options._vars['content'] = content;
            
            // retrieve for the first time
            this.options._vars.rawlist = this.options.tracklist;
            this._refreshList();
            
            // TODO: configure polling
        }
    });
})(jQuery);
