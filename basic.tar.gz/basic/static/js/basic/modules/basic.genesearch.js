BASIC.register('gis.basic.genesearch', (function() {

    var HOLDER = $('<div>')
        .append($('<div>').addClass('gene_byname'))
        .append($('<div>').addClass('gene_byfunc')); 
    
    var global = null;
    
    var _geneloc_click_fun = function(ev) {
        ev.preventDefault();
        var arr = $.trim($(this).html()).split(/[\:\-]/);
        $.publish(BASICEvent.NAV_ZOOM_TO, [arr[0], arr[1], arr[2]]);
    };
    
    var _genesearch_complete_fun = function(ev, ui) {
        $.publish('gis.basic.panel.bottom.addTab', ['Search result for [' + ui.query + ']', ui.result, false, null, function(tab) {
            $(tab).on('click', '.genelink', _geneloc_click_fun);
        }]);
        
        // show bottom panel if it's hidden
        $.publish(BASICEvent.PANEL_BOTTOM_SHOW);
    };

    var TEMPLATE = {
        BYNAME: '/static/templates/gene_byname.html',
        BYFUNC: '/static/templates/gene_byfunc.html'
    };

    var SERVICE = {
        BYNAME: '/basic/services/genes/find_by_name/',
        BYFUNC: '/basic/services/genes/find_by_func/'
    };

    return {
        __init__: function(args) {
            global = args.global;
            app_url = args.APP_URL;
            
            return $.Deferred(function(def) {
                $.publish('gis.basic.panel.left.addTab', ['Gene Search', HOLDER, function(tab) {
                    // [3-1] Gene search by name
                    $('.gene_byname', tab).genesearch({ asm: global.asm,
                        template_url: app_url + TEMPLATE.BYNAME,
                        query_url: app_url + SERVICE.BYNAME,
                        complete: _genesearch_complete_fun
                    });
    
                    // [3-2] Gene search by function (gene ontology)
                    $('.gene_byfunc', tab).genesearch({ asm: global.asm,
                        template_url: app_url + TEMPLATE.BYFUNC,
                        query_url: app_url + SERVICE.BYFUNC,
                        complete: _genesearch_complete_fun
                    });
                    
                    def.resolve();
                }]);
            }).promise();
        },
        
        __deps__: function() {
            return ['gis.basic.panel.left', 'gis.basic.panel.bottom', 'gis.basic.tracklist'];
        }
    };
})());

// START WIDGET ----------------------------------------------------------

(function ($) {
    $.widget("gis.genesearch", {
        options: {
            asm: '', // required
            template_url: '', // required
            query_url: '' // required
        },

        _templEntry: [
            '<tr><td rowspan="${rowspan}">',
            '<a class="external" href="http://www.ncbi.nlm.nih.gov/gene?term=${sym}" target="_blank">${sym}</a>',
            '</td>',
            '<td rowspan="${rowspan}">{{html func}}</td>',
            '<td>${acc}</td>',
            '<td><a class="genelink" style="white-space: nowrap" href="#">',
            '${chrom}:${start}-${end}</a></td>',
            '<td>${strand}</td></tr>'
        ].join('\n'),

        _templSubentry: [ 
            '<tr><td>${acc}</td>',
            '<td><a class="genelink" style="white-space: nowrap" href="#">',
            '${chrom}:${start}-${end}</a></td>',
            '<td>${strand}</td></tr>'
        ].join('\n'),

        _fillResultTable: function (tbody, data) {
            $.template('Entry', this._templEntry);
            $.template('SubEntry', this._templSubentry);
            
            _.each(data, function(g) {
                var rowspan = g.accs.length,
                    funcstr = '<ol class="linenums">';

                _.each(g.func || [], function(f) {
                    if (f.func) {
                        funcstr += '<li>' + f.func + ' (' + f.role + '-' + f.type + ')</li>';
                    }
                });

                funcstr += '</ol>';
                var x = g.accs[0];
                $.tmpl('Entry', {
                    sym: g.sym,
                    func: funcstr,
                    acc: x.name,
                    rowspan: rowspan,
                    chrom: x.chrom,
                    start: x.start,
                    end: x.end,
                    strand: x.strand
                }).appendTo(tbody);

                for (var j = 1; j < g.accs.length; j++) {
                    var x = g.accs[j];
                    $.tmpl('SubEntry', {
                        acc: x.name,
                        chrom: x.chrom,
                        start: x.start,
                        end: x.end,
                        strand: x.strand
                    }).appendTo(tbody);
                };
            });
        },

        _doSearch: function() {
            var self = this, 
                    el = this.element,
                    form = el.find('form');

            if (form.find('input:text[name=name]').val() == '' && form.find('input:text[name=func]').val() == '') return;
            form.find('input:hidden[name=asm]').val(this.options.asm);
            
            params = $(form).serialize();
            form.find('button').button('searching');
            
            $.getJSON(this.options.query_url, params, function(data) {
                if (data.too_many) return;

                var result = el.find('.result'),
                    table = result.find('table').addClass('table table-striped table-bordered table-condensed'),
                    tbody = table.find('>tbody');

                tbody.html('');
                self._fillResultTable(tbody, data);
                
                self._trigger('complete', null, {
                    query: form.find('input:text[name=name]').val() || form.find('input:text[name=func]').val(),
                    result: result.html()
                });
                
                form.find('button').button('reset');
            });
        },

        _setupPanel: function() {
            var self = this,
                el = this.element,
                form = el.find('form');
            
            form.submit(function() {
                self._doSearch();
                return false;
            });
        },

        _create: function() {
            var self = this, el = this.element;
            $.get(this.options.template_url, {}, function(html) {
                el.html(html);
                self._setupPanel();
            });
        }
    });
    
})(jQuery);

// END WIDGET ----------------------------------------------------------
