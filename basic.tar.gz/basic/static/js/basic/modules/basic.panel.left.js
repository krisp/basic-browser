/**
 * Provides API to perform operations on left panels
 */
BASIC.register('gis.basic.panel.left', (function() {
    var global = null,
        accordion = null,
        acc_count = 0;

	var _resize_content = function(ev, content) {
    	if (_.isUndefined(content)) {
    		content = $(this).attr('href');
    	}
    	if ($(content).hasClass('in') && ev) {
    		ev.stopPropagation();
    		ev.preventDefault();
    	}
    	var h = accordion.parent().height();
    	accordion.find('> .accordion-group > .accordion-heading').each(function() { 
    		h -= $(this).height() + 9; 
		});
    	$(content).find('> .accordion-inner').height(h);
    	
   };

    return {
        __init__: function(args, callback) {
            global = args.global;
            accordion = global.left_panel_accord;
            
            accordion.on('click', 'a.title', _resize_content);
        },
        
        __deps__: function() {
            return ['gis.basic.layout'];
        },
        
        addTab: function(title, content, callback, icon) {
            if (_.isUndefined(icon)) {
            	icon = 'icon-chevron-right';
            }
        	
            var group = $('<div>').addClass('accordion-group').appendTo(accordion),
            	head = $('<div>').addClass('accordion-heading').appendTo(group),
            	toggle = $('<a>').addClass('accordion-toggle title').attr({
            		'data-toggle': 'collapse',
           	    	'data-parent': '#' + accordion.attr('id'),
            	   	'href': '#accordion-content-' + acc_count
        	    })
        	    .append($('<i></i>').addClass(icon)).append('&nbsp;')
        	    .append($('<span>').html(title))
        	    .appendTo(head),
            	body = $('<div>').addClass('accordion-body collapse').attr({
            	  	'id': 'accordion-content-' + acc_count
            	}).appendTo(group),
            	div = $('<div>').addClass('accordion-inner').css({ 'overflow-y': 'auto' }).appendTo(body);
           	   
           if (_.isString(content)) {
               div.html(content);
           } else {
               div.append(content);
           }
           
           if (acc_count == 0) {
           	   body.addClass('in');
       	   }
       	   
       	   accordion.find('> .accordion-group > .accordion-body.in').each(function() {
       	       _resize_content(null, $(this));
       	   });
       	   
           acc_count++;
           if (callback != null) callback(div);
        },
        
        toggle: function() {
                if (global.no_panel_op) return;
                var ev = global.left_panel.offset().left < 0
                         ? BASICEvent.PANEL_LEFT_SHOW
                         : BASICEvent.PANEL_LEFT_HIDE;
                $.publish(ev);
        },
        
        show: function() {
            if (global.left_panel.offset().left < 0) { // show
                global.left_panel.animate({ left: '+=' + global.left_panel.width() }, {
                    step: global.fun_left,
                    complete: function() {
                        $.publish(BASICEvent.WIN_RESIZE);
                        global.left_panel.resizable('enable');
                        global.left_sep.removeClass('collapsed');
                        BASIC_local(BASICStorage.PANEL_LEFT_HIDDEN, false);
                        global.basic_navbar.find('.menu-panel-left').removeClass('panel-hide').addClass('panel-show');
                    }
                });
            }
        },
        
        hide: function(animDur) {
            if (global.left_panel.offset().left >= 0) { // hide
                global.left_panel.animate({ left: '-=' + global.left_panel.width() }, {
                    step: global.fun_left,
                    duration: animDur || 400,
                    complete: function() { 
                        $.publish(BASICEvent.WIN_RESIZE);
                        global.left_panel.resizable('disable');
                        global.left_sep.addClass('collapsed').show(); // resist the effect of disable()
                        BASIC_local(BASICStorage.PANEL_LEFT_HIDDEN, true);
                        global.basic_navbar.find('.menu-panel-left').removeClass('panel-show').addClass('panel-hide');
                    }
                });
            }
        }
    };
})());