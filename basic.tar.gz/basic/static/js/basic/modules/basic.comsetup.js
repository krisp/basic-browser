BASIC.register('gis.basic.comsetup', (function() {
    var global = null,
        print_friendly = null;
    
    return {
        __init__: function(args) {
            var self = this;
            global = args.global;
            print_friendly = args.print_friendly;
            
            return $.Deferred(function(def) {
                $.publish('gis.basic.bootstrap.getChromInfo', function(info) {
                    $.publish('gis.basic.corenav.getLocation', function(loc) {
                        self._setupComponents(info.bands, loc.chrom, loc.start, loc.end);
                        def.resolve();
                    });
                });
            }).promise();
        },
        
        __deps__: function() {
            return ['gis.basic.corenav'];
        },

        /*
         * PRIVATE FUNCTIONS 
         */
        
        _setupChromViewers: function(chrbands, chrom) {
            // setup full chrom viewer
            global.full_chrom_view.chromview({
                bands: chrbands,
                chrom: chrom,
                color: '#08c',
                position: 'top',
                stop: function (ev, ui) { $.publish(BASICEvent.NAV_ZOOM_TO, [null, ui.start, ui.end]); }
            });
            
            // setup partial chrom viewer (connected to full viewer above)
            global.part_chrom_view.css({ 'margin-top': '-0.5em' }).chromview({
                bands: chrbands,
                chrom: chrom,
                color: '#08c',
                selectorVisible: false,
                position: 'bottom',
                stop: function (ev, ui) { $.publish(BASICEvent.NAV_ZOOM_TO, [null, ui.start, ui.end]); }
            });
            
            var fun = function(ev, d) {
                ev.preventDefault();
                $.publish(d < 0 ? BASICEvent.NAV_ZOOM_IN : BASICEvent.NAV_ZOOM_OUT); 
            };
            global.full_chrom_view.mousewheel(fun);
            global.part_chrom_view.mousewheel(fun);
        },
        
        _setupComponents: function(chrbands, chrom, start, end) {
            this._setupChromViewers(chrbands, chrom);
            
            global.acgt_view.acgtview({
                asm: global.asm,
                source: BASICService.CHROME_ACGT
            }).acgtview('setLocation', chrom, start, end);

            global.awsum_bar.awesome({
                asm: global.asm,
                url: BASICService.GENOME_LOCATION_PARSER,
                location: { chrom: chrom, start: start, end: end },
                anchor: global.full_chrom_view // used to determine location when [pencil] is active
            });
            
            global.track_holder.sortable({
                axis: 'y',
                handle: '.ordering-handle',
                forcePlaceholderSize: true,
                placeholder: 'alert',
                items: 'li',
                start: function (ev, ui) {
                    $.publish(BASICEvent.TRACK_ALLOW_SLIDE, [false]);
                    ui.item.fadeTo('fast', 0.7);
                },
                stop: function (ev, ui) {
                    ui.item.fadeTo('fast', 1);
                    $.publish(BASICEvent.TRACK_ALLOW_SLIDE, [true]);
                    $.publish(BASICEvent.TRACK_CHANGE);
                }
            });
            
            global.control_panel.css({ height: global.control_panel.height() + 2 });
            
            if (! print_friendly) {
                global.center_panel.css({
                    height: global.middle_panel.height() - global.control_panel.height()
                });
            }
        }
    };
})());
