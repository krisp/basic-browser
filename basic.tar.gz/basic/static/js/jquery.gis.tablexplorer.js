(function ($) {
    $.widget('gis.linkpopup', {
        options: {
            mousePos: {} // X and Y
        },
        
        _create: function() {
            var self = this,
                el = this.element,
                mousePos = this.options.mousePos;

            var div = $('<div>').addClass('ui-corner-all basic-tablexplorer linkpopup').hide();
            
            var table = $('<table>').addClass('table-condensed').appendTo(div),
                tbody = $('<tbody>').appendTo(table);
            
            links = $(el).data('links');
            tbody.on('click', 'a', function(ev) {
                ev.preventDefault();
                self._trigger('click', ev, $(this).data('val'));
            });
            
            for (var i in links) {
                var val = links[i],
                    tr = $('<tr>').appendTo(tbody);
                    
                var td1 = $('<td>').appendTo(tr).append($('<strong>').text(val.caption)),
                    td2 = $('<td>').appendTo(tr),
                    s = val.start,
                    e = val.end,
                    text = val.chrom + ':' + s + '-' + e + ' (' + BASIC_intComma(e-s+1) + ')';
                
                $('<a href="#">').data('val', val).text(text).appendTo(td2);
            }
            
            div.mouseleave(function() {
                div.fadeOut(function() { div.remove(); });
                el.linkpopup('destroy');
            }).appendTo($('body'));
            
            var w = $(window).width();
            if (mousePos.X + div.width() < w-10) {
                div.css({ left: mousePos.X-5 });
            } else {
                div.css({ right: w-mousePos.X-5 });
            }

            var h = $(document).height();
            if (mousePos.Y + div.height() < h-10) {
                div.css({ top: mousePos.Y-5 });
            } else {
                div.css({ bottom: h-mousePos.Y-5 });
            }
            div.show();
        }
    });
})(jQuery);
        
(function ($) {
    $.widget('gis.tablexplorer', {
        options: {
            url: null, // required
            table_id: null, // required
            extra_params: {}, // included when making request to URL
            limit: 100, // number of records fetched at a time
            popup: true, // show a popup of links when clicked
            scrollTarget: null, // if null, default=this.element
            max_length: 30, // maximum length of text in cell before it gets shortened

	        _vars: { // to store variables global to this component
	            reload_in_progress: false,
	            order: []
	        }, 
        },
        
        _refresh_sorticons: function() {
            this.options._vars.thead.find('> tr.header > th').each(function() {
                var icon = $('span', this), v = $(this).data('order');
                if (v == '-') {
                    icon.removeClass().addClass('ui-icon ui-icon-triangle-1-s');
                } else if (v == '+') {
                    icon.removeClass().addClass('ui-icon ui-icon-triangle-1-n');
                } else {
                    icon.removeClass().addClass('ui-icon ui-icon-triangle-2-n-s');
                }
            });
        },

        _set_click_ev: function (th, col_name) {
            var self = this,
                vars = this.options._vars,
                thead = vars.thead;
            
            th.click(function(ev) {
                var v = $(this).data('order');
                if (! ev.shiftKey) {
                    // reset the ordering of all
                    vars.order = [];
                    thead.find('> tr.header > th').each(function() {
                        $(this).data('order', null);
                    });
                }

                var order = vars.order;
                // delete existing sorting with the same key
                for (var i in order) {
                    if (order[i] == col_name || order[i] == '-' + col_name) {
                        order.splice(i, 1);
                        break;
                    }
                }

                if (v == '+') { // ascending -> desc
                    order.push('-' + col_name);
                    $(this).data('order', '-');
                } else if (v == null || v == '-') { // none/desc -> asc
                    order.push(col_name);
                    $(this).data('order', '+');
                }

                self._refresh_sorticons();
                vars.offset = 0;
                self._reload('reset');
            });
        },

        _make_tr_header_btns: function(td, column) {
            td.html(column.longname);
            if (column.sort) {
                td.data('order', null);
                $('<span>').addClass('ui-icon ui-icon-triangle-2-n-s').appendTo(td);
            }
        },

        _make_links: function(tr, row, col_idx, data) {
            var links = [];
            for (var caption in (data.links || [])) {
                var link = data.links[caption],
                    c = row[col_idx[link[0]]],
                    s = row[col_idx[link[1]]],
                    e = row[col_idx[link[2]]];
                    
                if (e < s) { var _ = e; e = s; s = _; }
                links.push({ caption: caption, chrom: c, start: s, end: e });
            }
            
            tr.data('links', links);
        },
        
        _make_td: function(j, row, data) {
            var t = data.columns[j].type,
                is_int = (t == 'int'),
                is_float = (t == 'float'),
                td = $('<td>').css({ 'text-align': (is_int || is_float ? 'right' : 'left') });

            var content = null;
            if (is_int) {
                // add thousands separator
                content = BASIC_intComma(row[j]);
            } else if (is_float) {
                content = '' + (row[j] != null ? row[j].toPrecision(4) : '');
            } else {
                content = '' + (row[j] != null ? row[j] : '');
            }

            var maxlen = this.options.max_length;
            if (content.length < maxlen) {
                td.text(content);
            } else {
                $('<span>').addClass('long').text(content).hide().appendTo(td);
                $('<span>').addClass('short').text(content.substring(0, maxlen) + '...').appendTo(td);
            }
            
            return td;
        },
        
        _make_tr_header: function(data) {
            var thead = this.options._vars.thead,
                tr = $('<tr>').addClass('header').disableSelection().appendTo(thead);
                
            col_idx = this.options._vars.col_idx = {};

            for (var i in data.columns) {
                var col = data.columns[i],
                    th = $('<th>').appendTo(tr);
                    
                col_idx[col.name] = i;
                this._make_tr_header_btns(th, col);
                
                if (col.sort) {
                    this._set_click_ev(th, col.name);
                }
            }
        },
        
        _make_tr_filter: function(data) {
            var self = this,
                thead = this.options._vars.thead,
                tr = $('<tr>').addClass('filter').appendTo(thead);
                
            for (var i in data.columns) {
                var col = data.columns[i],
                    th = $('<th>').appendTo(tr);
                
                if (! col.sort) continue;
                
                $('<input>').attr({
                    type: 'text',
                    placeholder: col.name,
                }).addClass('input-mini').appendTo(th);
            }
            
            tr.on('keyup', 'input', function(ev) {
                if (ev.which != 13) return; // only respond to [enter]
                self._reload('reset');
            });
        },

        _onload_json: function(data, mode) {
            var self = this,
                opts = this.options,
                vars = this.options._vars;
            
            var thead = vars.thead,
                tbody = vars.tbody;
            
            // HEADER
            if (mode == 'init') {
                this._make_tr_header(data);
                this._make_tr_filter(data);
            } else if (mode == 'reset') {
                tbody.empty();
            }
            
            // ENTRIES
            for (var i in data.entries) {
                var row = data.entries[i],
                    tr = $('<tr>').appendTo(tbody).data('item', row);

                if (opts.popup) {
                    // col_idx: dict of {column name -> position in header array}
                    this._make_links(tr, row, vars.col_idx, data);
                }
                
                // columns
                for (var j in row) {
                    var td = this._make_td(j, row, data);
                    tr.append(td);
                }
            }
        },
        
        _make_filter_params: function() {
            var filters = {};
            this.options._vars.thead.find('tr.filter input').each(function() {
                var val = $(this).val();
                if (val !== '') {
                    filters['_f_' + $(this).attr('placeholder')] = val;
                }
            });
            return filters;
        },
        
        _reload: function(mode) {
            var self = this,
                opts = this.options,
                vars = this.options._vars;
            
            if (vars.reload_in_progress) return;
            
            var filters = this._make_filter_params();
            
            var params = $.extend({}, opts.extra_params, filters, {
                table_id: opts.table_id,
                limit: opts.limit,
                offset: vars.offset,
                order: vars.order.join(',')
            });
            
            vars.reload_in_progress = true;
            $.getJSON(opts.url, params, function (data) {
                self._onload_json(data, mode);
            }).complete(function() {
                vars.reload_in_progress = false;
            });
        },

        _make_download_btn: function() {
            var self = this;
            return $('<button>')
                .addClass('btn')
                .css({ 'margin-bottom': '1em' })
                .append($('<i>').addClass('icon-download-alt'))
                .append(' Download')
                .click(function(ev) {
                    self._trigger('download', ev, $.extend({
                        table_id: self.options.table_id, 
                        order: self.options._vars.order.join(','),
                    }, self._make_filter_params()));
                });
        },

        _make_clearfilter_btn: function() {
            var self = this;
            return $('<button>')
                .addClass('btn')
                .css({ 'margin-bottom': '1em' })
                .append($('<i>').addClass('icon-remove'))
                .append(' Clear filter')
                .click(function(ev) {
                    self.options._vars.thead.find('tr.filter input').val('');
                    self._reload('reset');
                });
        },

        _create: function() {
            var self = this,
                opts = this.options,
                el = this.element,
                vars = this.options._vars;
            
            vars.thead = $('<thead>');
            vars.tbody = $('<tbody>');
            vars.table = $('<table>').addClass('basic-tablexplorer table table-striped table-bordered table-condensed');

            if (opts.popup) {
                vars.tbody.on('click', 'tr', function(ev) {
                    $(this).linkpopup({ 
                        'mousePos': { X: ev.pageX, Y: ev.pageY },
                        'click': function(ev, ui) { self._trigger('click', ev, ui); }
                    });
                });
            } else {
                vars.tbody.on('click', 'tr', function(ev) {
                    self._trigger('click', ev, { item: $(this).data('item') });
                });
            }
            
            vars.tbody.on('mouseenter', 'td', function() {
                $(this).find('.long').show().end().find('.short').hide();
            }).on('mouseleave', 'td', function() {
                $(this).find('.short').show().end().find('.long').hide();
            });
            
            var btn_grp = $('<div>').addClass('btn-group').appendTo(el);
            btn_grp.append(this._make_download_btn());
            btn_grp.append(this._make_clearfilter_btn());
            
            vars.table.append(vars.thead).append(vars.tbody).appendTo(el); 
            vars.offset = 0; // read from 1st record in database
            
            // auto-load mechanism
            var scrollTarget = opts.scrollTarget ? $(opts.scrollTarget) : $(el);
              scrollTarget.on('scroll', function() {
                  if (scrollTarget.scrollTop() + scrollTarget.height() >= vars.table.height()-10) {
                      vars.offset += opts.limit;
                      self._reload(); // neither 'init' or 'reset'
                  }
              });
            
            this._reload('init');
        }
    });
})(jQuery);
