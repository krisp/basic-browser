/**
 * Fabi. Aug 2010.
 */
(function ($) {
    function _get(dict, key, altval) {
        if (dict == null) return altval;
        else {
            if (dict[key] == null) return altval;
            return dict[key];
        }
    }
    
    $.widget("gis.trfactrack", $.gis.abstrack, {
        // @Override
        _drawPlot: function (values, quick) {
            var opts = this.options;
            if (!values) {
                values = opts._values;
            }
            opts._canvas.css({
                height: (opts._canvas.height()),
                width: (opts._canvas.width())
            });

            var self = this,
                params = {
                    data: values,
                    colors: _get(opts._options, "colors", "black"),
                    start: opts.location.start,
                    end: opts.location.end,
                    quick: quick,
                    showPos: _get(opts._options, "showPos", true),
                    showSize: _get(opts._options, "showSize", true),
                    showLabel: _get(opts._options, "showLabel", true)
                },
                trfacLinks = $(opts._canvas).trfacplot(params);
                
            if (!quick) {
                for (var i = 0; i < trfacLinks.length; i++) {
                    var link = trfacLinks[i][1];

                    (function () {
                        var trfac = trfacLinks[i][0];
                        link.click(function (ev) {
                            self._trigger("click", ev, {
                                item: self.element, 
                                chrom: trfac.chrom,
                                start: trfac.start,
                                end: trfac.end
                            });
                        });
                    })();
                }
            }
        },

        // @Override
        _quickRefresh: function () {
            if (this.options._isHidden) return;
            if (!this.options._prevLocation) return;
            this._drawPlot(null, true);
        },

        // @Override
        _fullRefresh: function (forced) {
            var opts = this.options;
            if (opts._isHidden) return;
            if (!opts._dirty && !forced) return;

            opts._options = BASIC_recurseval(opts.options || {}); // global settings
            opts._series = BASIC_recurseval(opts.series || {});    // series-specific settings

            var track = opts._track,
                maxpets = _get(opts._options, "limit", 10000);

            var l = opts.location.start,
                    r = opts.location.end,
                    params = {
                        tid: opts.tid,
                        chrom: opts.location.chrom,
                        start: l,
                        end: r,
                        max: maxpets
                    };

            if (opts.source) {
                // HACK!! This is a very crude way to say that there's a "source" defined
                // so that the backend will respond differently
                params.srckey = "hack";
            }
            
            // keep previous values
            opts._prevLocation = null;
            prev = {};
            $.extend(prev, opts.location);
            opts._prevLocation = prev;

            var self = this;
                    
            return $.Deferred(function(def) {
                $.getJSON(opts.url, params, function (data) {
                    if (data.length > maxpets) {
                        data = []; // don't bother drawing
                        opts._content.addClass("ui-widget-overlay");
                    } else {
                        opts._content.removeClass("ui-widget-overlay");
                    }
    
                    opts._values = data;
                    self._drawPlot();
                    opts._dirty = false;
                    self._trigger("refresh", null, {
                        self: self.element,
                        start: opts.location.start,
                        end: opts.location.end
                    });
                    def.resolve();
                }).error(function() { 
                    def.reject(); 
                });
            }).promise();
        } //end fullRefresh
    });
})(jQuery);