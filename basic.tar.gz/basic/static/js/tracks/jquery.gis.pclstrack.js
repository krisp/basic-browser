/**
 * Fabi. Aug 2010.
 */
(function ($) {
  var INTER1 = 0,
      INTER2 = 1,
      INTRA  = 2,
      MIN_ANCHOR_WIDTH = 3,
      MIN_CONNECTOR_LENGTH = 10,
      _DEFAULT_GLYPH_HEIGHT = 8,
      _DEFAULT_GLYPH_POSTPAD = 12;
  
  var _drawHLine = $.gis.basic.helpers.plot._drawHLine,
      _drawAnchor = $.gis.basic.helpers.plot._drawClusterAnchor;

  $.widget("gis.pclstrack", $.gis.b_rowtrack, {
    
    options: {
      showLabel: false,
      label: '${label}',
      tooltip: '${chrom}:${start}-${end} -> ${chrom2}:${start2}-${end2} (${score})',
      orderBy: 'score',
      glyph: {
        colors: "black",
        height: _DEFAULT_GLYPH_HEIGHT,
        prepad: 0,
        postpad: _DEFAULT_GLYPH_POSTPAD,
        clickable: true
      }
    },

    _sortItems: function(items, start, end, loc) {
      // default sort: try to sort by score descending
      var ordby = this.options.orderBy;
      return items.sort(function(p,q) {
        if (p[ordby] < q[ordby]) {
          return 1; // descending
        } else if (p[ordby] > q[ordby]) {
          return -1;
        }

        // if failed, use similar strategy as paired-tag sorting
        var pHead = (p.chrom===loc.chrom && loc.start<=p.start && p.start<loc.end) ? p.start : null,
            pTail = (p.chrom2===loc.chrom && loc.start<=p.start2 && p.start2<loc.end) ? p.start2 : null;
        var qHead = (q.chrom===loc.chrom && loc.start<=q.start && q.start<loc.end) ? q.start : null,
            qTail = (q.chrom2===loc.chrom && loc.start<=q.start2 && q.start2<loc.end) ? q.start2 : null;
        var pScore = (pHead!=null?1:0) + (pTail!=null?1:0),
            qScore = (qHead!=null?1:0) + (qTail!=null?1:0),
            score = pScore-qScore;
    
        if (score != 0) return -score;
        return Math.min(pHead,pTail)-Math.min(qHead,qTail);
      });
    },
    
    _preprocess: function(items) {
      var chrom = this.options.location.chrom; // from [abs-track]
      for (var i in items) {
        var it = items[i];
        if (it.chrom === chrom) {
          it.type = (it.chrom2 === chrom) ? INTRA : INTER1;
        } else {
          it.type = INTER2;
        }
        this._determineStartEnd(it);
      }
      
      this.options.glyph.postpad = this.options.showLabel ? _DEFAULT_GLYPH_POSTPAD : 2;
    },
    
    _determineStartEnd: function(pcls) {
      var start, end;
      
      if (pcls.type == INTER1) {
        // head anchor visible
        start = pcls.start;
        end = pcls.end;
        link = [pcls.chrom2, pcls.start2, pcls.end2];
      } else if (pcls.type == INTER2) {
        // tail anchor visible
        start = pcls.start2;
        end = pcls.end2;
        link = [pcls.chrom, pcls.start, pcls.end];
      } else {
        if (pcls.start < pcls.start2) {
          start = pcls.start;
          end = pcls.end2;
        } else {
          start = pcls.start2;
          end = pcls.end;
        }
        link = [pcls.chrom, start, end];
      }
      
      pcls._link = link;
      pcls._start = start;
      pcls._end = end;
      pcls._text = this._makeLabel(pcls);
      pcls._tooltip = this._makeLabel(pcls, this.options.tooltip);
    },
    
    _drawItem: function(canvas, x, y, w, h, pcls, colors, c) { 
      var ctx = canvas.getContext("2d"),
          cstart = Math.max(1, c(pcls._start)),
          cend = Math.min(c(pcls._end+1), w),
          hRatio = h/8;

      ctx.save();
      ctx.translate(0, y + h / 2);
      ctx.lineWidth = 1;

      ctx.strokeStyle = this._getColor(colors, "line", pcls);
      
      if (pcls.type == INTER1) { // 5'
        if (pcls.strand == '+') _drawHLine(ctx, cend, cend + MIN_CONNECTOR_LENGTH, 0);
                            else _drawHLine(ctx, cstart - MIN_CONNECTOR_LENGTH, cstart, 0);
      } else if (pcls.type == INTER2) { // 3'
        if (pcls.strand2 == '+') _drawHLine(ctx, cstart - MIN_CONNECTOR_LENGTH, cstart, 0);
                            else _drawHLine(ctx, cend, cend + MIN_CONNECTOR_LENGTH, 0);
      } else {
        _drawHLine(ctx, Math.max(1, cstart), Math.min(cend, w), 0);
      }

      // 1a. draw anchors - left
      if (pcls.type != INTER2) { 
        ctx.strokeStyle = this._getColor(colors, "head", pcls);
        ctx.fillStyle = this._getColor(colors, "hfill", pcls);
        var cx0 = c(pcls.start),
            cx1 = c(pcls.end+1);
        if (cx1-cx0 <= 5) cx1 = cx0 + MIN_ANCHOR_WIDTH; // minimal drawn width
        var prot = 0;
        if (pcls.strand == "+") prot = 1; else if (pcls.strand == "-") prot = -1;
        _drawAnchor(ctx, cx0, -3 * hRatio, cx1 - cx0, 6 * hRatio, prot, prot);
      }

      // 1b. draw anchors - right
      if (pcls.type != INTER1) {
        ctx.strokeStyle = this._getColor(colors, "tail", pcls);
        ctx.fillStyle = this._getColor(colors, "tfill", pcls);
        var cx0 = c(pcls.start2),
            cx1 = c(pcls.end2+1);
        if (cx1-cx0 <= 5) cx1 = cx0 + MIN_ANCHOR_WIDTH; // minimal drawn width
        var prot = 0;
        if (pcls.strand2 == "+") prot = 1; else if (pcls.strand2 == "-") prot = -1;
        _drawAnchor(ctx, cx0, -3 * hRatio, cx1 - cx0, 6 * hRatio, prot, prot);
      }

      if (this.options.showLabel) {
        // 5. write symbol/accession
        ctx.fillStyle = this._getColor(colors, "text", pcls);
        ctx.font = "normal 9px sans-serif";
  
        if (pcls.type == INTER1) {
          if (pcls.strand == "+") {
            ctx.textAlign = "left";
            ctx.fillText(pcls._text, cstart, 6 * hRatio + 6);
          } else {
            ctx.textAlign = "right";
            ctx.fillText(pcls._text, cend, 6 * hRatio + 6);
          }
        } else if (pcls.type == INTER2) {
          if (pcls.strand2 == "+") {
            ctx.textAlign = "left";
            ctx.fillText(pcls._text, cstart, 6 * hRatio + 6);
          } else {
            ctx.textAlign = "right";
            ctx.fillText(pcls._text, cend, 6 * hRatio + 6);
          }
        } else {
          ctx.textAlign = "center";
          ctx.fillText(pcls._text, cstart+Math.round((cend-cstart)/2), 6 * hRatio + 6);
        }
      }

      ctx.restore();
    },

    _measureWidth: function(canvas, w, pcls, c) {
      // determine which part of canvas will be used to draw given pcls
      var ctx = canvas.getContext("2d");

      var cstart = Math.max(1, c(pcls._start)),
          cend = Math.min(w, c(pcls._end+1)),
          actualWidth = Math.max(cend-cstart, this.options.showLabel ? ctx.measureText(pcls._text).width : 0);

      if (pcls.type == INTER1) {
        if (pcls.strand == "+") {
          return { start: cstart, end: cstart + actualWidth };
        } else {
          var s = Math.max(1, Math.min(cstart, cend - actualWidth));
          return { start: s, end: s + actualWidth };
        }
      } else if (pcls.type == INTER2) {
        if (pcls.strand2 == "+") {
          return { start: cstart, end: cstart + actualWidth };
        } else {
          var s = Math.max(1, Math.min(cstart, cend - actualWidth));
          return { start: s, end: s + actualWidth };
        }
      } else {
        var s = Math.max(1, Math.min(cstart, cstart + (cend - cstart - actualWidth) / 2));
        return { start: s, end: s + actualWidth };
      }
    },

    _addLinks: function(parent, canvas, y, w, h, postpad, pcls, c) {
      // determine which part of canvas will be used to draw given pcls
      var ctx = canvas.getContext("2d");

      var cstart = Math.max(1, c(pcls._start)),
          cend = Math.min(w, c(pcls._end+1)),
          actualWidth = Math.max(cend-cstart, ctx.measureText(pcls._text).width),
          left = null;

      if (pcls.type == INTER1) {
        if (pcls.strand == "+") left = cstart;
                           else left = Math.max(1, Math.min(cstart, cend - actualWidth));
      } else if (pcls.type == INTER2) {
        if (pcls.strand2 == "+") left = cstart;
                            else left = Math.max(1, Math.min(cstart, cend - actualWidth));
      } else {
        left = Math.max(1, Math.min(cstart, cstart + (cend - cstart - actualWidth) / 2));
      }

      var elem = $("<div>").css({
        position: "absolute",
        top: y,
        left: left,
        //"background-color": "rgba(255, 0, 0, 0.3)",
        width: actualWidth,
        height: h + postpad,
        cursor: "pointer"
      }).attr({
        title: pcls._tooltip
      }).appendTo(parent);
      
      return elem;
    }
  });
})(jQuery);