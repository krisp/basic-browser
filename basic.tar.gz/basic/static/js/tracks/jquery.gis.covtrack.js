/**
 * Shows visualized genomic data.
 * Fabi. Jul 2010.
 */
(function ($) {
    function _get(dict, key, altval) {
        return (dict == null) ? altval : (dict[key] || altval);
    }

    var _common_func = {
        // @Override
        _drawPlot: function (xvalues) {
            var opts = this.options;
            if (!xvalues) {
                xvalues = opts._xvalues;
            }

            opts._canvas.css({
                height: opts._canvas.height(),
                width: opts._canvas.width()
            });

            var params = {
                grid: { borderWidth: 1, reserveSpace: true },
                series: {
                    lines: { fill: false, lineWidth: 1 }
                },
                xaxis: { ticks: 0 },
                yaxis: {
                    labelWidth: BASIConst.flot.labelWidth,
                    tickFormatter: function (val, axis) {
                        if (val/1000!=0 && val%1000==0) return (val/1000) + "k";
                        return Math.round(val);
                    }
                },
                fill: true
            };

            if (xvalues.length == 1) {
                params.series.lines.fill = 1;
                params.series.lines.lineWidth = 0;
            }

            var opacity = _get(opts._options, "opacity", params.series.lines.fill);
            params.series.lines.fill = opacity;

            if (opacity != null && opacity != 1) {
                params.series.lines.lineWidth = 1; // we need clear outline
            }
            
            // extend xaxis/yaxis
            params.xaxis = $.extend(params.xaxis, _get(opts._options, "xaxis"));
            params.yaxis = $.extend(params.yaxis, _get(opts._options, "yaxis"));

            if (params.yaxis.log) {
                params.yaxis.tickFormatter = function(val) {
                    if (val < 0) {
                        val = Math.round(Math.pow(params.yaxis.log, -val)); 
                        if (Math.round(val) != val) val = val.toFixed(val < 10 ? 1 : 0);
                        if (val/1000!=0 && val%1000==0) return (-val/1000) + "k"; else return -val;
                    } else {
                        val = Math.round(Math.pow(params.yaxis.log, val)); 
                        if (Math.round(val) != val) val = val.toFixed(val < 10 ? 1 : 0);
                        if (val/1000!=0 && val%1000==0) return (val/1000) + "k"; else return val;
                    }
                };
            }
            
            $.plot(opts._canvas, xvalues, params);
            // HACK: make the font smaller for a quick'n'dirty fix to problem with text overflow
            $(opts._canvas).find('.tickLabel'); //.css({'font-size': '80%'});
        },
        
        // @Override
        _resize: function() {
            this._drawPlot();
        },
        
        // @Override
        _quickRefresh: function () {
            var opts = this.options, 
                loc = opts.location;
            
            if (!opts._prevLocation || opts._isHidden) return;

            var w = opts._canvas.width(),
                step = (loc.end - loc.start) / w,
                xvalues = [];

            for (var k in opts._xvalues) {
                var p = -Math.round((opts._prevLocation.start - loc.start) / step),
                    oldVals = opts._xvalues[k],
                    values = [];

                for (var i = 0; i < w; i++) {
                    var x = i * step + loc.start;
                    if (p >= 0 && p < w) {
                        values.push([x, oldVals.data[p][1]]);
                    } else {
                        values.push([x, 0]);
                    }
                    p += 1;
                }

                xvalues.push({
                    color: oldVals.color,
                    data: values
                });
            }

            this._drawPlot(xvalues);
        },

        _makeInitialRequest: function (url, source, params) {
            var self = this,
                opts = self.options,
                urls = {};
            
            for (var i in source) {
                urls[i] = url + "&srckey=" + i;
            }

            var deferred = $.Deferred();
            BASIC_getMultiJSON(urls, params).done(function (xdata) {
                var xvalues = [],
                    l = params.start,
                    r = params.end,
                    w = params.w,
                    step = (r-l) / w;

                var ylog = _get(_get(opts._options, "yaxis", {}), "log");
                for (var k in xdata) {
                    var values = [],
                        data = xdata[k];

                    // modifier
                    var negate = _get(opts._series, k, {}).negate;
                    
                    for (var i = 0; i < w; i++) {
                        var v = data[i];
                        if (ylog && v>0) v = Math.log(v)/Math.log(ylog);
                        if (negate) v = -v;
                        values.push([i * step + l, v]);
                    }

                    xvalues.push($.extend(_get(opts._series, k, {}), { data: values }));
                }

                opts._xvalues = xvalues;

                self._drawPlot();
                
                opts._dirty = false;
                self._trigger("refresh", null, {
                    self: self.element,
                    start: opts.location.start,
                    end: opts.location.end
                });

                deferred.resolve();
            }).fail(function() { 
                deferred.reject(); 
            });
            
            return deferred.promise();
        },

        // @Override
        _fullRefresh: function (forced) {
            var opts = this.options;

            if (opts._isHidden) return;
            if (!opts._dirty && !forced) return;

            var canvas = opts._canvas,
                l = opts.location.start,
                r = opts.location.end,
                w = canvas.width();

            var params = {
                track_id: opts.track_id,
                chrom: opts.location.chrom,
                start: l,
                end: r,
                w: Math.ceil(w)
            };
            
            // only custom-drawn tracks (not using flot) should be padded
            opts._canvas.css({ margin: 0, border: 'none', overflow: 'hidden' });

            // keep previous values
            opts._prevLocation = null;
            prev = {};
            $.extend(prev, opts.location);
            opts._prevLocation = prev;

            opts._options = BASIC_recurseval(opts.options || {}); // global settings
            opts._series = BASIC_recurseval(opts.series || {});    // series-specific settings

            var source = BASIC_recurseval(opts.source);
            if (typeof(source) == "string") source = [source];
            return this._makeInitialRequest(opts.url + '?dummy=1', source, params);
        }
    };
    
    // avg and cov have identical functionalities
    // why bother duplicating them
    $.widget("gis.covtrack", $.gis.abstrack, $.extend({}, _common_func));
    $.widget("gis.avgtrack", $.gis.abstrack, $.extend({}, _common_func));
    
})(jQuery);