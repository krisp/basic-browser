/**
 * Fabi. Aug 2010.
 */
(function ($) {
  var EXTLEN = 5; // length of tags drawn in number of pixels
  var _drawHLine = $.gis.basic.helpers.plot._drawHLine,
      _drawAnchor = $.gis.basic.helpers.plot._drawTagAnchor;

  $.widget("gis.ptagtrack", $.gis.b_rowtrack, {
    
    options: {
      caption: null, // default: no caption
      glyph: {
        colors: "black",
        height: 6,
        prepad: 0,
        postpad: 0,
        hpad: 2, // distance between glyphs (used in intersection)
      }
    },
    
    _sortItems: function(items, start, end, loc) {
      // default sort: sort using positions that are seen in the viewed region
      return items.sort(function(p,q) {
        var pHead = (p.chrom===loc.chrom && loc.start<=p.pos1 && p.pos1<loc.end) ? p.pos1 : null,
            pTail = (p.chrom2===loc.chrom && loc.start<=p.pos2 && p.pos2<loc.end) ? p.pos2 : null;
        var qHead = (q.chrom===loc.chrom && loc.start<=q.pos1 && q.pos1<loc.end) ? q.pos1 : null,
            qTail = (q.chrom2===loc.chrom && loc.start<=q.pos2 && q.pos2<loc.end) ? q.pos2 : null;
        var pScore = (pHead!=null?1:0) + (pTail!=null?1:0),
            qScore = (qHead!=null?1:0) + (qTail!=null?1:0),
            score = pScore-qScore;
        
        if (score != 0) return -score;
        return Math.min(pHead,pTail)-Math.min(qHead,qTail);
      });
    },
    
    _preprocess: function(items) {
      /*
       * Ignoring whether it's head or tail tag:
       * (+)ve strand -> extend to right (downstream)
       * (-)ve strand -> extend to left (upstream) 
       */
      var opts = this.options,
          w = opts._canvas.width(),
          loc = opts.location,
          gspan = loc.end-loc.start+1;
      
      var delta = Math.max(19, gspan*EXTLEN/w);
      for (var i in items) {
        var it = items[i];
        if (it.strand === '+') {
          it.start = it.pos1;
          it.end = it.pos1 + delta;
        } else {
          it.start = it.pos1 - delta;
          it.end = it.pos1;
        }
        if (it.strand2 === '+') {
          it.start2 = it.pos2;
          it.end2 = it.pos2 + delta;
        } else {
          it.start2 = it.pos2 - delta;
          it.end2 = it.pos2;
        }
        it.start = (it.pos1 < it.pos2) ? it.start : it.start2;
        it.end = (it.pos1 < it.pos2) ? it.end2 : it.end;
        it.reversed = it.pos1 > it.pos2; // head is after tail
      }
    },
    
    _drawItem: function(canvas, x, y, w, h, ptag, colors, c) {
      var ctx = canvas.getContext("2d"),
          hRatio = h / 8,
          cstart = c(ptag.start), 
          cend = c(ptag.end);

      if (cstart < 1 && cend > w) return; // don't draw at all if both ends are outta the viewing range

      ctx.save();
      ctx.translate(0, y + h / 2);
      ctx.lineWidth = 1;

      ctx.strokeStyle = this._getColor(colors, "line", ptag);
      _drawHLine(ctx, Math.max(1, cstart), Math.min(cend, w), 0);

      // 1a. draw anchors - left
      if (cstart >= 1) {
        ctx.strokeStyle = this._getColor(colors, "head", ptag);
        var strand = ptag.reversed ? ptag.strand2 : ptag.strand,
            start = ptag.reversed ? ptag.start2 : ptag.start,
            end = ptag.reversed ? ptag.end2 : ptag.end;
        
        var cx0 = c(start), cx1 = c(end), prot = strand == '+' ? [0,1] : [-1,0]; 
        _drawAnchor(ctx, cx0, -3 * hRatio, cx1 - cx0, 6 * hRatio, prot[0], prot[1]);
      }
      
      // 1b. draw anchors - right
      if (cend <= w) {
        ctx.strokeStyle = this._getColor(colors, "tail", ptag);
        var strand = ptag.reversed ? ptag.strand : ptag.strand2,
            start = ptag.reversed ? ptag.start : ptag.start2,
            end = ptag.reversed ? ptag.end : ptag.end2;
        
        var cx0 = c(start), cx1 = c(end), prot = strand == '+' ? [0,1] : [-1,0]; 
        _drawAnchor(ctx, cx0, -3 * hRatio, cx1 - cx0, 6 * hRatio, prot[0], prot[1]);
      }
      
      ctx.restore();
    },

    _measureWidth: function(canvas, w, ptag, c) {
      return { start: c(ptag.start), end: c(ptag.end) };
    }
    
  });
})(jQuery);