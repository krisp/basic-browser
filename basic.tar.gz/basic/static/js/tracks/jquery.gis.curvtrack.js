/**
 * Shows visualized genomic data.
 * Fabi. Jul 2010.
 */
(function ($) {
    function _get(dict, key, altval) {
        return (dict == null) ? altval : (dict[key] == null ? altval : dict[key]);
    }

    $.widget("gis.curvtrack", $.gis.abstrack, {
        // @Override
        _drawPlot: function (steps, xvalues) {
            var opts = this.options;
            if (!xvalues) xvalues = opts._xvalues;
            
            opts._canvas.css({
                height: (opts._canvas.height()),
                width: (opts._canvas.width())
            });
            
            var params = {
                curvy: true,
                opacity: _get(opts._options, 'opacity', 0.1),
                grid: { borderWidth: 1, reserveSpace: true },
                xaxis: {
                    ticks: 0,
                    min: opts.location.start,
                    max: opts.location.end
                },
                yaxis: {
                    labelWidth: BASIConst.flot.labelWidth,
                    tickFormatter: function(val, axis) {
                        if (val/1000!=0 && val%1000==0) return (val/1000) + "k";
                        return val;
                    }
                }
            };

            // extend xaxis/yaxis
            params.xaxis = $.extend(params.xaxis, _get(opts._options, 'xaxis'));
            params.yaxis = $.extend(params.yaxis, _get(opts._options, 'yaxis'));

            var yaxis_log = _get(_get(opts._options, 'yaxis', {}), 'log');
            if (yaxis_log) {
                params.yaxis.tickFormatter = function(val) {
                    if (val === 0) return 0;
                    var neg = val < 0 ? -1 : 1;
                    val = Math.round(Math.pow(yaxis_log, Math.abs(val))); 
                    if (Math.round(val) != val) val = val.toFixed(val < 10 ? 1 : 0);
                    if (val/1000!=0 && val%1000==0) return (val/1000) + "k";
                    return val * neg;
                };
            }

            $.plot(opts._canvas, xvalues, params);
        },

        // @Override
        _resize: function() {
            this._drawPlot();
        },

        // @Override
        _quickRefresh: function () {
            var opts = this.options;
            if (!opts._prevLocation || opts._isHidden) return;

            var w = opts._canvas.width(),
                step = Math.round((opts.location.end - opts.location.start) / w),
                xvalues = [];

            for (var k in opts._xvalues) { // for each data source
                var oldVals = opts._xvalues[k],
                    values = [],
                    l = opts.location.start,
                    r = opts.location.end;

                for (var i in oldVals.data) { // for each entry in series
                    var v = oldVals.data[i];
                    if ((l <= v[0] && v[0] < r) || (l <= v[1] && v[1] < r)) {
                        values.push(v);
                    }
                }

                xvalues.push({
                    color: oldVals.color,
                    strokeColor: oldVals.strokeColor,
                    data: values
                });
            }

            this._drawPlot(step, xvalues);
        },

        _makeInitialRequest: function (url, source, params) {
            var self = this,
                opts = self.options,
                urls = {};
            
            urls = [url];

            var deferred = $.Deferred();
            BASIC_getMultiJSON(urls, params).done(function (xdata) {
                var xvalues = [],
                    l = params.start,
                    r = params.end,
                    w = params.w,
                    step = Math.round((r - l) / w);

                var yaxis_log = _get(_get(opts._options, 'yaxis', {}), 'log'),
                    show_outbound = _get(_get(opts._options, 'outbound', {}), 'show', false);

                for (var k in xdata) {
                    var values = [], data = xdata[k];

                    for (var i in data) {
                        var d = data[i];
                        if (d.chrom != d.chrom2) continue; // skip inter-chrom
                        
                        var m = (d.start+d.end)/2,
                            n = (d.start2+d.end2)/2;
                    
                        if (yaxis_log) {
                            d.score = Math.log(d.score)/Math.log(yaxis_log);
                        }
                        
                        // if show_outbound=false, only show those that strictly within the viewing range
                        var modif = (Math.min(m,n) < l || Math.max(m,n) > r) ? -1 : 1;
                        if (show_outbound) {
                            values.push([Math.min(m,n), Math.max(m,n), d.score * modif]);
                        } else {
                            if (modif >= 0) values.push([Math.min(m,n), Math.max(m,n), d.score]);
                        }
                    }

                    var fillColor = _get(opts._series, k, {}).color,
                            strokeColor = _get(opts._options, 'outline') || 'auto';
                    
                    switch (strokeColor.toLowerCase()) {
                    case 'auto': 
                        strokeColor = fillColor; break;
                    case 'off':
                    case 'false':
                        strokeColor = null; break;
                    }
                    
                    xvalues.push({
                        color: fillColor,
                        strokeColor: strokeColor,
                        data: values.sort(function(p,q) { return q[2]-p[2]; })
                    });
                }

                self.options._xvalues = xvalues;

                self._drawPlot(step);
                self.options._dirty = false;
                self._trigger("refresh", null, {
                    self: self.element,
                    start: self.options.location.start,
                    end: self.options.location.end
                });

                deferred.resolve();
            }).fail(function() { 
                deferred.reject(); 
            });
            
            return deferred.promise();
        },

        // @Override
        _fullRefresh: function (forced) {
            var opts = this.options;

            if (opts._isHidden) return;
            if (!opts._dirty && !forced) return;

            var track = opts._track,
                canvas = opts._canvas,
                l = opts.location.start,
                r = opts.location.end,
                w = canvas.width();

            var params = {
                tid: opts.tid,
                chrom: opts.location.chrom,
                start: l,
                end: r,
                w: w
            };
            
            // only custom-drawn tracks (not using flot) should be padded
            opts._canvas.css({ margin: 0, border: 'none', overflow: 'hidden' });

            // keep previous values
            opts._prevLocation = null;
            prev = {};
            $.extend(prev, opts.location);
            opts._prevLocation = prev;

            opts._options = BASIC_recurseval(opts.options || {}); // global settings
            opts._series = BASIC_recurseval(opts.series || {});    // series-specific settings

            var source = BASIC_recurseval(opts.source);
            if (_.isString(source)) source = [source];
            
            return this._makeInitialRequest(opts.url, source, params);
        }
    });
})(jQuery);