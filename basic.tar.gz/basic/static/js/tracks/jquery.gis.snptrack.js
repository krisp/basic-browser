/**
 * Fabi. Aug 2010.
 * 
 * Specific Options:
 * - asm: assembly code
 * - acgt_url: JSON service that can give sequence from reference genome
 */
(function ($) {
    function _get(dict, key, altval) {
        if (dict == null) return altval;
        else {
            if (dict[key] == null) return altval;
            return dict[key];
        }
    }
    
    $.widget("gis.snptrack", $.gis.abstrack, {
        // @Override
        _drawPlot: function (values, quick) {
            var opts = this.options;
            if (!values) {
                values = opts._values;
            }
            opts._canvas.css({
                height: (opts._canvas.height()),
                width: (opts._canvas.width())
            });

            var self = this,
                params = {
                    data: values,
                    acgt: opts._acgt,
                    colors: _get(opts._options, "colors", "black"),
                    start: opts.location.start,
                    end: opts.location.end,
                    quick: quick
                },
                snpLinks = $(opts._canvas).snpplot(params);
                
            if (!quick) {
                for (var i = 0; i < snpLinks.length; i++) {
                    var link = snpLinks[i][1];

                    (function () {
                        var snp = snpLinks[i][0];
                        link.click(function (ev) {
                            self._trigger("click", ev, {
                                item: self.element, 
                                chrom: snp.chrom,
                                start: snp.start,
                                end: snp.end
                            });
                        });
                    })();
                }
            }
        },

        // @Override
        _quickRefresh: function () {
            if (this.options._isHidden) return;
            if (!this.options._prevLocation) return;
            this._drawPlot(null, true);
        },

        // @Override
        _fullRefresh: function (forced) {
            var opts = this.options;
            if (opts._isHidden) return;
            if (!opts._dirty && !forced) return;
            
            opts._options = BASIC_recurseval(opts.options || {}); // global settings
            opts._series = BASIC_recurseval(opts.series || {});    // series-specific settings

            var limit = _get(opts._options, "limit", opts.limit);

            var l = opts.location.start,
                    r = opts.location.end,
                    params = {
                        asm: opts.asm,
                        track_id: opts.tid,
                        chrom: opts.location.chrom,
                        start: l,
                        end: r,
                        limit: limit,
                        canvas_w: opts._canvas.width()
                    };

            if (opts.source) params.srckey = 'hack'; // hack: not needed until we support multiple sources 
            
            // keep previous values
            opts._prevLocation = null;
            prev = {};
            $.extend(prev, opts.location);
            opts._prevLocation = prev;

            var self = this;
                    
            return $.Deferred(function(def) {
                $.getJSON(opts.url, params, function (data) {
                    if (data.length > limit) {
                        data = []; // don't bother drawing
                        opts._content.addClass("ui-widget-overlay");
                    } else {
                        opts._content.removeClass("ui-widget-overlay");
                    }
                    
                    opts._values = data;
                    self._drawPlot(data);
                    opts._dirty = false;
                    self._trigger("refresh", null, {
                        self: self.element,
                        start: opts.location.start,
                        end: opts.location.end
                    });
                    def.resolve();
                }).error(function() { 
                    def.reject(); 
                });
            }).promise();
        } //end fullRefresh
    });
})(jQuery);