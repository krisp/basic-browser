(function ($) {
    function _flatten_props(props, defs, attrs) {
        if (attrs == null) attrs = [];
        attrs = attrs.slice(0);

        var result = {};
        for (var k in defs) {
            attrs.push(k);
            var v = defs[k], w = props[k];
            if (v.type != null) {
                result[attrs.join('.')] = $.extend({ 
                    value: w != null ? w : v['default'] 
                }, v);
            } else {
                result = $.extend(result, _flatten_props(w || {}, v, attrs));
            }
            attrs.pop();
        }
        return result;
    };

    $.widget("gis.trackconf", {
        options: {
            defs: null,
            props: null
        },
        
        _create: function() {
            var self = this,
                opts = this.options,
                defs = BASIC_recurseval(opts.defs) || {},
                props = BASIC_recurseval(opts.props) || {};

            var flat_options = _flatten_props(props.options || {}, defs.options || {}),
                flat_series = {};

            for (var i in props.series) {
                flat_series[i] = _flatten_props(props.series[i] || {}, defs.series || {});
            }

            var entries = [], // to be passed to plugin [datagrid]
                items = null;
            
            items = [];
            for (var i in flat_options) {
                items.push($.extend({
                    id: 'options.' + i, // real key used to update database (Metadata)    
                    label: i
                }, flat_options[i]));
            }
            
            // first group
            entries.push({ name: 'OPTIONS', items: items });

            for (var j in flat_series) {
                items = [];
                var seri = flat_series[j];
                for (var i in seri) {
                    items.push($.extend({
                        id: 'series.' + j + '.' + i,
                        label: i
                    }, seri[i]));
                }
                
                // subsequent groups
                entries.push({ name: 'SERIES/' + j, items: items });
            }

            var apply_btn = $('<button>')
                .prepend('<i class="icon-ok icon-white"></i>')
                .addClass('btn btn-primary')
                .css({ 'margin-bottom': '1em' })
                .append(' Apply')
                .appendTo(this.element);
            
            var dataedit = $('<div>')
                .appendTo(this.element).dataedit({
                entries: entries
            });
            
            apply_btn.on('click', function(ev) {
                var result = dataedit.dataedit('values');
                self._trigger('apply', ev, { value: result });
            });
        }
    });
})(jQuery);
