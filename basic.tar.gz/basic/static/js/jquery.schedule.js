/**
 * Schedules a function to be invoked after a delay.
 * If this method is called again before the delay is up,
 * the new delay is used.
 *
 * @author mulawadifh
 * @date  Jun 2011
 * 
 * @param name Unique identifier
 * @param delay Time before fun is executed (ms)
 * @param fun
 */

(function($) {
  var _tasks = {};
	$.schedule = function(name, delay, fun) {
    var task = _tasks[name];

    if (task != null) { // already scheduled
      clearTimeout(task.id);
    }
    
    var timer_id = setTimeout(fun, delay);
    _tasks[name] = { id: timer_id }; 
  };
})(jQuery);
