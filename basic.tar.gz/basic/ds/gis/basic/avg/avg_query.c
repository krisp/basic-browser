#include"avg.h"

struct rs_node {
	FILE *fp;
	uint64_t *StreamS;
	uint8_t *StreamG;
	unsigned int *A[3];
	unsigned int bits_count[3];
	unsigned int S_size;
	unsigned int GA_size;
	unsigned int G_bytes;
	unsigned int pS; // S pointer, absolute
	unsigned int pG; // G pointer, absolute
};
typedef struct rs_node *RS_Struct;

struct node {
	unsigned int NumOfChroms;
	unsigned int *RS_pointers;
	RS_Struct *data;
};

RS_Struct rs_init (FILE *fp, unsigned int mode)
{
	int i;
	RS_Struct s = malloc(sizeof(struct rs_node));	
	s->fp = fp;
	
	fread(&s->S_size, sizeof(unsigned int), 1, s->fp);
	fread(&s->GA_size, sizeof(unsigned int), 1, s->fp);
	fread(&s->G_bytes, sizeof(unsigned int), 1, s->fp);

	printf("Number of Segments: %u\n", s->S_size);
	printf("Number of Groups: %u\n", s->GA_size);
	
	// load the S stream
	s->pS = ftell(s->fp);
	if (mode == 2) {
		s->StreamS = malloc(s->S_size * sizeof(uint64_t));
		if (s->StreamS == NULL) {
			perror("CANT ALLOCATE ENOUGH MEMORY FOR S ARRAY");
			exit(EXIT_FAILURE);
		} else fread(s->StreamS, sizeof(uint64_t), s->S_size, s->fp);
	} else {
		s->StreamS = NULL;
		fseek(s->fp, s->S_size * sizeof(uint64_t), SEEK_CUR); // jump over it
	}
	
	// load the A arrays, mandatory
	for (i = 0; i < 3; i++) {
		s->A[i] = malloc(s->GA_size * sizeof(unsigned int));
		if (s->A[i] == NULL) {
			perror("CANT ALLOCATE ENOUGH MEMORY FOR A ARRAY");
			exit(EXIT_FAILURE);
		} else  fread(s->A[i], sizeof(unsigned int), s->GA_size, s->fp);
	}
	s->bits_count[0] = s->A[0][s->GA_size-1];
	s->bits_count[1] = s->A[1][s->GA_size-1];
	s->bits_count[2] = s->bits_count[0] + s->bits_count[1];
	printf("Total Bits: %u (%u + %u)\n", s->bits_count[2], s->bits_count[0], s->bits_count[1]);
	
	// load the G stream
	s->pG = ftell(s->fp);
	if (mode > 0) {
		s->StreamG = malloc(s->G_bytes * sizeof(uint8_t));
		if (s->StreamG == NULL) {
			perror("CANT ALLOCATE ENOUGH MEMORY FOR G ARRAY");
			exit(EXIT_FAILURE);
		} else fread(s->StreamG, sizeof(uint8_t), s->G_bytes, s->fp);
	} else s->StreamG = NULL;
	
	return s;
}

void rs_unload (RS_Struct s)
{
	int i;
	if (s != NULL) {
		if (s->StreamS != NULL)  free(s->StreamS);
		if (s->StreamG != NULL)  free(s->StreamG);
		for (i = 0; i < 3; i++)  free(s->A[i]);
		free(s);
	}
}

AVG_Struct init (char *input, unsigned int mode) {
	AVG_Struct a = malloc(sizeof(struct node));
	FILE *fp;
	int i;
	
	fp = fopen(input, "rb");
	assert(fp != NULL);
	
	fread(&a->NumOfChroms, sizeof(unsigned int), 1, fp);
	a->RS_pointers = malloc(a->NumOfChroms * sizeof(unsigned int));
	fread(a->RS_pointers, sizeof(unsigned int), a->NumOfChroms, fp);
	a->data = malloc(a->NumOfChroms * sizeof(RS_Struct));
	
	for (i = 0; i < a->NumOfChroms; i++)  {
		fseek(fp, a->RS_pointers[i], SEEK_SET);
		a->data[i] = rs_init(fp, mode);
	}
	return a;	
}

void unload (AVG_Struct a)
{
	int i;
	free(a->RS_pointers);
	fclose(a->data[0]->fp);
	for (i = 0; i < a->NumOfChroms; i++)  rs_unload(a->data[i]);
	free(a->data);
}

// binary search on the partial sum
unsigned int binary_search_A (unsigned int Q, unsigned int A[], unsigned int startpos, unsigned int endpos)
{
	unsigned int i = startpos, j = endpos, k;
	while (i < j)
		if (A[k = (i + j) / 2] > Q) j = k;
		else if (i == k) 
			if (A[i] == Q) return i;
			else return i + 1;
		else i = k;
	return i;	
}

unsigned int binary_search_A2 (unsigned int Q, unsigned int A0[], unsigned int A1[], unsigned int startpos, unsigned int endpos)
{
	unsigned int i = startpos, j = endpos, k;	
	while (i < j)
		if (A0[k = (i + j) / 2] + A1[k] > Q) j = k;
		else if (i == k) 
			if (A0[i] + A1[i] == Q) return i;
			else return i + 1;
		else i = k;
	return i;	
}

unsigned int byte_aligned_decode_from_file (FILE *fp)
{
	unsigned int i, result, buffer;
	
	// decode the data from MSB to LSB
	for (i = result = 0, buffer = 1; buffer & 1 && i < 4; i++) {
		if (fread(&buffer, sizeof(uint8_t), 1, fp) != 1) {
			perror("Read ERROR when decoding byte-aligned code");
			break;
		}
		result |= (buffer >> 1) << 7 * i;
	}
	return result;	
}

unsigned int byte_aligned_decode_from_stream (uint8_t *buffer, unsigned int *pos)
{
	unsigned int i, j, tmp, result;
	
	// decode the data from MSB to LSB
	i = result = 0; j = *pos;
	do {
		tmp = buffer[j] >> 1;
		result |= tmp << 7 * i++;
	} while (buffer[j++] & 1);
	*pos = j;
	return result;
}

unsigned int gamma_decode_select (uint64_t S, unsigned int bit, unsigned int inpos)
{
	unsigned int start_bit = S & 1, current_bit;
	unsigned int i, bits, bit_count[2];
	
	for (current_bit = start_bit, bit_count[0] = bit_count[1] = 0; ; current_bit = 1 - current_bit) {
		for (i = 63, bits = 0; i > 0; i--)
			if (!S) {
				perror("Out of S range");
				return 0;
			} else if (!(S >> i))
				bits++;
			else if (i == 63) {
				perror("Out of S range");
				return 0;
			} else {
				bit_count[current_bit] += (S >> 64 - 2 * bits - 1) - 1; // remember RLV is always bigger than 1
				S <<= 2 * bits + 1;
				break;
			}
		
		if (bit_count[bit] < inpos) continue;
		else {
			assert(current_bit == bit);
			return inpos + bit_count[1 - current_bit];
		}	
	}
}

unsigned int gamma_decode_rank (uint64_t S, unsigned int bit, unsigned int inpos)
{
	unsigned int start_bit = S & 1, current_bit;
	unsigned int i, bits, bit_count[2];
	
	for (current_bit = start_bit, bit_count[0] = bit_count[1] = 0; ; current_bit = 1 - current_bit) {
		for (i = 63, bits = 0; i > 0; i--)
			if (!S) {
				perror("Out of S range");
				return 0;
			} else if (!(S >> i))
				bits++;
			else if (i == 63) {
				perror("Out of S range");
				return 0;
			} else {
				bit_count[current_bit] += (S >> 64 - 2 * bits - 1) - 1; // remember RLV is always bigger than 1
				S <<= 2 * bits + 1;
				break;
			}
		
		if (bit_count[0] + bit_count[1] < inpos) continue;
		else if (current_bit == bit) return inpos - bit_count[1 - current_bit];
		else return bit_count[bit];
	}
}

unsigned int rank_inclusive (unsigned int bit, unsigned int pos, RS_Struct s)
{
	unsigned int i, j;
	unsigned int block, inpos, S_bit_count[2], rank;
	uint64_t S;
	
	if (pos > s->bits_count[2]) {
		perror("MAXIMUM LENGTH EXCEEDED");
		return s->bits_count[bit];
	} else if (!pos) return 0;
	else if (bit > 1) {
		perror("QUERY BIT ERROR");
		return 0;
	} else block = binary_search_A2(pos, s->A[0], s->A[1], 0, s->GA_size - 1);
	
	// if the position is in the first block
	if (!block) {
		inpos = pos;
		rank = 0;
		j = 0;
		fseek(s->fp, s->pG, SEEK_SET);
	} else {
		inpos = pos - s->A[0][block-1] - s->A[1][block-1]; // the pos inside corresponding block
		rank = s->A[bit][block-1]; // partial rank
		j = s->A[2][block-1];
		fseek(s->fp, s->pG + s->A[2][block-1], SEEK_SET);
	}	
	S_bit_count[0] = S_bit_count[1] = 0;
		
	for (i = 0; S_bit_count[0] + S_bit_count[1] < inpos; i++) {
		rank += S_bit_count[bit];
		inpos -= S_bit_count[0] + S_bit_count[1];
		
		// when stream G has been loaded into memory
		if (s->StreamG != NULL) {
			S_bit_count[0] = byte_aligned_decode_from_stream(s->StreamG, &j);
			S_bit_count[1] = byte_aligned_decode_from_stream(s->StreamG, &j);
		} else {
			S_bit_count[0] = byte_aligned_decode_from_file(s->fp);
			S_bit_count[1] = byte_aligned_decode_from_file(s->fp);
		}
	}	
	if (i > MAX_SEGMENTS_PER_GROUP) {
		perror("Out of G range");
		return 0;
	}
	
	if (s->StreamS != NULL)  rank += gamma_decode_rank(s->StreamS[MAX_SEGMENTS_PER_GROUP * block + i - 1], bit, inpos);
	else {
		fseek(s->fp, s->pS + MAX_SEGMENTS_PER_GROUP * block * sizeof(uint64_t) + (i-1) * sizeof(uint64_t), SEEK_SET);
		fread(&S, sizeof(uint64_t), 1, s->fp);
		rank += gamma_decode_rank(S, bit, inpos);
	}
	
	return rank;
}

unsigned int select_inclusive (unsigned int bit, unsigned int pos, RS_Struct s)
{
	unsigned int i, j, block;
	unsigned int inpos, S_bit_count[2], S_accumalated_bits[2], result;
	uint64_t S;
	
	if (pos > s->bits_count[bit]) {
		perror("MAXIMUM BITS EXCEEDED");
		return 0;
	} else if (!pos) return 0;
	else if (bit > 1) {
		perror("QUERY BIT ERROR");
		return 0;
	} else block = binary_search_A(pos, s->A[bit], 0, s->GA_size - 1);
	
	// if the position is in the first block
	if (!block) {
		inpos = pos;
		result = 0;
		j = 0;
		fseek(s->fp, s->pG, SEEK_SET);
	} else {
		inpos = pos - s->A[bit][block-1];
		result = s->A[0][block-1] + s->A[1][block-1];
		j = s->A[2][block-1];
		fseek(s->fp, s->pG + s->A[2][block-1], SEEK_SET);
	}

	//printf("Block NO %u PR %u\n", block, result);
	S_bit_count[0] = S_bit_count[1] = 0;
	S_accumalated_bits[0] = S_accumalated_bits[1] = 0;
	
	// search within the block
	for (i = 0; S_bit_count[bit] + S_accumalated_bits[bit] < inpos; i++) {
		//printf("Segment bit count 0: %u\n", S_bit_count[0]);
		//printf("Segment bit count 1: %u\n", S_bit_count[1]);
		S_accumalated_bits[0] += S_bit_count[0];
		S_accumalated_bits[1] += S_bit_count[1];
		
		// when stream G has been loaded into memory
		if (s->StreamG != NULL) {
			S_bit_count[0] = byte_aligned_decode_from_stream(s->StreamG, &j);
			S_bit_count[1] = byte_aligned_decode_from_stream(s->StreamG, &j);
		} else {
			S_bit_count[0] = byte_aligned_decode_from_file(s->fp);
			S_bit_count[1] = byte_aligned_decode_from_file(s->fp);
		}
	}	
	if (i > MAX_SEGMENTS_PER_GROUP) {
		perror("Out of G range");
		return 0;
	}
	
	// not in the first S array
	if (i > 1) {
		inpos -= S_accumalated_bits[bit];
		result += S_accumalated_bits[0] + S_accumalated_bits[1];
	}
	//printf("Segment NO %u PR %u\n", i, result);
	
	// when stream S is in memory
	if (s->StreamS != NULL)
		S = s->StreamS[MAX_SEGMENTS_PER_GROUP * block + i - 1];		
	else {
		fseek(s->fp, s->pS + MAX_SEGMENTS_PER_GROUP * block * sizeof(uint64_t) + (i-1) * sizeof(uint64_t), SEEK_SET);
		fread(&S, sizeof(uint64_t), 1, s->fp);
	}
	
	return result + gamma_decode_select(S, bit, inpos);
}

unsigned int average(AVG_Struct a, unsigned int chrom, unsigned int i, unsigned int j)
{
	unsigned int pi, pj, sum;
	if (!chrom || chrom > a->NumOfChroms || i > j) return 0;
	
	pi = select_inclusive(1, i-1, a->data[chrom-1]);
	pj = select_inclusive(1, j, a->data[chrom-1]);
	
	if (pj - pi == j - i) return 0;

	sum = rank_inclusive(0, pj, a->data[chrom-1]) - rank_inclusive(0, pi, a->data[chrom-1]);
	return sum /(j - i + 1);
}

unsigned int sum(AVG_Struct a, unsigned int chrom, unsigned int i, unsigned int j)
{
	unsigned int pi, pj;
	if (!chrom || chrom > a->NumOfChroms || i > j) return 0;
	
	pi = select_inclusive(1, i-1, a->data[chrom-1]);
	pj = select_inclusive(1, j, a->data[chrom-1]);
	
	if (pj - pi == j - i) return 0;
	return rank_inclusive(0, pj, a->data[chrom-1]) - rank_inclusive(0, pi, a->data[chrom-1]);
}

