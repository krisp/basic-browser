#include "countif.h"

struct rs_node {
	FILE *fp;
	uint8_t *StreamG;
	uint64_t *StreamS;
	uint32_t *A[3];
	uint32_t bits_count[3];
	uint32_t S_size;
	uint32_t GA_size;
	uint32_t G_bytes;
	uint32_t G_base_pointer;
	uint32_t S_base_pointer;
};
typedef struct rs_node *RS_Struct;

struct node {
	unsigned int length;
	unsigned int width;
	unsigned int version;
	RS_Struct *RSDS;
	FILE *fp;
};

RS_Struct rs_init (FILE *fin, unsigned int mode)
{
	int i;
	RS_Struct s = malloc(sizeof(struct rs_node));	
	s->fp = fin;
	assert(s->fp != NULL);
	
	fread(&s->S_size, sizeof(unsigned int), 1, s->fp);
	fread(&s->GA_size, sizeof(unsigned int), 1, s->fp);
	fread(&s->G_bytes, sizeof(unsigned int), 1, s->fp);

	printf("Number of Segments: %u\n", s->S_size);
	printf("Number of Groups: %u\n", s->GA_size);
	
	// load the S stream, optional
	s->S_base_pointer = ftell(s->fp);
	if (mode) {
		s->StreamS = malloc(s->S_size * sizeof(uint64_t));
		if (s->StreamS == NULL) {
			perror("CANT ALLOCATE ENOUGH MEMORY FOR S ARRAY");
			exit(EXIT_FAILURE);
		} else fread(s->StreamS, sizeof(uint64_t), s->S_size, s->fp);
	} else {
		s->StreamS = NULL;
		fseek(s->fp, s->S_size * sizeof(uint64_t), SEEK_CUR); // jump over S stream
	}
	
	// load the A arrays and G stream, mandatory
	for (i = 0; i < 3; i++) {
		s->A[i] = malloc(s->GA_size * sizeof(unsigned int));
		if (s->A[i] == NULL) {
			perror("CANT ALLOCATE ENOUGH MEMORY FOR A ARRAY");
			exit(EXIT_FAILURE);
		} else  fread(s->A[i], sizeof(unsigned int), s->GA_size, s->fp);
	}
	s->bits_count[0] = s->A[0][s->GA_size-1];
	s->bits_count[1] = s->A[1][s->GA_size-1];
	s->bits_count[2] = s->bits_count[0] + s->bits_count[1];
	printf("Total Bits: %u (%u + %u)\n", s->bits_count[2], s->bits_count[0], s->bits_count[1]);
	
	s->G_base_pointer = ftell(s->fp);
	s->StreamG = malloc(s->G_bytes * sizeof(uint8_t));
	if (s->StreamG == NULL) {
		perror("CANT ALLOCATE ENOUGH MEMORY FOR G ARRAY");
		exit(EXIT_FAILURE);
	} else fread(s->StreamG, sizeof(uint8_t), s->G_bytes, s->fp);
	
	return s;
}

CIF_Struct init (char *input)
{
	unsigned int i, *fpBase;
	CIF_Struct S = malloc(sizeof(struct node));
	
	S->fp = fopen(input, "rb");
	if (S->fp == NULL) {
		perror("ERROR");
		return NULL;
	}
	fread(&S->length, sizeof(unsigned int), 1, S->fp);
	fread(&S->width, sizeof(unsigned int), 1, S->fp);
	fread(&S->version, sizeof(unsigned int), 1, S->fp);
	printf("There are %u bases.\n", S->length);
	printf("Data width is %u bits.\n", S->width);
	
	fpBase = malloc(S->width * sizeof(uint32_t));
	fread(fpBase, sizeof(uint32_t), S->width, S->fp);
	
	S->RSDS = malloc(S->width * sizeof(RS_Struct));
	for (i = 0; i < S->width; i++) {
		fseek(S->fp, fpBase[i], SEEK_SET);
		S->RSDS[i] = rs_init(S->fp, 0); // do not load S stream
	}
	
	free(fpBase);
	printf("Structure loaded.\n");
	return S;
}

void RS_unload (RS_Struct s)
{
	int i;
	if (s != NULL) {
		if (s->StreamS != NULL)  free(s->StreamS);
		if (s->StreamG != NULL)  free(s->StreamG);
		for (i = 0; i < 3; i++)  free(s->A[i]);
		free(s);
	}
}
void unload (CIF_Struct S)
{
	int i;
	if (S == NULL) return;
	for (i = 0; i < S->width; i++)  RS_unload(S->RSDS[i]);
	fclose(S->fp);
	free(S->RSDS);
	free(S);
	printf("Structure unloaded.\n");
}

// binary search on the partial sum
unsigned int binary_search_A2 (unsigned int Q, unsigned int A0[], unsigned int A1[], unsigned int startpos, unsigned int endpos)
{
	unsigned int i = startpos, j = endpos, k;	
	while (i < j)
		if (A0[k = (i + j) / 2] + A1[k] > Q) j = k;
		else if (i == k) 
			if (A0[i] + A1[i] == Q) return i;
			else return i + 1;
		else i = k;
	return i;	
}

unsigned int byte_aligned_decode_from_file (FILE *fp)
{
	unsigned int i, result, buffer;
	
	// decode the data from MSB to LSB
	for (i = result = 0, buffer = 1; buffer & 1 && i < 4; i++) {
		if (fread(&buffer, sizeof(uint8_t), 1, fp) != 1) {
			perror("Read ERROR when decoding byte-aligned code");
			break;
		}
		result |= (buffer >> 1) << 7 * i;
	}
	return result;	
}

unsigned int byte_aligned_decode_from_stream (uint8_t *buffer, unsigned int *pos)
{
	unsigned int i, j, tmp, result;
	
	// decode the data from MSB to LSB
	i = result = 0; j = *pos;
	do {
		tmp = buffer[j] >> 1;
		result |= tmp << 7 * i++;
	} while (buffer[j++] & 1);
	*pos = j;
	return result;
}


unsigned int gamma_decode_rank (uint64_t S, unsigned int bit, unsigned int inpos)
{
	unsigned int start_bit = S & 1, current_bit;
	unsigned int i, bits, bit_count[2];
	
	for (current_bit = start_bit, bit_count[0] = bit_count[1] = 0; ; current_bit = 1 - current_bit) {
		for (i = 63, bits = 0; i > 0; i--)
			if (!S) {
				perror("Out of S range");
				return 0;
			} else if (!(S >> i))
				bits++;
			else if (i == 63) {
				perror("Out of S range");
				return 0;
			} else {
				bit_count[current_bit] += (S >> 64 - 2 * bits - 1) - 1; // remember RLV is always bigger than 1
				S <<= 2 * bits + 1;
				break;
			}
		
		if (bit_count[0] + bit_count[1] < inpos) continue;
		else if (current_bit == bit) return inpos - bit_count[1 - current_bit];
		else return bit_count[bit];
	}
}

unsigned int countbetween (unsigned int bit, unsigned int pos1, unsigned int pos2, RS_Struct s)
{
	unsigned int i, j, S_count[2], rank[2], pos[2];
	unsigned int block[2], inpos[2], addr[2];
	uint64_t S;
	
	pos[0] = pos1; pos[1] = pos2;
	
	if (pos[0] > s->bits_count[2] || pos[1] > s->bits_count[2]) {
		perror("MAXIMUM LENGTH EXCEEDED");
		return s->bits_count[bit];
	} else if (pos[0] > pos[1]) return 0;
	else if (bit > 1) {
		perror("QUERY BIT ERROR");
		return 0;
	} else if (!pos[0]) {
		block[0] = 0;
		block[1] = binary_search_A2(pos[1], s->A[0], s->A[1], 0, s->GA_size - 1);
	} else {
		block[0] = binary_search_A2(pos[0], s->A[0], s->A[1], 0, s->GA_size - 1);
		block[1] = binary_search_A2(pos[1], s->A[0], s->A[1], block[0], s->GA_size - 1);
	}
	
	for (i = 0; i < 2; i++) {
		if (!pos[i])  {
			rank[i] = 0;
			continue;
		}
		// if the position is in the first block
		if (!block[i]) {
			inpos[i] = pos[i];
			rank[i] = 0;
			addr[i] = 0;
			fseek(s->fp, s->G_base_pointer, SEEK_SET);
		} else {
			inpos[i] = pos[i] - s->A[0][block[i]-1] - s->A[1][block[i]-1]; // the pos inside corresponding block
			rank[i] = s->A[bit][block[i]-1]; // partial rank
			addr[i] = s->A[2][block[i]-1];
			fseek(s->fp, s->G_base_pointer + s->A[2][block[i]-1], SEEK_SET);
		}	
		S_count[0] = S_count[1] = 0;
			
		for (j = 0; S_count[0] + S_count[1] < inpos[i]; j++) {
			rank[i] += S_count[bit];
			inpos[i] -= S_count[0] + S_count[1];
			
			// when stream G has been loaded into memory
			if (s->StreamG != NULL) {
				S_count[0] = byte_aligned_decode_from_stream(s->StreamG, &addr[i]);
				S_count[1] = byte_aligned_decode_from_stream(s->StreamG, &addr[i]);
			} else {
				S_count[0] = byte_aligned_decode_from_file(s->fp);
				S_count[1] = byte_aligned_decode_from_file(s->fp);
			}
		}
		if (j > MAX_SEGMENTS_PER_GROUP) {
			perror("Out of G range");
			return 0;
		}
	
		if (s->StreamS != NULL)  rank[i] += gamma_decode_rank(s->StreamS[MAX_SEGMENTS_PER_GROUP * block[i] + j - 1], bit, inpos[i]);
		else {
			fseek(s->fp, s->S_base_pointer + MAX_SEGMENTS_PER_GROUP * block[i] * sizeof(uint64_t) + (j-1) * sizeof(uint64_t), SEEK_SET);
			if (fread(&S, sizeof(uint64_t), 1, s->fp))
				rank[i] += gamma_decode_rank(S, bit, inpos[i]);
		}
	}
			
	return rank[1] - rank[0];
}

unsigned int countbetween_inclusive (unsigned int bit, unsigned int pos1, unsigned int pos2, RS_Struct s)
{
	return countbetween(bit, pos1 - 1, pos2, s);
}

unsigned int countif (CIF_Struct S, unsigned int i, unsigned int j, unsigned int q)
{
	int k;
	unsigned int L, R, newL, newR, sum, current_bit, level, Si, Sj, Sij, biti;
	
	if (!i || !j || i > j) {
		perror("INPUT RANGE PARAMETERS ERROR");
		return 0;
	} else if (i > S->length || j > S->length) {
		perror("INPUT RANGE PARAMETERS ERROR");
		printf("The maximum length is %u.\n", S->length);
		return 0;
	}
	
	for (L = sum = level = 0, R = S->length, k = 15; level < 15 && k > 0; level++, k--)
		if (i > j)	return sum;		
		
		// the bit to handle is 1, ignore left part and go to right part
		else if (current_bit = q >> k & 1) {
			Sij = countbetween_inclusive(1, i, j, S->RSDS[level]);
			// there is no 1 in between, terminate the loop
			if (!Sij) return sum;
			else biti = countbetween_inclusive(1, i, i, S->RSDS[level]);
				
			newL = L + countbetween(0, L, R, S->RSDS[level]);
			Si = countbetween(1, L, i, S->RSDS[level]);
			Sj = Si + Sij;
			
			if (biti) Sj--;	
			// when there is at least one 1 before i and position i is not 0
			if (Si && biti)
				if (Sj) {
					i = newL + Si;
					j = newL + Sj;
				} else {
					perror("Boundary ERROR");
					return 0;
				}
			else if (Sj) {
				i = newL + Si + 1;
				j = newL + Sj;
			} else return sum;		
			L = newL;
		
		// the bit to handle is 0, sum the right part and go to left part
		} else {
			Sij = countbetween_inclusive(1, i, j, S->RSDS[level]);
			sum += Sij;
			
			// there is no 0 in between, terminate the loop
			if (Sij == j - i + 1) return sum;
			else biti = countbetween_inclusive(0, i, i, S->RSDS[level]);
			
			newR = L + countbetween(0, L, R, S->RSDS[level]);
			Si = countbetween(0, L, i, S->RSDS[level]);
			Sj = countbetween(0, L, j, S->RSDS[level]);
						
			// position i is 0
			if (biti) {
				i = L + Si;
				j = L + Sj;
			// position i is 1
			} else {
				i = L + Si + 1;
				j = L + Sj;
			}			
			R = newR;
		}
	
	if (q & 1) sum += countbetween_inclusive(1, i, j, S->RSDS[level]);
	else sum += j - i + 1;
	return sum;
}

