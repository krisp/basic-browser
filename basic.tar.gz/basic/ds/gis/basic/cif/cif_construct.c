#include "countif.h"

unsigned int data_width = 16;
unsigned int data_width_M1 = 15;

unsigned int floorLog2 (unsigned int n) {
	unsigned int pos = 0;
	
	if (n == 0) return pos;
	if (n >= 1<<16) { n >>= 16; pos += 16; }
	if (n >= 1<< 8) { n >>=  8; pos +=  8; }
	if (n >= 1<< 4) { n >>=  4; pos +=  4; }
	if (n >= 1<< 2) { n >>=  2; pos +=  2; }
	if (n >= 1<< 1) {           pos +=  1; }
	
	return pos;
}

// encode segment summary info into byte-aligned codes
uint8_t *byte_aligned_encoding (unsigned int S_count[][2], unsigned int *bytes_needed)
{
	unsigned int i, j, k, byte_count;
	uint8_t *G;
	
	// calculate total bytes needed
	for (byte_count = i = 0; i < MAX_SEGMENTS_PER_GROUP; i++)
		for (j = 0; j < 2; j++)
			if (S_count[i][j] > 0)
				byte_count += floorLog2(S_count[i][j]) / 7 + 1;
			else byte_count += 1;
	G = malloc(byte_count * sizeof(uint8_t));
	
	// encoding
	for (i = j = k = 0; i < MAX_SEGMENTS_PER_GROUP; i++)
		for (j = 0; j < 2; j++)
			if (S_count[i][j] > 0)
				for ( ; S_count[i][j] > 0; k++) {
					G[k] = S_count[i][j] & 0x7F;
					G[k] <<= 1;
					S_count[i][j] >>= 7;
					if (S_count[i][j] > 0)  G[k]++;
				}					
			else G[k++] = 0;
	
	assert(k == byte_count);
	*bytes_needed += byte_count;
	return G;
}

// build the RS structure for a single bit vector
void build_rs_structure (char *input, FILE *output, unsigned int first_bit)
{
	unsigned int current_bit, current_segment, S_start_bit, S_ended, G_ended;
	unsigned int bit_countS[MAX_SEGMENTS_PER_GROUP][2], bit_countG[2];
	unsigned int *A[3], RLV, RLV_Sum;
	unsigned int S_bit_count, bits_needed, G_bytes_count;
	unsigned int S_count, G_count, RLV_count, i, j;
	unsigned int *RLV_buffer;
	uint8_t **G;
	uint64_t *S;
	FILE *fp;
	
	fp = fopen(input, "r");
	assert(fp != NULL);
	
	// memory allocation
	S = malloc(MAX_GROUPS * MAX_SEGMENTS_PER_GROUP * sizeof(uint64_t));
	if (S == NULL) {
		perror("CANT ALLOCATE ENOUGH MEMORY FOR S ARRAY");
		exit(EXIT_FAILURE);
	}
	
	G = malloc(MAX_GROUPS * sizeof(uint8_t *));
	if (G == NULL) {
		perror("CANT ALLOCATE ENOUGH MEMORY FOR G ARRAY");
		exit(EXIT_FAILURE);
	}
	for (i = 0; i < MAX_GROUPS; i++) G[i] = NULL;
	
	for (i = 0; i < 3; i++) {
		A[i] = malloc(MAX_GROUPS * sizeof(unsigned int));
		if (A[i] == NULL) {
			perror("CANT ALLOCATE ENOUGH MEMORY FOR A ARRAY");
			exit(EXIT_FAILURE);
		}
		for (j = 0; j < MAX_GROUPS; j++) A[i][j] = 0;
	}
	
	assert(first_bit < 2);
	printf("Start RLV Encoding...");
	
	// initialize
	current_segment = S_count = G_count = RLV_count = 0;
	S_bit_count = G_bytes_count = S_ended = G_ended = RLV = RLV_Sum = 0;
	bit_countG[0] = bit_countG[1] = 0;
	
	for (i = 0; i < MAX_SEGMENTS_PER_GROUP; i++)
		bit_countS[i][0] = bit_countS[i][1] = 0;
	
	// read only one run-length value each time
	for (S_start_bit = current_bit = first_bit, i = j = 0; fscanf(fp, "%u", &RLV) != EOF; i++) {
		
		// RLV cant be 0 except for the first one
		if (!(RLV + i))  {
			S_start_bit = current_bit = 1 - first_bit;
			continue;
		}
		else if (!RLV) {
			perror("CHECK INPUT BITVECTOR");
			exit(EXIT_FAILURE);
		}
						
		// dealing with S array
		RLV++; // avoid encode 1
		bits_needed = 1 + 2 * floorLog2(RLV);
		// if the run length value can be put into the S array
		if (S_bit_count + bits_needed < MAX_BITS_PER_SEGMENT) {
			S[S_count] <<= bits_needed;
			S[S_count] |= RLV; // put the gamma code into it
			S_bit_count += bits_needed;
			
		// start a new S array
		} else {
			 // padding if necessary
			for ( ; S_bit_count < MAX_BITS_PER_SEGMENT; S_bit_count++) {
				S[S_count] <<= 1;
				S[S_count]++;
			}
			if (!S_start_bit) S[S_count]--; // indicate what is the start bit in this segment
			
			S[++S_count] = RLV; // start a new S array
			S_start_bit = current_bit;
			S_bit_count = bits_needed;
			S_ended = 1; // indicate that we have started a new S array;
		}
		RLV--; // restore original RLV
		
		// dealing with G array
		// when the S array is not full yet
		if (!S_ended) bit_countS[current_segment][current_bit] += RLV;
		else {
			// S ended, can encode segment summary info
			
			// reach G's maximum segments
			if (++current_segment == MAX_SEGMENTS_PER_GROUP) {
				G[G_count] = byte_aligned_encoding(bit_countS, &G_bytes_count);
				current_segment = 0;
				G_ended = 1;
			}
			// start new S bit counting
			bit_countS[current_segment][current_bit] = RLV;
			bit_countS[current_segment][1 - current_bit] = 0;		
		}
		
		// dealing with A array
		if (!G_ended) bit_countG[current_bit] += RLV;
		else {
			A[0][G_count] = bit_countG[0];
			A[1][G_count] = bit_countG[1];
			A[2][G_count] = G_bytes_count;
			bit_countG[current_bit] += RLV;
			if (++G_count == MAX_GROUPS) {
				perror("NUMBER OF GROUPS REACHES THE MAXIMUM");
				exit(EXIT_FAILURE);
			}
		}
		
		// update
		RLV_count++;
		RLV_Sum += RLV;
		current_bit = 1 - current_bit;
		S_ended = G_ended = 0;
	}
	
	// dealing with the last S
	for (; S_bit_count < MAX_BITS_PER_SEGMENT; S_bit_count++, S[S_count]++) S[S_count] <<= 1; // padding
	if (!S_start_bit) S[S_count]--; // indicate the start bit
	S_count++;
	
	// dealing with the last G and A	
	while (++current_segment < MAX_SEGMENTS_PER_GROUP)
		bit_countS[current_segment][0] = bit_countS[current_segment][1] = 0;
		
	G[G_count] = byte_aligned_encoding(bit_countS, &G_bytes_count);
	A[0][G_count] = bit_countG[0];
	A[1][G_count] = bit_countG[1];
	A[2][G_count] = G_bytes_count;
	G_count++;
	
	printf("Encode Finished.\n");
	printf("Number of RLVs: %u\n", RLV_count);
	printf("Total Bits: %u (%u + %u)\n", RLV_Sum, bit_countG[0], bit_countG[1]);
	printf("Number of Segments: %u\n", S_count);
	printf("Number of Groups: %u\n", G_count);
	printf("Total bytes for G stream: %u\n", G_bytes_count);
	fclose(fp);
	
	printf("Writing Data to File....");
	// meta-data
	fwrite(&S_count, sizeof(unsigned int), 1, output);
	fwrite(&G_count, sizeof(unsigned int), 1, output);
	fwrite(&G_bytes_count, sizeof(unsigned int), 1, output);
	
	// S array
	fwrite(S, sizeof(uint64_t), S_count, output); free(S);
	
	// A arrays
	for (i = 0; i < 3; i++)
		fwrite(A[i], sizeof(unsigned int), G_count, output);
	free(A[0]);	free(A[1]);
	
	// G stream
	fwrite(G[0], sizeof(uint8_t), A[2][0], output); free(G[0]);
	for (i = 1; i < G_count; i++) {
		fwrite(G[i], sizeof(uint8_t), A[2][i] - A[2][i-1], output);
		free(G[i]);
	} free(A[2]); free(G);

	printf("Written Completed.\n");
}

void build_rank9_structure (char *input, FILE *output, unsigned int first_bit, unsigned int length)
{
	uint32_t i, j, k, RLV, current_bit, current_capacity;
	uint32_t count1_global, count1_local, overflow;
	uint64_t *bv, *prank, tmp;
	FILE *fp;
	
	fp = fopen(input, "r");
	assert(fp != NULL);
	
	bv = malloc(((length / 320 + 1) * 5 + 1) *sizeof(uint64_t));
	prank = malloc((length / 320 + 1) * sizeof(uint64_t));
	//printf("%u %u\n", (length / 320 + 1) * 5 + 1, length / 320 + 1);
	if (bv == NULL || prank == NULL) {
		perror("CANT ALLOCATE ENOUGH MEMORY");
		exit(EXIT_FAILURE);
	}
	
	// read only one run-length value each time
	count1_global = count1_local = overflow = 0;
	current_bit = first_bit, current_capacity = 64;
	for (i = j = k = 0, tmp = 0; fscanf(fp, "%u", &RLV) != EOF; i++)
		
		// RLV cant be 0 except for the first one
		if (!(RLV + i))  {
			current_bit = 1 - first_bit;
			continue;
		}
		else if (!RLV) {
			perror("CHECK INPUT BITVECTOR");
			exit(EXIT_FAILURE);
		}
		else
			while (RLV > 0)
				if (RLV >= current_capacity) {
					if (!current_bit)  bv[j] <<= current_capacity;
					else
						for (count1_local += current_capacity; current_capacity > 0; current_capacity--) {
							bv[j] <<= 1;
							bv[j]++;
						}
					RLV -= current_capacity;
					current_capacity = 64;			
					j++;
					
					// not yet complete one group
					if (j % 5) {
						tmp <<= 8;
						if (count1_local < 256)  tmp |= count1_local;
						else if (count1_local > 255 && j == 4) {
							tmp |= 0xFF;
							overflow = 1;
						} else  printf("Error occured while doing counting!\n");
					} else {
						// finish one group
						count1_global += count1_local;
						tmp <<= 32;
						tmp |= count1_global << 1;
						if (overflow)  tmp++;
						prank[k++] = tmp;
						tmp = count1_local = overflow = 0;
					}
				} else {
					if (!current_bit)  bv[j] <<= RLV;
					else
						for (count1_local += RLV; RLV > 0; RLV--) {
							bv[j] <<= 1;
							bv[j]++;
						}
					current_capacity -= RLV;				
					break;
				}
	fclose(fp);
	// deal with the last group
	if (j % 5 || current_capacity < 64) {
		bv[j] <<= current_capacity;
		for (; j % 5; j++) {
			tmp <<= 8;
			if (count1_local < 256)  tmp |= count1_local;
			else if (count1_local > 255 && j == 4) {
				tmp |= 0xFF;
				overflow = 1;
			} else  printf("Error occured while doing counting!\n");
		}
		count1_global += count1_local;
		tmp <<= 32;
		tmp |= count1_global << 1;
		if (overflow)  tmp++;
		prank[k++] = tmp;
		tmp = count1_local = overflow = 0;
	}
	
	printf("There are %u groups and %u segments.\n", k, j);
	fwrite(prank, sizeof(uint64_t), k, output);
	fwrite(bv, sizeof(uint64_t), j, output);	
	free(prank);
	free(bv);	
	printf("Written Completed.\n");
}

// decompose the tree into next level, taking a set of breakpoints
uint32_t decompose (uint16_t **data, uint32_t **bp, uint32_t length, uint32_t NoOfBP, uint32_t cl)
{
	uint32_t i, j, k, l, tmp, al = 1 - cl;
	
	for (i = j = k = l = 0; i < NoOfBP; i++) {
		// create left branch, from j to the breakpoint
		for (tmp = j; j < bp[cl][i]; j++)
			if (!(data[cl][j] >> data_width_M1))  data[al][k++] = data[cl][j] << 1;
			
		bp[al][l++] = k; // record the separate point
		
		// create right branch
		for (j = tmp; j < bp[cl][i]; j++)
			if (data[cl][j] >> data_width_M1)  data[al][k++] = data[cl][j] << 1;
		
		bp[al][l++] = k;
	}
	if (k != length)  perror("Boundary ERROR");
	// return new number of breakpoints
	return l;
}

void build (char *infile, char *tmpdir, char *outfile, unsigned int length)
{
	char BitVector[data_width][1000];
	unsigned int i, j, k, *breakpoints[2], NoOfBP, current_level, current_bit;
	time_t start_time = time(NULL);
	uint16_t *data[2];
	uint32_t RS_pointer[data_width];
	FILE *infp, *outfp;
	
	srand((unsigned int)time(NULL));
	data[0] = malloc(length * sizeof(uint16_t));
	data[1] = malloc(length * sizeof(uint16_t));
	breakpoints[0] = malloc(32770 * sizeof(uint32_t)); // maximum 2^(16-1)
	breakpoints[1] = malloc(32770 * sizeof(uint32_t));
	
	if (data[0] == NULL || data[1] == NULL || breakpoints[0] == NULL || breakpoints[1] == NULL) {
		perror("CANT ALLOCATE ENOUGH MEMORY");
		exit(EXIT_FAILURE);
	}
	// create files for bit vector
	for (i = 0, j = rand(); i < data_width; i++)
		sprintf(BitVector[i], "%s/bit%u_%u.txt", tmpdir, i, j);

	infp = fopen(infile, "r");
	if (infp == NULL) {
		perror("ERROR");
		exit(EXIT_FAILURE);
	}
	printf("Start reading raw data...\n");
	for (i = 0; fscanf(infp, "%u", &j) != EOF; i++)  data[0][i] = j;
	printf("Reading finished.\nTotal bases: %u.\n", i);
	fclose(infp);
	
	breakpoints[0][0] = length;
	for (i = 0, NoOfBP = 1; i < data_width; i++) {
		current_level = i % 2;
		// decompose the wavelet tree to next level
		if (i < data_width_M1) {
			NoOfBP = decompose(data, breakpoints, length, NoOfBP, current_level);
			printf("NoOfBP for level %u: %u\n", i, NoOfBP);
		}
		
		// create bit vector in RLV format, assume the start bit is 0
		// if encounter start bit to be 1, the first RLV is set to 0
		outfp = fopen(BitVector[i], "w");
		for (k = j = current_bit = 0; k < length; k++)
			if (data[current_level][k] >> data_width_M1 == current_bit) j++;
			else {
				fprintf(outfp, "%u\n", j);
				current_bit = 1 - current_bit;
				j = 1;
			}
		fprintf(outfp, "%u\n", j);
		fclose(outfp);
	}	
	free(breakpoints[0]);
	free(breakpoints[1]);
	free(data[0]);
	free(data[1]);
	
	// RS structure construction
	outfp = fopen(outfile, "w");
	fwrite(&length, sizeof(uint32_t), 1, outfp);
	fwrite(&data_width, sizeof(uint32_t), 1, outfp);
	i = 0; // for future use
	fwrite(&i, sizeof(uint32_t), 1, outfp);
	fseek(outfp, data_width * sizeof(uint32_t), SEEK_CUR);
		
	for (i = 0; i < data_width; i++) {
		RS_pointer[i] = ftell(outfp);
		build_rs_structure (BitVector[i], outfp, 0);
		remove(BitVector[i]);
	}
	// use Jacobson data structure for the last level
	//RS_pointer[data_width_M1] = ftell(outfp);
	//build_rank9_structure (BitVector[data_width_M1], outfp, 0, length);
	//remove(BitVector[data_width_M1]);
	
	fseek(outfp, 3 * sizeof(uint32_t), SEEK_SET);
	fwrite(RS_pointer, sizeof(uint32_t), data_width, outfp);
	fclose(outfp);
	printf("Construction Finished.\n");
	printf("Total time elapsed: %us.\n", (unsigned int)(time(NULL) - start_time));
}

