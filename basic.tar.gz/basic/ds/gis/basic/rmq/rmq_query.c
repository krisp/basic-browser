#include"rmq.h"

const unsigned int bucket_size = RMQ_BSIZE;
const unsigned int block_size = RMQ_BSIZE * RMQ_BSIZE;

int16_t find (unsigned int i, unsigned int j, int16_t **table)
{
	if (i > j) return -1;
	int k = log(j - i + 1) / log (2.0);
	if (table[i][k] > table[j - (1 << k) + 1][k]) return table[i][k];
	else return table[j - (1 << k) + 1][k];
}

int16_t search (int16_t values[], uint8_t index[], int size, int s, int t)
{
	int i, j;
	int16_t max;
	if (s > t) return 0;
	for (i = 0; i < size; i++)
		if (index[i] > s) {
			for (j = i, max = values[i-1]; j < size; j++)
				if (index[j] <= t && values[j] > max) max = values[j];
				else if (index[j] > t) return max;
			return max;
		}
	return values[size-1];
}

int rmq_query (rmq_track t, unsigned int p, unsigned int q)
{
	int16_t max, max0;
	unsigned int i, j;
	unsigned int block1 = p / block_size, block2 = q / block_size;
	unsigned int bucket1 = p / bucket_size, bucket2 = q / bucket_size;
	unsigned int block_bucket1 = p % block_size / t->L, block_bucket2 = q % block_size / t->L;
	
	if (p >= t->N || q >= t->N || p > q) {
		perror("Out of Range");
		return SHRT_MIN;
	}
		
	// query block table in memory only if they expand at least one block
	if (block2 - block1 > 1) {
		max = find(block1 + 1, block2 - 1, t->block_table);
		//printf("Initial maximum: %d\n", max);
	} else max = SHRT_MIN;

	// query bucket tables in disk
	// two pointers are not in the same block
	if (block1 != block2) {
		// query the left side only if it is not in the last block bucket
		if (block_bucket1 != t->L - 1) {
			if (fseek(t->fp, t->bucket_tables_start_addr + block1 * t->L * t->logL * sizeof(int16_t), SEEK_SET)) perror("SEEK ERROR");
			for (i = 0; i < t->L; i++)
				if (fread(t->bucket_table[i], sizeof(int16_t), t->logL, t->fp) != t->logL) perror("READ ERROR");
			max0 = find(block_bucket1 + 1, t->L - 1, t->bucket_table);
			if (max0 > max) max = max0;
		}
		// query the right side only if it is not in the first block bucket
		if (block_bucket2 != 0) {
			if (fseek(t->fp, t->bucket_tables_start_addr + block2 * t->L * t->logL * sizeof(int16_t), SEEK_SET)) perror("SEEK ERROR");
			for (i = 0; i < t->L; i++)
				if (fread(t->bucket_table[i], sizeof(int16_t), t->logL, t->fp) != t->logL) perror("READ ERROR");
			max0 = find(0, block_bucket2 - 1, t->bucket_table);
			if (max0 > max) max = max0;
		}
	// in the same block, but expand at least one bucket
	} else if (block_bucket2 - block_bucket1 > 1) {
		if (fseek(t->fp, t->bucket_tables_start_addr + block1 * t->L * t->logL * sizeof(int16_t), SEEK_SET)) perror("SEEK ERROR");
		for (i = 0; i < t->L; i++)
			if (fread(t->bucket_table[i], sizeof(int16_t), t->logL, t->fp) != t->logL) perror("READ ERROR");
		max0 = find(block_bucket1 + 1, block_bucket2 - 1, t->bucket_table);
		if (max0 > max) max = max0;
	}

	// query buckets
	// in different buckets
	if (bucket1 != bucket2) {
		// query left bucket
		if (fseek(t->fp, t->bucket_address[bucket1], SEEK_SET)) perror("SEEK ERROR");
		if (fread(t->bucket_index, sizeof(uint8_t), t->compacted_bucket_size[bucket1], t->fp) != t->compacted_bucket_size[bucket1]) 
			perror("READ ERROR");
		if (fread(t->bucket_value, sizeof(int16_t), t->compacted_bucket_size[bucket1], t->fp) != t->compacted_bucket_size[bucket1]) 
			perror("READ ERROR");
		max0 = search(t->bucket_value, t->bucket_index, t->compacted_bucket_size[bucket1], p % bucket_size, bucket_size - 1);
		if (max0 > max) max = max0;
		
		// query right bucket
		if (fseek(t->fp, t->bucket_address[bucket2], SEEK_SET)) perror("SEEK ERROR");
		if (fread(t->bucket_index, sizeof(uint8_t), t->compacted_bucket_size[bucket2], t->fp) != t->compacted_bucket_size[bucket2]) 
			perror("READ ERROR");
		if (fread(t->bucket_value, sizeof(int16_t), t->compacted_bucket_size[bucket2], t->fp) != t->compacted_bucket_size[bucket2]) 
			perror("READ ERROR");
		max0 = search(t->bucket_value, t->bucket_index, t->compacted_bucket_size[bucket2], 0, q % bucket_size);
		if (max0 > max) max = max0;
	// in the same bucket
	} else {
		if (fseek(t->fp, t->bucket_address[bucket1], SEEK_SET)) perror("SEEK ERROR");
		if (fread(t->bucket_index, sizeof(uint8_t), t->compacted_bucket_size[bucket1], t->fp) != t->compacted_bucket_size[bucket1]) 
			perror("READ ERROR");
		if (fread(t->bucket_value, sizeof(int16_t), t->compacted_bucket_size[bucket1], t->fp) != t->compacted_bucket_size[bucket1]) 
			perror("READ ERROR");
		max0 = search(t->bucket_value, t->bucket_index, t->compacted_bucket_size[bucket1], p % bucket_size, q % bucket_size);
		if (max0 > max) max = max0;
	}	
	//printf("Final maximum: %d\n", max);
	return max;
}

rmq_track rmq_load (char filename[])
{
	unsigned int i, j;
	rmq_track t;
	t = malloc(sizeof(struct rmq_node));
	
	t->fp = fopen(filename, "rb");
	t->L = block_size / bucket_size;
	t->logL = log(t->L) / log(2.0) + 1;
		
	// read overall info
	fread(&t->M, sizeof(unsigned int), 1, t->fp);
	t->logM = log(t->M) / log(2.0) + 1;
	//printf("Block table size is: %u x %u.\n", t->M, t->logM);
	//printf("Bucket table size is: %u x %u.\n", t->L, t->logL);
	t->K = t->M * t->L;
	t->N = t->K * RMQ_BSIZE;
	//printf("Total buckets: %u\n", t->K);
	//printf("Total elements: %u\n", t->N);
	
	// read memory table
	t->block_table = malloc(t->M * sizeof(int16_t *));
	for (i = 0; i < t->M; i++) {
		t->block_table[i] = malloc(t->logM * sizeof(int16_t));
		if (fread(t->block_table[i], sizeof(int16_t), t->logM, t->fp) != t->logM) perror("Read ERROR:");
	}
	// initialize bucket table for read
	t->bucket_table = malloc(t->L * sizeof(int16_t *));
	for (i = 0; i < t->L; i++)
		t->bucket_table[i] = malloc(t->logL * sizeof(int16_t));
	
	t->bucket_tables_start_addr = ftell(t->fp); // save the bucket tables pointer
	if (fseek(t->fp, t->K * t->logL * sizeof(int16_t), SEEK_CUR)) // skip bucket tables at the moment
		perror("Seek ERROR:");
		
	// read the buckets info
	t->compacted_bucket_size = malloc(t->K * sizeof(uint8_t));
	t->bucket_address = malloc(t->K * sizeof(long));
	
	if (fread(t->compacted_bucket_size, sizeof(uint8_t), t->K, t->fp) != t->K) perror("Read ERROR:");
	if (fread(t->bucket_address, sizeof(long), t->K, t->fp) != t->K) perror("Read ERROR:");
	
	t->bucket_contents_start_addr = ftell(t->fp); // save the bucket contents pointer
	//printf("%ld %ld\n", bucket_tables_start_addr, bucket_contents_start_addr);
	//printf("Memory table loaded.\n");
	return t;
}

void rmq_unload (rmq_track t)
{
	unsigned int i, j;
	if (t == NULL) return;
	
	for (i = 0; i < t->M; i++)
		free(t->block_table[i]);
	free(t->block_table);
	
	for (i = 0; i < t->L; i++)
		free(t->bucket_table[i]);
	free(t->bucket_table);
	
	free(t->compacted_bucket_size);
	free(t->bucket_address);
	
	fclose(t->fp);
	free(t);
}

int rmq_query2 (rmq_track t, unsigned int p, unsigned int q)
{
	int16_t max, max0;
	unsigned int i, j;
	unsigned int block1 = p / block_size, block2 = q / block_size;
	unsigned int bucket1 = p / bucket_size, bucket2 = q / bucket_size;
	unsigned int block_bucket1 = p % block_size / t->L, block_bucket2 = q % block_size / t->L;
	
	// own data
	uint8_t bucket_index[RMQ_BSIZE];
	int16_t bucket_value[RMQ_BSIZE];
	int16_t **bucket_table;
	bucket_table = malloc(t->L * sizeof(int16_t *));
	for (i = 0; i < t->L; i++)
		bucket_table[i] = malloc(t->logL * sizeof(int16_t));
	
	if (p >= t->N || q >= t->N || p > q) {
		perror("Out of Range");
		return SHRT_MIN;
	}
		
	// query block table in memory only if they expand at least one block
	if (block2 - block1 > 1) {
		max = find(block1 + 1, block2 - 1, t->block_table);
		//printf("Initial maximum: %d\n", max);
	} else max = SHRT_MIN;

	// query bucket tables in disk
	// two pointers are not in the same block
	if (block1 != block2) {
		// query the left side only if it is not in the last block bucket
		if (block_bucket1 != t->L - 1) {
			if (fseek(t->fp, t->bucket_tables_start_addr + block1 * t->L * t->logL * sizeof(int16_t), SEEK_SET)) perror("SEEK ERROR");
			for (i = 0; i < t->L; i++)
				if (fread(bucket_table[i], sizeof(int16_t), t->logL, t->fp) != t->logL) perror("READ ERROR");
			max0 = find(block_bucket1 + 1, t->L - 1, bucket_table);
			if (max0 > max) max = max0;
		}
		// query the right side only if it is not in the first block bucket
		if (block_bucket2 != 0) {
			if (fseek(t->fp, t->bucket_tables_start_addr + block2 * t->L * t->logL * sizeof(int16_t), SEEK_SET)) perror("SEEK ERROR");
			for (i = 0; i < t->L; i++)
				if (fread(bucket_table[i], sizeof(int16_t), t->logL, t->fp) != t->logL) perror("READ ERROR");
			max0 = find(0, block_bucket2 - 1, bucket_table);
			if (max0 > max) max = max0;
		}
	// in the same block, but expand at least one bucket
	} else if (block_bucket2 - block_bucket1 > 1) {
		if (fseek(t->fp, t->bucket_tables_start_addr + block1 * t->L * t->logL * sizeof(int16_t), SEEK_SET)) perror("SEEK ERROR");
		for (i = 0; i < t->L; i++)
			if (fread(bucket_table[i], sizeof(int16_t), t->logL, t->fp) != t->logL) perror("READ ERROR");
		max0 = find(block_bucket1 + 1, block_bucket2 - 1, bucket_table);
		if (max0 > max) max = max0;
	}

	// query buckets
	// in different buckets
	if (bucket1 != bucket2) {
		// query left bucket
		if (fseek(t->fp, t->bucket_address[bucket1], SEEK_SET)) perror("SEEK ERROR");
		if (fread(bucket_index, sizeof(uint8_t), t->compacted_bucket_size[bucket1], t->fp) != t->compacted_bucket_size[bucket1]) 
			perror("READ ERROR");
		if (fread(bucket_value, sizeof(int16_t), t->compacted_bucket_size[bucket1], t->fp) != t->compacted_bucket_size[bucket1]) 
			perror("READ ERROR");
		max0 = search(bucket_value, bucket_index, t->compacted_bucket_size[bucket1], p % bucket_size, bucket_size - 1);
		if (max0 > max) max = max0;
		
		// query right bucket
		if (fseek(t->fp, t->bucket_address[bucket2], SEEK_SET)) perror("SEEK ERROR");
		if (fread(bucket_index, sizeof(uint8_t), t->compacted_bucket_size[bucket2], t->fp) != t->compacted_bucket_size[bucket2]) 
			perror("READ ERROR");
		if (fread(bucket_value, sizeof(int16_t), t->compacted_bucket_size[bucket2], t->fp) != t->compacted_bucket_size[bucket2]) 
			perror("READ ERROR");
		max0 = search(bucket_value, bucket_index, t->compacted_bucket_size[bucket2], 0, q % bucket_size);
		if (max0 > max) max = max0;
	// in the same bucket
	} else {
		if (fseek(t->fp, t->bucket_address[bucket1], SEEK_SET)) perror("SEEK ERROR");
		if (fread(bucket_index, sizeof(uint8_t), t->compacted_bucket_size[bucket1], t->fp) != t->compacted_bucket_size[bucket1]) 
			perror("READ ERROR");
		if (fread(bucket_value, sizeof(int16_t), t->compacted_bucket_size[bucket1], t->fp) != t->compacted_bucket_size[bucket1]) 
			perror("READ ERROR");
		max0 = search(bucket_value, bucket_index, t->compacted_bucket_size[bucket1], p % bucket_size, q % bucket_size);
		if (max0 > max) max = max0;
	}
	
	for (i = 0; i < t->L; i++)
		free(bucket_table[i]);
	free(bucket_table);
	return max;
}
