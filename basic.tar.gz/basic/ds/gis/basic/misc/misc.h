#ifndef MISC_H
#define MISC_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

int intv_to_seq(char* infile, char* outfile, int chromlen);

#endif
