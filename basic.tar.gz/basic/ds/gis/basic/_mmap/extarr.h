#pragma once

#include <stdint.h>
#include <cassert>
#include "mmap.h"

class UI64ExtBArr {
public:
	UI64ExtBArr();
	UI64ExtBArr(UI64ExtBArr& other);
	UI64ExtBArr(const UI64ExtBArr& other);

	~UI64ExtBArr();
	
	void open(const char* fname, int mode = 0);
	void create(const char* fname, uint64_t len, int mode = 0);
	void close();
	
	uint64_t size() const { return len; }
	
	uint64_t& operator[](uint64_t i) { assert(i < len && ptr != NULL); return ptr[i]; }
	const uint64_t& operator[](uint64_t i) const { assert(i < len && ptr != NULL); return ptr[i]; }
	
	uint64_t get_bits(uint64_t bitindex, unsigned int len) const {
		const unsigned int WORDLEN = 64;
		assert(len <= WORDLEN && len > 0);
		uint64_t i = bitindex / WORDLEN;
		unsigned int j = bitindex % WORDLEN; 
		assert(i < size());
		uint64_t mask = ((1ull << len) - 1); // & (~0ull >> (WORDLEN - len))
		if (j + len <= WORDLEN) {
			assert(i < size());
			return (ptr[i] >> j) & mask;
		} else {
			assert(i + 1 < size());
			return (ptr[i] >> j) | ((ptr[i + 1] << (WORDLEN - j)) & mask);
		}
	}
	
	void set_bits(uint64_t bitindex, uint64_t value, unsigned int len) {
		const unsigned int WORDLEN = 64;
		assert(len <= WORDLEN && len > 0);
		uint64_t i = bitindex / WORDLEN;
		unsigned int j = bitindex % WORDLEN; 
		assert(i < size());
		uint64_t mask = ((1ull << len) - 1); // & (~0ull >> (WORDLEN - len))
		value = value & mask;
		if (j + len <= WORDLEN) {
			assert(i < size());
			ptr[i] = (ptr[i] & ~(mask << j)) | (value << j);
		} else {
			assert(i + 1 < size());
			ptr[i] = (ptr[i] & ~(mask << j)) | (value << j);
			ptr[i+1] = ptr[i+1] & ~ (mask >> (WORDLEN - j)) &  value >> (WORDLEN - j);
		}
	}

	bool compat_bitlen(uint64_t bitlen) { if (bitlen % 64 == 0) return size() == bitlen / 64; else return size() == bitlen / 64 + 1; }

	UI64ExtBArr& operator=(const UI64ExtBArr& other);

protected:
	void decCounter();
	void incCounter() const;

	unsigned int * counter; // reference counting :)
	MMAP * f;
	uint64_t len;
	uint64_t * ptr;
};
