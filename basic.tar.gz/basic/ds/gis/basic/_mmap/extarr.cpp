#include "extarr.h"

#include <stdexcept>
#include <iostream>
#include "logger.h"


UI64ExtBArr::UI64ExtBArr(): f(NULL), ptr(NULL), len(0), counter(NULL) {}
UI64ExtBArr::UI64ExtBArr(UI64ExtBArr& other): f(other.f), len(other.len), ptr(other.ptr) {
	if (other.f != NULL) {
		counter = other.counter;
		assert(counter != NULL);
		*counter += 1;
	}
}

UI64ExtBArr::UI64ExtBArr(const UI64ExtBArr& other): f(other.f), len(other.len), ptr(other.ptr) {
	if (other.f != NULL) {
		counter = other.counter;
		assert(counter != NULL);
		*counter += 1;
	}
}


void UI64ExtBArr::incCounter() const {
	if (f != NULL) *counter += 1;
}

void UI64ExtBArr::decCounter() {
	if (this->f != NULL) {
		*counter -= 1;
		if (*counter == 0) close();
	}
}

UI64ExtBArr& UI64ExtBArr::operator=(const UI64ExtBArr& other) {
	if (this == &other) return *this;
	other.incCounter();
	decCounter();
	f = other.f;
	len = other.len;
	ptr = other.ptr;
	counter = other.counter;
	return *this;
}

void UI64ExtBArr::close() {
	if (f != NULL) mymunmap(f);
	f = NULL;
	ptr = NULL;
	len = 0;
	if (counter != NULL) *counter = 0;
	delete counter;
	TRACEM("UInt64 array closed");
}

UI64ExtBArr::~UI64ExtBArr() {
	decCounter();
}

void UI64ExtBArr::create(const char* fname, uint64_t len, int mode) {
	assert(len > 0);
	if (f != NULL) close();
	this->len = len;
	f = mymmap_w(fname, len * 8);
	ptr = (uint64_t*)(f->addr);
	counter = new unsigned int;
	*counter = 1;
	TRACEM("Create new UInt64Arr");
}

void UI64ExtBArr::open(const char* fname, int mode) {
	if (f != NULL) close();
	f = mymmap(fname);
	if (f->len % 8 != 0)
		WARNM("file size is not multiple of 8");
	len = (f->len / 8);
	ptr = (uint64_t*)(f->addr);
	counter = new unsigned int;
	*counter = 1;
	TRACEM("Open UInt64Arr");
}

