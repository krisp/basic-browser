#pragma once
#include <string>
#include <sstream>

template<typename T>
std::string tostr(const T& v) {
	std::ostringstream ss;
	ss << v;
	return ss.str();
}

template<typename T>
T strto(const std::string& s) {
	std::istringstream ss(s);
	T v;
	ss >> v;
	return v;
}

std::string pathadd(const std::string& prefix, const std::string& suffix);