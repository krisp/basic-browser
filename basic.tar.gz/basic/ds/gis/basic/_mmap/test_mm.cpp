
#include "extarr.h"
#include "fosm.h"

#include <iostream>
using namespace std;

void test1() {
	UI64ExtBArr test;
	test.create("/home/hoang/gb/temp/ui64arr", 10);
	test[0] = 1;
	test[9] = 1;
	test.close();
	cout << "written to disk ? " << endl;
	UI64ExtBArr t2;
	t2.open("/home/hoang/gb/temp/ui64arr");
	cout << t2.size() << endl;
	cout << t2[0] << endl;
	cout << t2[1] << endl;
	cout << t2[9] << endl;
	t2.close();

}

int main() {
	return 0;
}

