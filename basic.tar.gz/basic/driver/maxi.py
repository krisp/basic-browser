'''
Created on Nov 4, 2010

@author: fabianus
'''
from contextlib import contextmanager
from gis.basic import rmq
from os import path
import yaml

class Maxi:
  @staticmethod
  @contextmanager
  def open(rmqfile):
    driver = None
    try:
      driver = Maxi(rmqfile)
      yield driver
    finally:
      if driver: driver.close()
  
  def __init__(self, rmqfile):
    with open(rmqfile) as f:
      self.rmqfile = yaml.load(f)
    self.handlers = dict()
    self.ratios = self.rmqfile.get("__ratios__", {}) # to scale the retrieved values, if necessary
    self.dirname = path.dirname(path.abspath(rmqfile))
  
  def query(self, chrom, start, end):
    h = self.handlers.get(chrom, None)
    if not h:
      f = str(path.join(self.dirname, self.rmqfile[chrom]))
      h = rmq.rmq_load(f)
      self.handlers[chrom] = h
    return rmq.rmq_query(h, start-1, end-1) * self.ratios.get(chrom, 1)
  
  def close(self):
    for h in self.handlers.itervalues():
      rmq.rmq_unload(h)
