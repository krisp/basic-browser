'''
Created on Nov 4, 2010

@author: fabianus
'''
from extsds import gap_rs
from os import path
import yaml

class Sigma:
  def __init__(self, sumfile):
    with open(sumfile) as f:
      self.sumfile = yaml.load(f)
    self.handlers = dict()
    self.ids = self.sumfile.get("__ids__", {})
    self.modifiers = self.sumfile.get("__modifiers__") # to scale the retrieved values, if necessary
    self.dirname = path.dirname(path.abspath(sumfile))

  def sum(self, chrom, start, end):
    h = self.handlers.get(chrom)
    if not h:
      f = str(path.join(self.dirname, self.sumfile[chrom]))
      h = gap_rs.SumQuery()
      h.load(f, self.ids[chrom])
      self.handlers[chrom] = h
    return h.sum_range(start, end)/self.modifiers[chrom]
  
  def average(self, chrom, start, end):
    return self.sum(chrom, start, end)/float(end-start+1)
  
  def close(self): pass
  