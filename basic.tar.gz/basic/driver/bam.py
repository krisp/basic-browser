'''
Created on Oct 17, 2011

@author: mulawadifh
'''
import pysam

_OK = 0
_INSERT = 1
_DELETE = 2
_SKIP = 4

class Bammy(object):
    def __init__(self, bamfile):
        self.bammy = pysam.Samfile(bamfile, 'rb')
        self.chroms = self.bammy.getrname

    def _process_read(self, read, report_seq=False):
        if read.is_unmapped: 
            return None
        if (read.flag & 0x704):
            return None
        
        pos = read.pos
        seqs = list()

        i = 0
        for type_, length in read.cigar:
            if type_ == _OK:
                seqs.append(read.seq[i:i+length])
                i += length
            elif type_ == _DELETE:
                seqs.append('-' * length)
            elif type_ == _INSERT or type_ == _SKIP:
                i += length

        seq = ''.join(seqs)
        alen = read.alen
        d = dict(chrom=self.chroms(read.tid),
                 name=read.qname,
                 strand='-' if read.is_reverse else '+',
                 read=2 if read.is_read2 else 1,
                 len=alen,
                 pos=pos+1)

        if report_seq: 
            d['seq'] = seq
        return d
    
    def query(self, chrom, start, end, limit, report_seq=False):
        result = list()
        count = 0
        
        for read in self.bammy.fetch(chrom, start, end):
            d = self._process_read(read, report_seq)
            if d:
                result.append(d)
            count += 1
            if count >= limit: break
        
        return result
    
    def close(self):
        self.bammy.close()

class TwinBammy(Bammy):
    '''For handling BAM files containing paired-end tags'''
    
    def __init__(self, bamfile):
        super(TwinBammy, self).__init__(bamfile)
    
    def _process_read(self, read, report_seq=False):
        d = super(TwinBammy, self)._process_read(read, report_seq)
        if not (read.is_paired and read.is_proper_pair):
            return d
        
        mate = self.bammy.mate(read)
        pair = [d, super(TwinBammy, self)._process_read(mate, report_seq)]
        
        # x is index to entry with leftmost pos
        x, y = (0, 1) if read.pos < mate.pos else (1, 0)
        pair[x]['_mate'] = pair[y] # mate is always more downstream
        
        return pair[x]