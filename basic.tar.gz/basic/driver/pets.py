'''
29 March 2011: [Fabi] modified to support old and new (with IDs) data structure from Jianxing
'''
from contextlib import contextmanager
from gis.basic import pets, xpets
from itertools import izip
from os import path
import yaml

class Tags:
  @staticmethod
  @contextmanager
  def open(petfile):
    driver = None
    try:
      driver = Tags(petfile)
      yield driver
    finally:
      if driver: driver.close()
  
  def __init__(self, petfile):
    with open(petfile) as f:
      petobj = yaml.load(f)
      dirname = path.dirname(path.abspath(petfile))
      pet_out = path.join(dirname, petobj["pets"]) 
      pet_select = path.join(dirname, petobj["select"])
      self.taglen = petobj["taglen"]
      self.chroms = petobj["chroms"] # used to convert 24->'chrY', etc
      self.single = petobj.get("type") == "single" # whether it's single or paired
      self.ver = petobj.get("version", 1) # to differentiate version with non-ID (ver1) from ver2
      self.chromap = dict()

      for p,q in enumerate(self.chroms): 
        self.chromap[q] = p+1 # used to convert 'chr1'->1, 'chrX'->23, etc
      
      if self.ver == 1:
        # use old module
        self.handler = pets.pets_load(str(pet_select), str(pet_out), len(self.chroms)) # same method for loading
      else:
        # use newer pets module
        self.handler = xpets.pets_load(str(pet_select), str(pet_out), 0 if self.single else 1) # 0->single, 1->paired
  
  _S_HDR = ("chrom", "pos", "strand") 
  def _query_single(self, chrom, start, end, maxpets):
    if self.ver == 1:
      # returns list of tuples
      result = set(pets.pets_query_single(self.handler, self.chromap[chrom], start, end, maxpets)) # remove duplicates
      result = [dict(izip(Tags._S_HDR, r)) for r in result] # turn into dictionary
    else:
      # returns list of dict
      result = list()
      uniqs = set()
      for x in xpets.pets_query_single(self.handler, self.chromap[chrom], start, end, maxpets):
        xid = x['id']
        if xid in uniqs: continue
        uniqs.add(xid)
        result.append(x)

    for r in result:
      r["chrom"] = self.chroms[r["chrom"]-1]
    return result #sorted(result, key=lambda x: x["pos"])

  _P_HDR = ("chrom", "pos", "strand", "chrom2", "pos2", "strand2")
  def _query_paired(self, chrom, start, end, maxpets):
    if self.ver == 1:
      result = set(pets.pets_query(self.handler, self.chromap[chrom], start, end, maxpets)) # remove duplicates
      result = [dict(izip(Tags._P_HDR, r)) for r in result] # turn into dictionary
    else:
      result = list()
      uniqs = set()
      for x in xpets.pets_query(self.handler, self.chromap[chrom], start, end, maxpets):
        xid = x['id']
        if xid in uniqs: continue
        uniqs.add(xid)
        result.append(x)
      
    for r in result:
      r["chrom"] = self.chroms[r["chrom"]-1]
      r["chrom2"] = self.chroms[r["chrom2"]-1]
    return result #sorted(result, key=lambda x: x["pos1"])
  
  def query(self, chrom, start, end, maxpets):
    if self.single:
      return self._query_single(chrom, start, end, maxpets)
    else:
      return self._query_paired(chrom, start, end, maxpets)
  
  def close(self):
    if self.ver == 1:
      pets.pets_unload(self.handler)
    else:
      xpets.pets_unload(self.handler)
